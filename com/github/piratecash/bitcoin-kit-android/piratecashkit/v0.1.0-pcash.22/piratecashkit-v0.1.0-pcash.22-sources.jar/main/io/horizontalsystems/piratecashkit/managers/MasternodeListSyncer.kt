package io.horizontalsystems.piratecashkit.managers

import io.horizontalsystems.bitcoincore.BitcoinCore
import io.horizontalsystems.bitcoincore.blocks.IPeerSyncListener
import io.horizontalsystems.bitcoincore.core.IInitialDownload
import io.horizontalsystems.bitcoincore.extensions.toReversedByteArray
import io.horizontalsystems.bitcoincore.network.peer.IPeerTaskHandler
import io.horizontalsystems.bitcoincore.network.peer.Peer
import io.horizontalsystems.bitcoincore.network.peer.PeerGroup
import io.horizontalsystems.bitcoincore.network.peer.PeerScopedExecutor
import io.horizontalsystems.bitcoincore.network.peer.task.PeerTask
import io.horizontalsystems.piratecashkit.tasks.PeerTaskFactory
import io.horizontalsystems.piratecashkit.tasks.RequestMasternodeListDiffTask

class MasternodeListSyncer(
    private val bitcoinCore: BitcoinCore,
    private val peerTaskFactory: PeerTaskFactory,
    private val masternodeListManager: MasternodeListManager,
    private val initialBlockDownload: IInitialDownload,
    private val logTag: String
) : IPeerTaskHandler, IPeerSyncListener, PeerGroup.Listener, AutoCloseable {

    @Volatile
    private var workingPeer: Peer? = null
    private val peersQueue = PeerScopedExecutor()

    override fun onStart() {
        peersQueue.start()
    }

    override fun onStop() {
        peersQueue.close()
    }

    /**
     * Explicit teardown invoked from BitcoinCore.stop(). Idempotent with
     * onStop(); required for the SharedPeerGroup case where onStop() may
     * never fire (refcount > 0 — other shared kits are still running).
     */
    override fun close() {
        peersQueue.close()
    }

    override fun onPeerSynced(peer: Peer) {
        assignNextSyncPeer()
    }

    override fun onPeerDisconnect(peer: Peer, e: Exception?) {
        if (peer == workingPeer) {
            workingPeer = null

            assignNextSyncPeer()
        }
    }

    private fun assignNextSyncPeer() {
        peersQueue.execute {
            if (workingPeer == null) {
                bitcoinCore.lastBlockInfo?.let { lastBlockInfo ->
                    val peersCopy = ArrayList(initialBlockDownload.syncedPeers)
                    peersCopy.firstOrNull()?.let { syncedPeer ->
                        val blockHash = lastBlockInfo.headerHash.toReversedByteArray()
                        val baseBlockHash = masternodeListManager.baseBlockHash

                        if (!blockHash.contentEquals(baseBlockHash)) {
                            val task = peerTaskFactory.createRequestMasternodeListDiffTask(baseBlockHash, blockHash, logTag)
                            syncedPeer.addTask(task)

                            workingPeer = syncedPeer
                        }
                    }
                }
            }
        }
    }


    override fun handleCompletedTask(peer: Peer, task: PeerTask): Boolean {
        return when (task) {
            is RequestMasternodeListDiffTask -> {
                task.masternodeListDiffMessage?.let { masternodeListDiffMessage ->
                    masternodeListManager.updateList(masternodeListDiffMessage)
                    workingPeer = null
                }
                true
            }

            else -> false
        }
    }

}
