package io.horizontalsystems.piratecashkit.messages

import io.horizontalsystems.bitcoincore.extensions.toReversedHex
import io.horizontalsystems.bitcoincore.io.BitcoinInputMarkable
import io.horizontalsystems.bitcoincore.network.messages.IMessage
import io.horizontalsystems.bitcoincore.network.messages.IMessageParser
import io.horizontalsystems.bitcoincore.storage.FullTransaction
import io.horizontalsystems.piratecashkit.models.CoinbaseTransaction
import io.horizontalsystems.piratecashkit.models.Masternode
import io.horizontalsystems.piratecashkit.models.Quorum

class MasternodeListDiffMessage(
    val baseBlockHash: ByteArray,
    val blockHash: ByteArray,
    val totalTransactions: Long,
    val merkleHashes: List<ByteArray>,
    val merkleFlags: ByteArray,
    val cbTx: FullTransaction,
    val deletedMNs: List<ByteArray>,
    val mnList: List<Masternode>,
    val deletedQuorums: List<Pair<Int, ByteArray>>,
    val quorumList: List<Quorum>
) : IMessage {

    override fun toString(): String {
        return "MnListDiffMessage(baseBlockHash=${baseBlockHash.toReversedHex()}, blockHash=${blockHash.toReversedHex()})"
    }

}

class MasternodeListDiffMessageParser : IMessageParser {
    override val command: String = "mnlistdiff"

    override fun parseMessage(input: BitcoinInputMarkable): IMessage {
        // PirateCash daemon at PROTOCOL_VERSION >= MNLISTDIFF_VERSION_ORDER
        // (70229) serialises CSimplifiedMNListDiff with nVersion (uint16)
        // BEFORE baseBlockHash. Skipping this field shifts every subsequent
        // read by 2 bytes; eventually a varint inside the coinbase tx's
        // sigScript length comes out as ~432 MB and crashes the worker
        // thread with OOM. Our wallet announces protocolVersion = 70229,
        // so every mnlistdiff we ever see uses this layout.
        val version = input.readUnsignedShort()
        val baseBlockHash = input.readBytes(32)
        val blockHash = input.readBytes(32)

        // Read Merkle tree
        val totalTransactions = input.readUnsignedInt()
        val merkleHashesCount = input.readVarInt()
        val merkleHashes = mutableListOf<ByteArray>()
        repeat(merkleHashesCount.toInt()) {
            merkleHashes.add(input.readBytes(32))
        }
        val merkleFlagsCount = input.readVarInt()
        val merkleFlags = input.readBytes(merkleFlagsCount.toInt())

        // Read coinbase transaction
        val cbTx = CoinbaseTransaction.deserialize(input)

        // Deleted MNs
        val deletedMNsCount = input.readVarInt()
        val deletedMNs = mutableListOf<ByteArray>()
        repeat(deletedMNsCount.toInt()) {
            deletedMNs.add(input.readBytes(32))
        }

        // Masternodes
        val mnListCount = input.readVarInt()
        val mnList = mutableListOf<Masternode>()
        repeat(mnListCount.toInt()) {
            mnList.add(Masternode(input))
        }

        // Deleted Quorums
        val deletedQuorumsCount = input.readVarInt()
        val deletedQuorums = mutableListOf<Pair<Int, ByteArray>>()
        repeat(deletedQuorumsCount.toInt()) {
            deletedQuorums.add(Pair(input.read(), input.readBytes(32)))
        }

        // Quorums
        val newQuorumsCount = input.readVarInt()
        val quorumList = mutableListOf<Quorum>()
        repeat(newQuorumsCount.toInt()) {
            quorumList.add(Quorum(input))
        }

        return MasternodeListDiffMessage(baseBlockHash, blockHash, totalTransactions, merkleHashes, merkleFlags, cbTx, deletedMNs, mnList, deletedQuorums, quorumList)
    }
}
