package io.horizontalsystems.piratecashkit.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.piratecashkit.models.MasternodeListState
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class MasternodeListStateDao_Impl(
  __db: RoomDatabase,
) : MasternodeListStateDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfMasternodeListState: EntityInsertAdapter<MasternodeListState>
  init {
    this.__db = __db
    this.__insertAdapterOfMasternodeListState = object : EntityInsertAdapter<MasternodeListState>()
        {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `MasternodeListState` (`baseBlockHash`,`primaryKey`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: MasternodeListState) {
        statement.bindBlob(1, entity.baseBlockHash)
        statement.bindText(2, entity.primaryKey)
      }
    }
  }

  public override fun setState(state: MasternodeListState): Unit = performBlocking(__db, false,
      true) { _connection ->
    __insertAdapterOfMasternodeListState.insert(_connection, state)
  }

  public override fun getState(): MasternodeListState? {
    val _sql: String = "SELECT * FROM MasternodeListState LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBaseBlockHash: Int = getColumnIndexOrThrow(_stmt, "baseBlockHash")
        val _columnIndexOfPrimaryKey: Int = getColumnIndexOrThrow(_stmt, "primaryKey")
        val _result: MasternodeListState?
        if (_stmt.step()) {
          val _tmpBaseBlockHash: ByteArray
          _tmpBaseBlockHash = _stmt.getBlob(_columnIndexOfBaseBlockHash)
          _result = MasternodeListState(_tmpBaseBlockHash)
          _result.primaryKey = _stmt.getText(_columnIndexOfPrimaryKey)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
