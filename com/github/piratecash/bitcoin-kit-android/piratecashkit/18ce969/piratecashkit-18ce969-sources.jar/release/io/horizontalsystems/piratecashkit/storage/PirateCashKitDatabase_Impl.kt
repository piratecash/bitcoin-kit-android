package io.horizontalsystems.piratecashkit.storage

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class PirateCashKitDatabase_Impl : PirateCashKitDatabase() {
  private val _instantTransactionHashDao: Lazy<InstantTransactionHashDao> = lazy {
    InstantTransactionHashDao_Impl(this)
  }

  public override val instantTransactionHashDao: InstantTransactionHashDao
    get() = _instantTransactionHashDao.value

  private val _masternodeDao: Lazy<MasternodeDao> = lazy {
    MasternodeDao_Impl(this)
  }

  public override val masternodeDao: MasternodeDao
    get() = _masternodeDao.value

  private val _quorumDao: Lazy<QuorumDao> = lazy {
    QuorumDao_Impl(this)
  }

  public override val quorumDao: QuorumDao
    get() = _quorumDao.value

  private val _masternodeListStateDao: Lazy<MasternodeListStateDao> = lazy {
    MasternodeListStateDao_Impl(this)
  }

  public override val masternodeListStateDao: MasternodeListStateDao
    get() = _masternodeListStateDao.value

  private val _instantTransactionInputDao: Lazy<InstantTransactionInputDao> = lazy {
    InstantTransactionInputDao_Impl(this)
  }

  public override val instantTransactionInputDao: InstantTransactionInputDao
    get() = _instantTransactionInputDao.value

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(10,
        "dccfe54bb6a59e6ca9a9401c8f8fd34c", "54a830ef4166bccfe3e5d3e0a1d5eeeb") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Masternode` (`proRegTxHash` BLOB NOT NULL, `confirmedHash` BLOB NOT NULL, `ipAddress` BLOB NOT NULL, `port` INTEGER NOT NULL, `pubKeyOperator` BLOB NOT NULL, `keyIDVoting` BLOB NOT NULL, `isValid` INTEGER NOT NULL, `type` INTEGER, `platformHTTPPort` INTEGER, `platformNodeID` BLOB, `hash` BLOB NOT NULL, PRIMARY KEY(`proRegTxHash`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Quorum` (`hash` BLOB NOT NULL, `version` INTEGER NOT NULL, `type` INTEGER NOT NULL, `quorumHash` BLOB NOT NULL, `quorumIndex` INTEGER, `signers` BLOB NOT NULL, `validMembers` BLOB NOT NULL, `quorumPublicKey` BLOB NOT NULL, `quorumVvecHash` BLOB NOT NULL, `quorumSig` BLOB NOT NULL, `sig` BLOB NOT NULL, PRIMARY KEY(`hash`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `MasternodeListState` (`baseBlockHash` BLOB NOT NULL, `primaryKey` TEXT NOT NULL, PRIMARY KEY(`primaryKey`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `InstantTransactionInput` (`txHash` BLOB NOT NULL, `inputTxHash` BLOB NOT NULL, `inputTxOutputIndex` INTEGER NOT NULL, `timeCreated` INTEGER NOT NULL, `voteCount` INTEGER NOT NULL, `blockHeight` INTEGER, PRIMARY KEY(`txHash`, `inputTxHash`, `inputTxOutputIndex`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `InstantTransactionHash` (`txHash` BLOB NOT NULL, PRIMARY KEY(`txHash`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'dccfe54bb6a59e6ca9a9401c8f8fd34c')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `Masternode`")
        connection.execSQL("DROP TABLE IF EXISTS `Quorum`")
        connection.execSQL("DROP TABLE IF EXISTS `MasternodeListState`")
        connection.execSQL("DROP TABLE IF EXISTS `InstantTransactionInput`")
        connection.execSQL("DROP TABLE IF EXISTS `InstantTransactionHash`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsMasternode: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsMasternode.put("proRegTxHash", TableInfo.Column("proRegTxHash", "BLOB", true, 1,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("confirmedHash", TableInfo.Column("confirmedHash", "BLOB", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("ipAddress", TableInfo.Column("ipAddress", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("port", TableInfo.Column("port", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("pubKeyOperator", TableInfo.Column("pubKeyOperator", "BLOB", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("keyIDVoting", TableInfo.Column("keyIDVoting", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("isValid", TableInfo.Column("isValid", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("type", TableInfo.Column("type", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("platformHTTPPort", TableInfo.Column("platformHTTPPort", "INTEGER",
            false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("platformNodeID", TableInfo.Column("platformNodeID", "BLOB", false,
            0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternode.put("hash", TableInfo.Column("hash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysMasternode: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesMasternode: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoMasternode: TableInfo = TableInfo("Masternode", _columnsMasternode,
            _foreignKeysMasternode, _indicesMasternode)
        val _existingMasternode: TableInfo = read(connection, "Masternode")
        if (!_infoMasternode.equals(_existingMasternode)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Masternode(io.horizontalsystems.piratecashkit.models.Masternode).
              | Expected:
              |""".trimMargin() + _infoMasternode + """
              |
              | Found:
              |""".trimMargin() + _existingMasternode)
        }
        val _columnsQuorum: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsQuorum.put("hash", TableInfo.Column("hash", "BLOB", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("version", TableInfo.Column("version", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("type", TableInfo.Column("type", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("quorumHash", TableInfo.Column("quorumHash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("quorumIndex", TableInfo.Column("quorumIndex", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("signers", TableInfo.Column("signers", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("validMembers", TableInfo.Column("validMembers", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("quorumPublicKey", TableInfo.Column("quorumPublicKey", "BLOB", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("quorumVvecHash", TableInfo.Column("quorumVvecHash", "BLOB", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("quorumSig", TableInfo.Column("quorumSig", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsQuorum.put("sig", TableInfo.Column("sig", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysQuorum: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesQuorum: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoQuorum: TableInfo = TableInfo("Quorum", _columnsQuorum, _foreignKeysQuorum,
            _indicesQuorum)
        val _existingQuorum: TableInfo = read(connection, "Quorum")
        if (!_infoQuorum.equals(_existingQuorum)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Quorum(io.horizontalsystems.piratecashkit.models.Quorum).
              | Expected:
              |""".trimMargin() + _infoQuorum + """
              |
              | Found:
              |""".trimMargin() + _existingQuorum)
        }
        val _columnsMasternodeListState: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsMasternodeListState.put("baseBlockHash", TableInfo.Column("baseBlockHash", "BLOB",
            true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMasternodeListState.put("primaryKey", TableInfo.Column("primaryKey", "TEXT", true,
            1, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysMasternodeListState: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesMasternodeListState: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoMasternodeListState: TableInfo = TableInfo("MasternodeListState",
            _columnsMasternodeListState, _foreignKeysMasternodeListState,
            _indicesMasternodeListState)
        val _existingMasternodeListState: TableInfo = read(connection, "MasternodeListState")
        if (!_infoMasternodeListState.equals(_existingMasternodeListState)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |MasternodeListState(io.horizontalsystems.piratecashkit.models.MasternodeListState).
              | Expected:
              |""".trimMargin() + _infoMasternodeListState + """
              |
              | Found:
              |""".trimMargin() + _existingMasternodeListState)
        }
        val _columnsInstantTransactionInput: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsInstantTransactionInput.put("txHash", TableInfo.Column("txHash", "BLOB", true, 1,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsInstantTransactionInput.put("inputTxHash", TableInfo.Column("inputTxHash", "BLOB",
            true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsInstantTransactionInput.put("inputTxOutputIndex",
            TableInfo.Column("inputTxOutputIndex", "INTEGER", true, 3, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsInstantTransactionInput.put("timeCreated", TableInfo.Column("timeCreated",
            "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsInstantTransactionInput.put("voteCount", TableInfo.Column("voteCount", "INTEGER",
            true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsInstantTransactionInput.put("blockHeight", TableInfo.Column("blockHeight",
            "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysInstantTransactionInput: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesInstantTransactionInput: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoInstantTransactionInput: TableInfo = TableInfo("InstantTransactionInput",
            _columnsInstantTransactionInput, _foreignKeysInstantTransactionInput,
            _indicesInstantTransactionInput)
        val _existingInstantTransactionInput: TableInfo = read(connection,
            "InstantTransactionInput")
        if (!_infoInstantTransactionInput.equals(_existingInstantTransactionInput)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |InstantTransactionInput(io.horizontalsystems.piratecashkit.models.InstantTransactionInput).
              | Expected:
              |""".trimMargin() + _infoInstantTransactionInput + """
              |
              | Found:
              |""".trimMargin() + _existingInstantTransactionInput)
        }
        val _columnsInstantTransactionHash: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsInstantTransactionHash.put("txHash", TableInfo.Column("txHash", "BLOB", true, 1,
            null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysInstantTransactionHash: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesInstantTransactionHash: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoInstantTransactionHash: TableInfo = TableInfo("InstantTransactionHash",
            _columnsInstantTransactionHash, _foreignKeysInstantTransactionHash,
            _indicesInstantTransactionHash)
        val _existingInstantTransactionHash: TableInfo = read(connection, "InstantTransactionHash")
        if (!_infoInstantTransactionHash.equals(_existingInstantTransactionHash)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |InstantTransactionHash(io.horizontalsystems.piratecashkit.models.InstantTransactionHash).
              | Expected:
              |""".trimMargin() + _infoInstantTransactionHash + """
              |
              | Found:
              |""".trimMargin() + _existingInstantTransactionHash)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "Masternode", "Quorum",
        "MasternodeListState", "InstantTransactionInput", "InstantTransactionHash")
  }

  public override fun clearAllTables() {
    super.performClear(false, "Masternode", "Quorum", "MasternodeListState",
        "InstantTransactionInput", "InstantTransactionHash")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(InstantTransactionHashDao::class,
        InstantTransactionHashDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(MasternodeDao::class, MasternodeDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(QuorumDao::class, QuorumDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(MasternodeListStateDao::class,
        MasternodeListStateDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(InstantTransactionInputDao::class,
        InstantTransactionInputDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }
}
