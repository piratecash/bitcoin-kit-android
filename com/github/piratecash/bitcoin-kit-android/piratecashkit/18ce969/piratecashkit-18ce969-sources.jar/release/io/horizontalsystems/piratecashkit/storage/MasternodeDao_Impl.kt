package io.horizontalsystems.piratecashkit.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.piratecashkit.models.Masternode
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class MasternodeDao_Impl(
  __db: RoomDatabase,
) : MasternodeDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfMasternode: EntityInsertAdapter<Masternode>
  init {
    this.__db = __db
    this.__insertAdapterOfMasternode = object : EntityInsertAdapter<Masternode>() {
      protected override fun createQuery(): String =
          "INSERT OR ABORT INTO `Masternode` (`proRegTxHash`,`confirmedHash`,`ipAddress`,`port`,`pubKeyOperator`,`keyIDVoting`,`isValid`,`type`,`platformHTTPPort`,`platformNodeID`,`hash`) VALUES (?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Masternode) {
        statement.bindBlob(1, entity.proRegTxHash)
        statement.bindBlob(2, entity.confirmedHash)
        statement.bindBlob(3, entity.ipAddress)
        statement.bindLong(4, entity.port.toLong())
        statement.bindBlob(5, entity.pubKeyOperator)
        statement.bindBlob(6, entity.keyIDVoting)
        val _tmp: Int = if (entity.isValid) 1 else 0
        statement.bindLong(7, _tmp.toLong())
        val _tmpType: Int? = entity.type
        if (_tmpType == null) {
          statement.bindNull(8)
        } else {
          statement.bindLong(8, _tmpType.toLong())
        }
        val _tmpPlatformHTTPPort: Int? = entity.platformHTTPPort
        if (_tmpPlatformHTTPPort == null) {
          statement.bindNull(9)
        } else {
          statement.bindLong(9, _tmpPlatformHTTPPort.toLong())
        }
        val _tmpPlatformNodeID: ByteArray? = entity.platformNodeID
        if (_tmpPlatformNodeID == null) {
          statement.bindNull(10)
        } else {
          statement.bindBlob(10, _tmpPlatformNodeID)
        }
        statement.bindBlob(11, entity.hash)
      }
    }
  }

  public override fun insertAll(masternodes: List<Masternode>): Unit = performBlocking(__db, false,
      true) { _connection ->
    __insertAdapterOfMasternode.insert(_connection, masternodes)
  }

  public override fun getAll(): List<Masternode> {
    val _sql: String = "SELECT * FROM Masternode"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfProRegTxHash: Int = getColumnIndexOrThrow(_stmt, "proRegTxHash")
        val _columnIndexOfConfirmedHash: Int = getColumnIndexOrThrow(_stmt, "confirmedHash")
        val _columnIndexOfIpAddress: Int = getColumnIndexOrThrow(_stmt, "ipAddress")
        val _columnIndexOfPort: Int = getColumnIndexOrThrow(_stmt, "port")
        val _columnIndexOfPubKeyOperator: Int = getColumnIndexOrThrow(_stmt, "pubKeyOperator")
        val _columnIndexOfKeyIDVoting: Int = getColumnIndexOrThrow(_stmt, "keyIDVoting")
        val _columnIndexOfIsValid: Int = getColumnIndexOrThrow(_stmt, "isValid")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfPlatformHTTPPort: Int = getColumnIndexOrThrow(_stmt, "platformHTTPPort")
        val _columnIndexOfPlatformNodeID: Int = getColumnIndexOrThrow(_stmt, "platformNodeID")
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _result: MutableList<Masternode> = mutableListOf()
        while (_stmt.step()) {
          val _item: Masternode
          _item = Masternode()
          _item.proRegTxHash = _stmt.getBlob(_columnIndexOfProRegTxHash)
          _item.confirmedHash = _stmt.getBlob(_columnIndexOfConfirmedHash)
          _item.ipAddress = _stmt.getBlob(_columnIndexOfIpAddress)
          _item.port = _stmt.getLong(_columnIndexOfPort).toInt()
          _item.pubKeyOperator = _stmt.getBlob(_columnIndexOfPubKeyOperator)
          _item.keyIDVoting = _stmt.getBlob(_columnIndexOfKeyIDVoting)
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsValid).toInt()
          _item.isValid = _tmp != 0
          if (_stmt.isNull(_columnIndexOfType)) {
            _item.type = null
          } else {
            _item.type = _stmt.getLong(_columnIndexOfType).toInt()
          }
          if (_stmt.isNull(_columnIndexOfPlatformHTTPPort)) {
            _item.platformHTTPPort = null
          } else {
            _item.platformHTTPPort = _stmt.getLong(_columnIndexOfPlatformHTTPPort).toInt()
          }
          if (_stmt.isNull(_columnIndexOfPlatformNodeID)) {
            _item.platformNodeID = null
          } else {
            _item.platformNodeID = _stmt.getBlob(_columnIndexOfPlatformNodeID)
          }
          _item.hash = _stmt.getBlob(_columnIndexOfHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun clearAll() {
    val _sql: String = "DELETE FROM Masternode"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
