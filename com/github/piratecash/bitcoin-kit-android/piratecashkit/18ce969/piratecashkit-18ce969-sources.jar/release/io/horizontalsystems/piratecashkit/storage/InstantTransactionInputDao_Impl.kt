package io.horizontalsystems.piratecashkit.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.piratecashkit.models.InstantTransactionInput
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class InstantTransactionInputDao_Impl(
  __db: RoomDatabase,
) : InstantTransactionInputDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfInstantTransactionInput: EntityInsertAdapter<InstantTransactionInput>
  init {
    this.__db = __db
    this.__insertAdapterOfInstantTransactionInput = object :
        EntityInsertAdapter<InstantTransactionInput>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `InstantTransactionInput` (`txHash`,`inputTxHash`,`inputTxOutputIndex`,`timeCreated`,`voteCount`,`blockHeight`) VALUES (?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: InstantTransactionInput) {
        statement.bindBlob(1, entity.txHash)
        statement.bindBlob(2, entity.inputTxHash)
        statement.bindLong(3, entity.inputTxOutputIndex)
        statement.bindLong(4, entity.timeCreated)
        statement.bindLong(5, entity.voteCount.toLong())
        val _tmpBlockHeight: Int? = entity.blockHeight
        if (_tmpBlockHeight == null) {
          statement.bindNull(6)
        } else {
          statement.bindLong(6, _tmpBlockHeight.toLong())
        }
      }
    }
  }

  public override fun insert(transaction: InstantTransactionInput): Unit = performBlocking(__db,
      false, true) { _connection ->
    __insertAdapterOfInstantTransactionInput.insert(_connection, transaction)
  }

  public override fun getByTx(txHash: ByteArray): List<InstantTransactionInput> {
    val _sql: String = "SELECT * FROM InstantTransactionInput WHERE txHash = ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindBlob(_argIndex, txHash)
        val _columnIndexOfTxHash: Int = getColumnIndexOrThrow(_stmt, "txHash")
        val _columnIndexOfInputTxHash: Int = getColumnIndexOrThrow(_stmt, "inputTxHash")
        val _columnIndexOfInputTxOutputIndex: Int = getColumnIndexOrThrow(_stmt,
            "inputTxOutputIndex")
        val _columnIndexOfTimeCreated: Int = getColumnIndexOrThrow(_stmt, "timeCreated")
        val _columnIndexOfVoteCount: Int = getColumnIndexOrThrow(_stmt, "voteCount")
        val _columnIndexOfBlockHeight: Int = getColumnIndexOrThrow(_stmt, "blockHeight")
        val _result: MutableList<InstantTransactionInput> = mutableListOf()
        while (_stmt.step()) {
          val _item: InstantTransactionInput
          val _tmpTxHash: ByteArray
          _tmpTxHash = _stmt.getBlob(_columnIndexOfTxHash)
          val _tmpInputTxHash: ByteArray
          _tmpInputTxHash = _stmt.getBlob(_columnIndexOfInputTxHash)
          val _tmpInputTxOutputIndex: Long
          _tmpInputTxOutputIndex = _stmt.getLong(_columnIndexOfInputTxOutputIndex)
          val _tmpTimeCreated: Long
          _tmpTimeCreated = _stmt.getLong(_columnIndexOfTimeCreated)
          val _tmpVoteCount: Int
          _tmpVoteCount = _stmt.getLong(_columnIndexOfVoteCount).toInt()
          val _tmpBlockHeight: Int?
          if (_stmt.isNull(_columnIndexOfBlockHeight)) {
            _tmpBlockHeight = null
          } else {
            _tmpBlockHeight = _stmt.getLong(_columnIndexOfBlockHeight).toInt()
          }
          _item =
              InstantTransactionInput(_tmpTxHash,_tmpInputTxHash,_tmpInputTxOutputIndex,_tmpTimeCreated,_tmpVoteCount,_tmpBlockHeight)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun deleteByTx(txHash: ByteArray) {
    val _sql: String = "DELETE FROM InstantTransactionInput WHERE txHash = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindBlob(_argIndex, txHash)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
