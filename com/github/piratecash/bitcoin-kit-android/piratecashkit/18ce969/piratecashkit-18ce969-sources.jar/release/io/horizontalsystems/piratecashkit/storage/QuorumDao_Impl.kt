package io.horizontalsystems.piratecashkit.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.piratecashkit.models.Quorum
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class QuorumDao_Impl(
  __db: RoomDatabase,
) : QuorumDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfQuorum: EntityInsertAdapter<Quorum>
  init {
    this.__db = __db
    this.__insertAdapterOfQuorum = object : EntityInsertAdapter<Quorum>() {
      protected override fun createQuery(): String =
          "INSERT OR ABORT INTO `Quorum` (`hash`,`version`,`type`,`quorumHash`,`quorumIndex`,`signers`,`validMembers`,`quorumPublicKey`,`quorumVvecHash`,`quorumSig`,`sig`) VALUES (?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Quorum) {
        statement.bindBlob(1, entity.hash)
        statement.bindLong(2, entity.version.toLong())
        statement.bindLong(3, entity.type.toLong())
        statement.bindBlob(4, entity.quorumHash)
        val _tmpQuorumIndex: Int? = entity.quorumIndex
        if (_tmpQuorumIndex == null) {
          statement.bindNull(5)
        } else {
          statement.bindLong(5, _tmpQuorumIndex.toLong())
        }
        statement.bindBlob(6, entity.signers)
        statement.bindBlob(7, entity.validMembers)
        statement.bindBlob(8, entity.quorumPublicKey)
        statement.bindBlob(9, entity.quorumVvecHash)
        statement.bindBlob(10, entity.quorumSig)
        statement.bindBlob(11, entity.sig)
      }
    }
  }

  public override fun insertAll(masternodes: List<Quorum>): Unit = performBlocking(__db, false,
      true) { _connection ->
    __insertAdapterOfQuorum.insert(_connection, masternodes)
  }

  public override fun getAll(): List<Quorum> {
    val _sql: String = "SELECT * FROM Quorum"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfVersion: Int = getColumnIndexOrThrow(_stmt, "version")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfQuorumHash: Int = getColumnIndexOrThrow(_stmt, "quorumHash")
        val _columnIndexOfQuorumIndex: Int = getColumnIndexOrThrow(_stmt, "quorumIndex")
        val _columnIndexOfSigners: Int = getColumnIndexOrThrow(_stmt, "signers")
        val _columnIndexOfValidMembers: Int = getColumnIndexOrThrow(_stmt, "validMembers")
        val _columnIndexOfQuorumPublicKey: Int = getColumnIndexOrThrow(_stmt, "quorumPublicKey")
        val _columnIndexOfQuorumVvecHash: Int = getColumnIndexOrThrow(_stmt, "quorumVvecHash")
        val _columnIndexOfQuorumSig: Int = getColumnIndexOrThrow(_stmt, "quorumSig")
        val _columnIndexOfSig: Int = getColumnIndexOrThrow(_stmt, "sig")
        val _result: MutableList<Quorum> = mutableListOf()
        while (_stmt.step()) {
          val _item: Quorum
          _item = Quorum()
          _item.hash = _stmt.getBlob(_columnIndexOfHash)
          _item.version = _stmt.getLong(_columnIndexOfVersion).toInt()
          _item.type = _stmt.getLong(_columnIndexOfType).toInt()
          _item.quorumHash = _stmt.getBlob(_columnIndexOfQuorumHash)
          if (_stmt.isNull(_columnIndexOfQuorumIndex)) {
            _item.quorumIndex = null
          } else {
            _item.quorumIndex = _stmt.getLong(_columnIndexOfQuorumIndex).toInt()
          }
          _item.signers = _stmt.getBlob(_columnIndexOfSigners)
          _item.validMembers = _stmt.getBlob(_columnIndexOfValidMembers)
          _item.quorumPublicKey = _stmt.getBlob(_columnIndexOfQuorumPublicKey)
          _item.quorumVvecHash = _stmt.getBlob(_columnIndexOfQuorumVvecHash)
          _item.quorumSig = _stmt.getBlob(_columnIndexOfQuorumSig)
          _item.sig = _stmt.getBlob(_columnIndexOfSig)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getByType(type: Int): List<Quorum> {
    val _sql: String = "SELECT * FROM Quorum WHERE type = ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, type.toLong())
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfVersion: Int = getColumnIndexOrThrow(_stmt, "version")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfQuorumHash: Int = getColumnIndexOrThrow(_stmt, "quorumHash")
        val _columnIndexOfQuorumIndex: Int = getColumnIndexOrThrow(_stmt, "quorumIndex")
        val _columnIndexOfSigners: Int = getColumnIndexOrThrow(_stmt, "signers")
        val _columnIndexOfValidMembers: Int = getColumnIndexOrThrow(_stmt, "validMembers")
        val _columnIndexOfQuorumPublicKey: Int = getColumnIndexOrThrow(_stmt, "quorumPublicKey")
        val _columnIndexOfQuorumVvecHash: Int = getColumnIndexOrThrow(_stmt, "quorumVvecHash")
        val _columnIndexOfQuorumSig: Int = getColumnIndexOrThrow(_stmt, "quorumSig")
        val _columnIndexOfSig: Int = getColumnIndexOrThrow(_stmt, "sig")
        val _result: MutableList<Quorum> = mutableListOf()
        while (_stmt.step()) {
          val _item: Quorum
          _item = Quorum()
          _item.hash = _stmt.getBlob(_columnIndexOfHash)
          _item.version = _stmt.getLong(_columnIndexOfVersion).toInt()
          _item.type = _stmt.getLong(_columnIndexOfType).toInt()
          _item.quorumHash = _stmt.getBlob(_columnIndexOfQuorumHash)
          if (_stmt.isNull(_columnIndexOfQuorumIndex)) {
            _item.quorumIndex = null
          } else {
            _item.quorumIndex = _stmt.getLong(_columnIndexOfQuorumIndex).toInt()
          }
          _item.signers = _stmt.getBlob(_columnIndexOfSigners)
          _item.validMembers = _stmt.getBlob(_columnIndexOfValidMembers)
          _item.quorumPublicKey = _stmt.getBlob(_columnIndexOfQuorumPublicKey)
          _item.quorumVvecHash = _stmt.getBlob(_columnIndexOfQuorumVvecHash)
          _item.quorumSig = _stmt.getBlob(_columnIndexOfQuorumSig)
          _item.sig = _stmt.getBlob(_columnIndexOfSig)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun clearAll() {
    val _sql: String = "DELETE FROM Quorum"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
