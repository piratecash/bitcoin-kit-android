package io.horizontalsystems.piratecashkit.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.piratecashkit.models.InstantTransactionHash
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class InstantTransactionHashDao_Impl(
  __db: RoomDatabase,
) : InstantTransactionHashDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfInstantTransactionHash: EntityInsertAdapter<InstantTransactionHash>
  init {
    this.__db = __db
    this.__insertAdapterOfInstantTransactionHash = object :
        EntityInsertAdapter<InstantTransactionHash>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `InstantTransactionHash` (`txHash`) VALUES (?)"

      protected override fun bind(statement: SQLiteStatement, entity: InstantTransactionHash) {
        statement.bindBlob(1, entity.txHash)
      }
    }
  }

  public override fun insert(instantTransactionHash: InstantTransactionHash): Unit =
      performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfInstantTransactionHash.insert(_connection, instantTransactionHash)
  }

  public override fun getAll(): List<InstantTransactionHash> {
    val _sql: String = "SELECT * FROM InstantTransactionHash"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfTxHash: Int = getColumnIndexOrThrow(_stmt, "txHash")
        val _result: MutableList<InstantTransactionHash> = mutableListOf()
        while (_stmt.step()) {
          val _item: InstantTransactionHash
          val _tmpTxHash: ByteArray
          _tmpTxHash = _stmt.getBlob(_columnIndexOfTxHash)
          _item = InstantTransactionHash(_tmpTxHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
