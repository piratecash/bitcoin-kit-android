package io.horizontalsystems.piratecashkit

object PirateCashKitErrors {
    sealed class LockVoteValidation : Exception() {
        class MasternodeNotFound : LockVoteValidation()
        class MasternodeNotInTop : LockVoteValidation()
        class TxInputNotFound : LockVoteValidation()
        class SignatureNotValid : LockVoteValidation()
    }

    sealed class ISLockValidation : Exception() {
        class InvalidStructure : ISLockValidation()
        class QuorumNotFound : ISLockValidation()
    }
}
