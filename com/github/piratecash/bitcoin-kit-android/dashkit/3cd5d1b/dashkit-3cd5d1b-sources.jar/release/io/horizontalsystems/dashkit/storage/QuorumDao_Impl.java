package io.horizontalsystems.dashkit.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.dashkit.models.Quorum;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class QuorumDao_Impl implements QuorumDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Quorum> __insertionAdapterOfQuorum;

  private final SharedSQLiteStatement __preparedStmtOfClearAll;

  public QuorumDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfQuorum = new EntityInsertionAdapter<Quorum>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR ABORT INTO `Quorum` (`hash`,`version`,`type`,`quorumHash`,`quorumIndex`,`signers`,`validMembers`,`quorumPublicKey`,`quorumVvecHash`,`quorumSig`,`sig`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Quorum entity) {
        statement.bindBlob(1, entity.getHash());
        statement.bindLong(2, entity.getVersion());
        statement.bindLong(3, entity.getType());
        statement.bindBlob(4, entity.getQuorumHash());
        if (entity.getQuorumIndex() == null) {
          statement.bindNull(5);
        } else {
          statement.bindLong(5, entity.getQuorumIndex());
        }
        statement.bindBlob(6, entity.getSigners());
        statement.bindBlob(7, entity.getValidMembers());
        statement.bindBlob(8, entity.getQuorumPublicKey());
        statement.bindBlob(9, entity.getQuorumVvecHash());
        statement.bindBlob(10, entity.getQuorumSig());
        statement.bindBlob(11, entity.getSig());
      }
    };
    this.__preparedStmtOfClearAll = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM Quorum";
        return _query;
      }
    };
  }

  @Override
  public void insertAll(final List<Quorum> masternodes) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfQuorum.insert(masternodes);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void clearAll() {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfClearAll.acquire();
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfClearAll.release(_stmt);
    }
  }

  @Override
  public List<Quorum> getAll() {
    final String _sql = "SELECT * FROM Quorum";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final int _cursorIndexOfQuorumHash = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumHash");
      final int _cursorIndexOfQuorumIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumIndex");
      final int _cursorIndexOfSigners = CursorUtil.getColumnIndexOrThrow(_cursor, "signers");
      final int _cursorIndexOfValidMembers = CursorUtil.getColumnIndexOrThrow(_cursor, "validMembers");
      final int _cursorIndexOfQuorumPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumPublicKey");
      final int _cursorIndexOfQuorumVvecHash = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumVvecHash");
      final int _cursorIndexOfQuorumSig = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumSig");
      final int _cursorIndexOfSig = CursorUtil.getColumnIndexOrThrow(_cursor, "sig");
      final List<Quorum> _result = new ArrayList<Quorum>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Quorum _item;
        _item = new Quorum();
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _item.setHash(_tmpHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _item.setType(_tmpType);
        final byte[] _tmpQuorumHash;
        _tmpQuorumHash = _cursor.getBlob(_cursorIndexOfQuorumHash);
        _item.setQuorumHash(_tmpQuorumHash);
        final Integer _tmpQuorumIndex;
        if (_cursor.isNull(_cursorIndexOfQuorumIndex)) {
          _tmpQuorumIndex = null;
        } else {
          _tmpQuorumIndex = _cursor.getInt(_cursorIndexOfQuorumIndex);
        }
        _item.setQuorumIndex(_tmpQuorumIndex);
        final byte[] _tmpSigners;
        _tmpSigners = _cursor.getBlob(_cursorIndexOfSigners);
        _item.setSigners(_tmpSigners);
        final byte[] _tmpValidMembers;
        _tmpValidMembers = _cursor.getBlob(_cursorIndexOfValidMembers);
        _item.setValidMembers(_tmpValidMembers);
        final byte[] _tmpQuorumPublicKey;
        _tmpQuorumPublicKey = _cursor.getBlob(_cursorIndexOfQuorumPublicKey);
        _item.setQuorumPublicKey(_tmpQuorumPublicKey);
        final byte[] _tmpQuorumVvecHash;
        _tmpQuorumVvecHash = _cursor.getBlob(_cursorIndexOfQuorumVvecHash);
        _item.setQuorumVvecHash(_tmpQuorumVvecHash);
        final byte[] _tmpQuorumSig;
        _tmpQuorumSig = _cursor.getBlob(_cursorIndexOfQuorumSig);
        _item.setQuorumSig(_tmpQuorumSig);
        final byte[] _tmpSig;
        _tmpSig = _cursor.getBlob(_cursorIndexOfSig);
        _item.setSig(_tmpSig);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Quorum> getByType(final int type) {
    final String _sql = "SELECT * FROM Quorum WHERE type = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, type);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final int _cursorIndexOfQuorumHash = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumHash");
      final int _cursorIndexOfQuorumIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumIndex");
      final int _cursorIndexOfSigners = CursorUtil.getColumnIndexOrThrow(_cursor, "signers");
      final int _cursorIndexOfValidMembers = CursorUtil.getColumnIndexOrThrow(_cursor, "validMembers");
      final int _cursorIndexOfQuorumPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumPublicKey");
      final int _cursorIndexOfQuorumVvecHash = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumVvecHash");
      final int _cursorIndexOfQuorumSig = CursorUtil.getColumnIndexOrThrow(_cursor, "quorumSig");
      final int _cursorIndexOfSig = CursorUtil.getColumnIndexOrThrow(_cursor, "sig");
      final List<Quorum> _result = new ArrayList<Quorum>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Quorum _item;
        _item = new Quorum();
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _item.setHash(_tmpHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _item.setType(_tmpType);
        final byte[] _tmpQuorumHash;
        _tmpQuorumHash = _cursor.getBlob(_cursorIndexOfQuorumHash);
        _item.setQuorumHash(_tmpQuorumHash);
        final Integer _tmpQuorumIndex;
        if (_cursor.isNull(_cursorIndexOfQuorumIndex)) {
          _tmpQuorumIndex = null;
        } else {
          _tmpQuorumIndex = _cursor.getInt(_cursorIndexOfQuorumIndex);
        }
        _item.setQuorumIndex(_tmpQuorumIndex);
        final byte[] _tmpSigners;
        _tmpSigners = _cursor.getBlob(_cursorIndexOfSigners);
        _item.setSigners(_tmpSigners);
        final byte[] _tmpValidMembers;
        _tmpValidMembers = _cursor.getBlob(_cursorIndexOfValidMembers);
        _item.setValidMembers(_tmpValidMembers);
        final byte[] _tmpQuorumPublicKey;
        _tmpQuorumPublicKey = _cursor.getBlob(_cursorIndexOfQuorumPublicKey);
        _item.setQuorumPublicKey(_tmpQuorumPublicKey);
        final byte[] _tmpQuorumVvecHash;
        _tmpQuorumVvecHash = _cursor.getBlob(_cursorIndexOfQuorumVvecHash);
        _item.setQuorumVvecHash(_tmpQuorumVvecHash);
        final byte[] _tmpQuorumSig;
        _tmpQuorumSig = _cursor.getBlob(_cursorIndexOfQuorumSig);
        _item.setQuorumSig(_tmpQuorumSig);
        final byte[] _tmpSig;
        _tmpSig = _cursor.getBlob(_cursorIndexOfSig);
        _item.setSig(_tmpSig);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
