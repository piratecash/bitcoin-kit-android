package io.horizontalsystems.dashkit.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.dashkit.models.InstantTransactionInput;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class InstantTransactionInputDao_Impl implements InstantTransactionInputDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<InstantTransactionInput> __insertionAdapterOfInstantTransactionInput;

  private final SharedSQLiteStatement __preparedStmtOfDeleteByTx;

  public InstantTransactionInputDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfInstantTransactionInput = new EntityInsertionAdapter<InstantTransactionInput>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `InstantTransactionInput` (`txHash`,`inputTxHash`,`inputTxOutputIndex`,`timeCreated`,`voteCount`,`blockHeight`) VALUES (?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final InstantTransactionInput entity) {
        statement.bindBlob(1, entity.getTxHash());
        statement.bindBlob(2, entity.getInputTxHash());
        statement.bindLong(3, entity.getInputTxOutputIndex());
        statement.bindLong(4, entity.getTimeCreated());
        statement.bindLong(5, entity.getVoteCount());
        if (entity.getBlockHeight() == null) {
          statement.bindNull(6);
        } else {
          statement.bindLong(6, entity.getBlockHeight());
        }
      }
    };
    this.__preparedStmtOfDeleteByTx = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM InstantTransactionInput WHERE txHash = ?";
        return _query;
      }
    };
  }

  @Override
  public void insert(final InstantTransactionInput transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfInstantTransactionInput.insert(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteByTx(final byte[] txHash) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteByTx.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, txHash);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDeleteByTx.release(_stmt);
    }
  }

  @Override
  public List<InstantTransactionInput> getByTx(final byte[] txHash) {
    final String _sql = "SELECT * FROM InstantTransactionInput WHERE txHash = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, txHash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "txHash");
      final int _cursorIndexOfInputTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "inputTxHash");
      final int _cursorIndexOfInputTxOutputIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "inputTxOutputIndex");
      final int _cursorIndexOfTimeCreated = CursorUtil.getColumnIndexOrThrow(_cursor, "timeCreated");
      final int _cursorIndexOfVoteCount = CursorUtil.getColumnIndexOrThrow(_cursor, "voteCount");
      final int _cursorIndexOfBlockHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHeight");
      final List<InstantTransactionInput> _result = new ArrayList<InstantTransactionInput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final InstantTransactionInput _item;
        final byte[] _tmpTxHash;
        _tmpTxHash = _cursor.getBlob(_cursorIndexOfTxHash);
        final byte[] _tmpInputTxHash;
        _tmpInputTxHash = _cursor.getBlob(_cursorIndexOfInputTxHash);
        final long _tmpInputTxOutputIndex;
        _tmpInputTxOutputIndex = _cursor.getLong(_cursorIndexOfInputTxOutputIndex);
        final long _tmpTimeCreated;
        _tmpTimeCreated = _cursor.getLong(_cursorIndexOfTimeCreated);
        final int _tmpVoteCount;
        _tmpVoteCount = _cursor.getInt(_cursorIndexOfVoteCount);
        final Integer _tmpBlockHeight;
        if (_cursor.isNull(_cursorIndexOfBlockHeight)) {
          _tmpBlockHeight = null;
        } else {
          _tmpBlockHeight = _cursor.getInt(_cursorIndexOfBlockHeight);
        }
        _item = new InstantTransactionInput(_tmpTxHash,_tmpInputTxHash,_tmpInputTxOutputIndex,_tmpTimeCreated,_tmpVoteCount,_tmpBlockHeight);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
