package io.horizontalsystems.dashkit.storage;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class DashKitDatabase_Impl extends DashKitDatabase {
  private volatile InstantTransactionHashDao _instantTransactionHashDao;

  private volatile MasternodeDao _masternodeDao;

  private volatile QuorumDao _quorumDao;

  private volatile MasternodeListStateDao _masternodeListStateDao;

  private volatile InstantTransactionInputDao _instantTransactionInputDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(6) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `Masternode` (`nVersion` INTEGER NOT NULL, `proRegTxHash` BLOB NOT NULL, `confirmedHash` BLOB NOT NULL, `ipAddress` BLOB NOT NULL, `port` INTEGER NOT NULL, `pubKeyOperator` BLOB NOT NULL, `keyIDVoting` BLOB NOT NULL, `isValid` INTEGER NOT NULL, `type` INTEGER, `platformHTTPPort` INTEGER, `platformNodeID` BLOB, `hash` BLOB NOT NULL, PRIMARY KEY(`proRegTxHash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `Quorum` (`hash` BLOB NOT NULL, `version` INTEGER NOT NULL, `type` INTEGER NOT NULL, `quorumHash` BLOB NOT NULL, `quorumIndex` INTEGER, `signers` BLOB NOT NULL, `validMembers` BLOB NOT NULL, `quorumPublicKey` BLOB NOT NULL, `quorumVvecHash` BLOB NOT NULL, `quorumSig` BLOB NOT NULL, `sig` BLOB NOT NULL, PRIMARY KEY(`hash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `MasternodeListState` (`baseBlockHash` BLOB NOT NULL, `primaryKey` TEXT NOT NULL, PRIMARY KEY(`primaryKey`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `InstantTransactionInput` (`txHash` BLOB NOT NULL, `inputTxHash` BLOB NOT NULL, `inputTxOutputIndex` INTEGER NOT NULL, `timeCreated` INTEGER NOT NULL, `voteCount` INTEGER NOT NULL, `blockHeight` INTEGER, PRIMARY KEY(`txHash`, `inputTxHash`, `inputTxOutputIndex`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `InstantTransactionHash` (`txHash` BLOB NOT NULL, PRIMARY KEY(`txHash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '4c117a143c950e6987d3bfbaa26b8cba')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `Masternode`");
        db.execSQL("DROP TABLE IF EXISTS `Quorum`");
        db.execSQL("DROP TABLE IF EXISTS `MasternodeListState`");
        db.execSQL("DROP TABLE IF EXISTS `InstantTransactionInput`");
        db.execSQL("DROP TABLE IF EXISTS `InstantTransactionHash`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsMasternode = new HashMap<String, TableInfo.Column>(12);
        _columnsMasternode.put("nVersion", new TableInfo.Column("nVersion", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("proRegTxHash", new TableInfo.Column("proRegTxHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("confirmedHash", new TableInfo.Column("confirmedHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("ipAddress", new TableInfo.Column("ipAddress", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("port", new TableInfo.Column("port", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("pubKeyOperator", new TableInfo.Column("pubKeyOperator", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("keyIDVoting", new TableInfo.Column("keyIDVoting", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("isValid", new TableInfo.Column("isValid", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("type", new TableInfo.Column("type", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("platformHTTPPort", new TableInfo.Column("platformHTTPPort", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("platformNodeID", new TableInfo.Column("platformNodeID", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternode.put("hash", new TableInfo.Column("hash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysMasternode = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesMasternode = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoMasternode = new TableInfo("Masternode", _columnsMasternode, _foreignKeysMasternode, _indicesMasternode);
        final TableInfo _existingMasternode = TableInfo.read(db, "Masternode");
        if (!_infoMasternode.equals(_existingMasternode)) {
          return new RoomOpenHelper.ValidationResult(false, "Masternode(io.horizontalsystems.dashkit.models.Masternode).\n"
                  + " Expected:\n" + _infoMasternode + "\n"
                  + " Found:\n" + _existingMasternode);
        }
        final HashMap<String, TableInfo.Column> _columnsQuorum = new HashMap<String, TableInfo.Column>(11);
        _columnsQuorum.put("hash", new TableInfo.Column("hash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("version", new TableInfo.Column("version", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("type", new TableInfo.Column("type", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("quorumHash", new TableInfo.Column("quorumHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("quorumIndex", new TableInfo.Column("quorumIndex", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("signers", new TableInfo.Column("signers", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("validMembers", new TableInfo.Column("validMembers", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("quorumPublicKey", new TableInfo.Column("quorumPublicKey", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("quorumVvecHash", new TableInfo.Column("quorumVvecHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("quorumSig", new TableInfo.Column("quorumSig", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsQuorum.put("sig", new TableInfo.Column("sig", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysQuorum = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesQuorum = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoQuorum = new TableInfo("Quorum", _columnsQuorum, _foreignKeysQuorum, _indicesQuorum);
        final TableInfo _existingQuorum = TableInfo.read(db, "Quorum");
        if (!_infoQuorum.equals(_existingQuorum)) {
          return new RoomOpenHelper.ValidationResult(false, "Quorum(io.horizontalsystems.dashkit.models.Quorum).\n"
                  + " Expected:\n" + _infoQuorum + "\n"
                  + " Found:\n" + _existingQuorum);
        }
        final HashMap<String, TableInfo.Column> _columnsMasternodeListState = new HashMap<String, TableInfo.Column>(2);
        _columnsMasternodeListState.put("baseBlockHash", new TableInfo.Column("baseBlockHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMasternodeListState.put("primaryKey", new TableInfo.Column("primaryKey", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysMasternodeListState = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesMasternodeListState = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoMasternodeListState = new TableInfo("MasternodeListState", _columnsMasternodeListState, _foreignKeysMasternodeListState, _indicesMasternodeListState);
        final TableInfo _existingMasternodeListState = TableInfo.read(db, "MasternodeListState");
        if (!_infoMasternodeListState.equals(_existingMasternodeListState)) {
          return new RoomOpenHelper.ValidationResult(false, "MasternodeListState(io.horizontalsystems.dashkit.models.MasternodeListState).\n"
                  + " Expected:\n" + _infoMasternodeListState + "\n"
                  + " Found:\n" + _existingMasternodeListState);
        }
        final HashMap<String, TableInfo.Column> _columnsInstantTransactionInput = new HashMap<String, TableInfo.Column>(6);
        _columnsInstantTransactionInput.put("txHash", new TableInfo.Column("txHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInstantTransactionInput.put("inputTxHash", new TableInfo.Column("inputTxHash", "BLOB", true, 2, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInstantTransactionInput.put("inputTxOutputIndex", new TableInfo.Column("inputTxOutputIndex", "INTEGER", true, 3, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInstantTransactionInput.put("timeCreated", new TableInfo.Column("timeCreated", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInstantTransactionInput.put("voteCount", new TableInfo.Column("voteCount", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInstantTransactionInput.put("blockHeight", new TableInfo.Column("blockHeight", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysInstantTransactionInput = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesInstantTransactionInput = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoInstantTransactionInput = new TableInfo("InstantTransactionInput", _columnsInstantTransactionInput, _foreignKeysInstantTransactionInput, _indicesInstantTransactionInput);
        final TableInfo _existingInstantTransactionInput = TableInfo.read(db, "InstantTransactionInput");
        if (!_infoInstantTransactionInput.equals(_existingInstantTransactionInput)) {
          return new RoomOpenHelper.ValidationResult(false, "InstantTransactionInput(io.horizontalsystems.dashkit.models.InstantTransactionInput).\n"
                  + " Expected:\n" + _infoInstantTransactionInput + "\n"
                  + " Found:\n" + _existingInstantTransactionInput);
        }
        final HashMap<String, TableInfo.Column> _columnsInstantTransactionHash = new HashMap<String, TableInfo.Column>(1);
        _columnsInstantTransactionHash.put("txHash", new TableInfo.Column("txHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysInstantTransactionHash = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesInstantTransactionHash = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoInstantTransactionHash = new TableInfo("InstantTransactionHash", _columnsInstantTransactionHash, _foreignKeysInstantTransactionHash, _indicesInstantTransactionHash);
        final TableInfo _existingInstantTransactionHash = TableInfo.read(db, "InstantTransactionHash");
        if (!_infoInstantTransactionHash.equals(_existingInstantTransactionHash)) {
          return new RoomOpenHelper.ValidationResult(false, "InstantTransactionHash(io.horizontalsystems.dashkit.models.InstantTransactionHash).\n"
                  + " Expected:\n" + _infoInstantTransactionHash + "\n"
                  + " Found:\n" + _existingInstantTransactionHash);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "4c117a143c950e6987d3bfbaa26b8cba", "e96e255414af00d8e6357c8c304d87c8");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "Masternode","Quorum","MasternodeListState","InstantTransactionInput","InstantTransactionHash");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    try {
      super.beginTransaction();
      _db.execSQL("DELETE FROM `Masternode`");
      _db.execSQL("DELETE FROM `Quorum`");
      _db.execSQL("DELETE FROM `MasternodeListState`");
      _db.execSQL("DELETE FROM `InstantTransactionInput`");
      _db.execSQL("DELETE FROM `InstantTransactionHash`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(InstantTransactionHashDao.class, InstantTransactionHashDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(MasternodeDao.class, MasternodeDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(QuorumDao.class, QuorumDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(MasternodeListStateDao.class, MasternodeListStateDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(InstantTransactionInputDao.class, InstantTransactionInputDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    return _autoMigrations;
  }

  @Override
  public InstantTransactionHashDao getInstantTransactionHashDao() {
    if (_instantTransactionHashDao != null) {
      return _instantTransactionHashDao;
    } else {
      synchronized(this) {
        if(_instantTransactionHashDao == null) {
          _instantTransactionHashDao = new InstantTransactionHashDao_Impl(this);
        }
        return _instantTransactionHashDao;
      }
    }
  }

  @Override
  public MasternodeDao getMasternodeDao() {
    if (_masternodeDao != null) {
      return _masternodeDao;
    } else {
      synchronized(this) {
        if(_masternodeDao == null) {
          _masternodeDao = new MasternodeDao_Impl(this);
        }
        return _masternodeDao;
      }
    }
  }

  @Override
  public QuorumDao getQuorumDao() {
    if (_quorumDao != null) {
      return _quorumDao;
    } else {
      synchronized(this) {
        if(_quorumDao == null) {
          _quorumDao = new QuorumDao_Impl(this);
        }
        return _quorumDao;
      }
    }
  }

  @Override
  public MasternodeListStateDao getMasternodeListStateDao() {
    if (_masternodeListStateDao != null) {
      return _masternodeListStateDao;
    } else {
      synchronized(this) {
        if(_masternodeListStateDao == null) {
          _masternodeListStateDao = new MasternodeListStateDao_Impl(this);
        }
        return _masternodeListStateDao;
      }
    }
  }

  @Override
  public InstantTransactionInputDao getInstantTransactionInputDao() {
    if (_instantTransactionInputDao != null) {
      return _instantTransactionInputDao;
    } else {
      synchronized(this) {
        if(_instantTransactionInputDao == null) {
          _instantTransactionInputDao = new InstantTransactionInputDao_Impl(this);
        }
        return _instantTransactionInputDao;
      }
    }
  }
}
