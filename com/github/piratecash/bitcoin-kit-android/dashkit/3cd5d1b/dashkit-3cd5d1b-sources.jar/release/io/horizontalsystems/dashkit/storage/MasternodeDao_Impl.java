package io.horizontalsystems.dashkit.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.dashkit.models.Masternode;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class MasternodeDao_Impl implements MasternodeDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Masternode> __insertionAdapterOfMasternode;

  private final SharedSQLiteStatement __preparedStmtOfClearAll;

  public MasternodeDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfMasternode = new EntityInsertionAdapter<Masternode>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `Masternode` (`nVersion`,`proRegTxHash`,`confirmedHash`,`ipAddress`,`port`,`pubKeyOperator`,`keyIDVoting`,`isValid`,`type`,`platformHTTPPort`,`platformNodeID`,`hash`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Masternode entity) {
        statement.bindLong(1, entity.getNVersion());
        statement.bindBlob(2, entity.getProRegTxHash());
        statement.bindBlob(3, entity.getConfirmedHash());
        statement.bindBlob(4, entity.getIpAddress());
        statement.bindLong(5, entity.getPort());
        statement.bindBlob(6, entity.getPubKeyOperator());
        statement.bindBlob(7, entity.getKeyIDVoting());
        final int _tmp = entity.isValid() ? 1 : 0;
        statement.bindLong(8, _tmp);
        if (entity.getType() == null) {
          statement.bindNull(9);
        } else {
          statement.bindLong(9, entity.getType());
        }
        if (entity.getPlatformHTTPPort() == null) {
          statement.bindNull(10);
        } else {
          statement.bindLong(10, entity.getPlatformHTTPPort());
        }
        if (entity.getPlatformNodeID() == null) {
          statement.bindNull(11);
        } else {
          statement.bindBlob(11, entity.getPlatformNodeID());
        }
        statement.bindBlob(12, entity.getHash());
      }
    };
    this.__preparedStmtOfClearAll = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM Masternode";
        return _query;
      }
    };
  }

  @Override
  public void insertAll(final List<Masternode> masternodes) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfMasternode.insert(masternodes);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void clearAll() {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfClearAll.acquire();
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfClearAll.release(_stmt);
    }
  }

  @Override
  public List<Masternode> getAll() {
    final String _sql = "SELECT * FROM Masternode";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfNVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "nVersion");
      final int _cursorIndexOfProRegTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "proRegTxHash");
      final int _cursorIndexOfConfirmedHash = CursorUtil.getColumnIndexOrThrow(_cursor, "confirmedHash");
      final int _cursorIndexOfIpAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "ipAddress");
      final int _cursorIndexOfPort = CursorUtil.getColumnIndexOrThrow(_cursor, "port");
      final int _cursorIndexOfPubKeyOperator = CursorUtil.getColumnIndexOrThrow(_cursor, "pubKeyOperator");
      final int _cursorIndexOfKeyIDVoting = CursorUtil.getColumnIndexOrThrow(_cursor, "keyIDVoting");
      final int _cursorIndexOfIsValid = CursorUtil.getColumnIndexOrThrow(_cursor, "isValid");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final int _cursorIndexOfPlatformHTTPPort = CursorUtil.getColumnIndexOrThrow(_cursor, "platformHTTPPort");
      final int _cursorIndexOfPlatformNodeID = CursorUtil.getColumnIndexOrThrow(_cursor, "platformNodeID");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final List<Masternode> _result = new ArrayList<Masternode>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Masternode _item;
        _item = new Masternode();
        final int _tmpNVersion;
        _tmpNVersion = _cursor.getInt(_cursorIndexOfNVersion);
        _item.setNVersion(_tmpNVersion);
        final byte[] _tmpProRegTxHash;
        _tmpProRegTxHash = _cursor.getBlob(_cursorIndexOfProRegTxHash);
        _item.setProRegTxHash(_tmpProRegTxHash);
        final byte[] _tmpConfirmedHash;
        _tmpConfirmedHash = _cursor.getBlob(_cursorIndexOfConfirmedHash);
        _item.setConfirmedHash(_tmpConfirmedHash);
        final byte[] _tmpIpAddress;
        _tmpIpAddress = _cursor.getBlob(_cursorIndexOfIpAddress);
        _item.setIpAddress(_tmpIpAddress);
        final int _tmpPort;
        _tmpPort = _cursor.getInt(_cursorIndexOfPort);
        _item.setPort(_tmpPort);
        final byte[] _tmpPubKeyOperator;
        _tmpPubKeyOperator = _cursor.getBlob(_cursorIndexOfPubKeyOperator);
        _item.setPubKeyOperator(_tmpPubKeyOperator);
        final byte[] _tmpKeyIDVoting;
        _tmpKeyIDVoting = _cursor.getBlob(_cursorIndexOfKeyIDVoting);
        _item.setKeyIDVoting(_tmpKeyIDVoting);
        final boolean _tmpIsValid;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsValid);
        _tmpIsValid = _tmp != 0;
        _item.setValid(_tmpIsValid);
        final Integer _tmpType;
        if (_cursor.isNull(_cursorIndexOfType)) {
          _tmpType = null;
        } else {
          _tmpType = _cursor.getInt(_cursorIndexOfType);
        }
        _item.setType(_tmpType);
        final Integer _tmpPlatformHTTPPort;
        if (_cursor.isNull(_cursorIndexOfPlatformHTTPPort)) {
          _tmpPlatformHTTPPort = null;
        } else {
          _tmpPlatformHTTPPort = _cursor.getInt(_cursorIndexOfPlatformHTTPPort);
        }
        _item.setPlatformHTTPPort(_tmpPlatformHTTPPort);
        final byte[] _tmpPlatformNodeID;
        if (_cursor.isNull(_cursorIndexOfPlatformNodeID)) {
          _tmpPlatformNodeID = null;
        } else {
          _tmpPlatformNodeID = _cursor.getBlob(_cursorIndexOfPlatformNodeID);
        }
        _item.setPlatformNodeID(_tmpPlatformNodeID);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _item.setHash(_tmpHash);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
