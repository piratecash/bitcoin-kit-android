package io.horizontalsystems.bitcoincore.storage

import androidx.room.concurrent.AtomicInt
import androidx.sqlite.db.SimpleSQLiteQuery
import io.horizontalsystems.bitcoincore.core.IStorage
import io.horizontalsystems.bitcoincore.extensions.hexToByteArray
import io.horizontalsystems.bitcoincore.extensions.toHexString
import io.horizontalsystems.bitcoincore.models.Block
import io.horizontalsystems.bitcoincore.models.BlockHash
import io.horizontalsystems.bitcoincore.models.BlockHashPublicKey
import io.horizontalsystems.bitcoincore.models.BlockchainState
import io.horizontalsystems.bitcoincore.models.InvalidTransaction
import io.horizontalsystems.bitcoincore.models.OrphanBlock
import io.horizontalsystems.bitcoincore.models.PeerAddress
import io.horizontalsystems.bitcoincore.models.PublicKey
import io.horizontalsystems.bitcoincore.models.SentTransaction
import io.horizontalsystems.bitcoincore.models.Transaction
import io.horizontalsystems.bitcoincore.models.TransactionFilterType
import io.horizontalsystems.bitcoincore.models.TransactionInput
import io.horizontalsystems.bitcoincore.models.TransactionMetadata
import io.horizontalsystems.bitcoincore.models.TransactionOutput
import io.horizontalsystems.bitcoincore.serializers.BaseTransactionSerializer
import io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType
import java.math.BigInteger
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

open class Storage(protected open val store: CoreDatabase) : IStorage {

    private var transactionSerializer: BaseTransactionSerializer? = null
    private var discoveredPeers = AtomicInt(0)
    private val unreachedHosts = ConcurrentHashMap.newKeySet<String>()

    override fun getDiscoveredPeersCount()
        = discoveredPeers.get()

    override fun addUnreachedHosts(host: String) {
        unreachedHosts.add(host)
    }

    override fun getUnreachedHostCount()
        = unreachedHosts.size

    override fun setTransactionSerializer(transactionSerializer: BaseTransactionSerializer) {
        this.transactionSerializer = transactionSerializer
    }

    override fun downloadedTransactionsBestBlockHeight(): Int {
        val maxDownloadedHeight = store.block.getLastBlockWithTransactions()?.height ?: 0
        val maxDiscoveredHeight = store.blockHash.getLastBlockHashByHeight()?.height ?: 0
        return max(maxDownloadedHeight, maxDiscoveredHeight)
    }

    // RestoreState

    override val initialRestored: Boolean?
        get() = store.blockchainState.getState()?.initialRestored

    override fun setInitialRestored(isRestored: Boolean) {
        store.blockchainState.insert(BlockchainState(initialRestored = isRestored))
    }

    // PeerAddress

    override fun getLeastScoreFastestPeerAddressExcludingIps(ips: List<String>): PeerAddress? {
        return store.peerAddress.getLeastScoreFastest(ips)
    }

    override fun hasFreshPeerAddressesExcludingIps(ips: List<String>): Boolean {
        return store.peerAddress.hasFresh(ips)
    }

    override fun deletePeerAddress(ip: String) {
        store.peerAddress.delete(PeerAddress(ip))
    }

    override fun setPeerAddresses(list: List<PeerAddress>) {
        discoveredPeers.addAndGet(list.size)
        store.peerAddress.insertAll(list)
    }

    override fun markConnected(ip: String, time: Long) {
        store.peerAddress.setSuccessConnectionTime(time, ip)
    }

    // BlockHash

    override fun getBlockHashesSortedBySequenceAndHeight(limit: Int): List<BlockHash> {
        return store.blockHash.getBlockHashesSortedSequenceHeight(limit)
    }

    override fun hasBlockHash(headerHash: ByteArray): Boolean {
        return store.blockHash.exists(headerHash)
    }

    override fun getBlockHashHeaderHashes(): List<ByteArray> {
        return store.blockHash.allBlockHashes()
    }

    override fun getBlockHashHeaderHashes(except: List<ByteArray>): List<ByteArray> {
        return store.blockHash.allBlockHashes(except)
    }

    override fun getLastBlockHash(): BlockHash? {
        return store.blockHash.getLastBlockHash()
    }

    override fun getApiBlockHashesCount(): Int {
        return store.blockHash.getApiBlockHashesCount()
    }

    override fun getBlockchainBlockHashes(): List<BlockHash> {
        return store.blockHash.getBlockchainBlockHashes()
    }

    override fun deleteBlockHash(hash: ByteArray) {
        store.blockHash.delete(hash)
    }

    override fun addBlockHashes(hashes: List<BlockHash>) {
        store.blockHash.insertAll(hashes)
    }

    override fun addBockHashPublicKeys(blockHashPublicKeys: List<BlockHashPublicKey>) {
        store.blockHashPublicKey.insertAll(blockHashPublicKeys)
    }

    override fun getLastBlockchainBlockHash(): BlockHash? {
        return store.blockHash.getLastBlockchainBlockHash()
    }

    override fun deleteBlockchainBlockHashes() {
        store.blockHash.delete(height = 0)
    }

    // Block

    override fun getOrphanBlocks(): List<OrphanBlock> =
        store.orphanBlockDao.getOrphanBlocks()

    override fun getBlockByHeightStalePrioritized(height: Int): Block? {
        return store.block.getBlockByHeightStalePrioritized(height)
    }

    override fun getBlock(height: Int): Block? {
        return store.block.getBlockByHeight(height)
    }

    override fun getBlock(hashHash: ByteArray): Block? {
        return store.block.getBlockByHash(hashHash)
    }

    override fun getBlock(stale: Boolean, sortedHeight: String): Block? {
        return if (sortedHeight == "DESC") {
            store.block.getLast(stale)
        } else {
            store.block.getFirst(stale)
        }
    }

    override fun getOrphanChild(parentHash: ByteArray): OrphanBlock? {
        return store.orphanBlockDao.getOrphanChild(parentHash)
    }

    override fun addOrphanBlock(block: OrphanBlock) {
        store.orphanBlockDao.insert(block)
    }

    override fun getOrphanBlock(hashHash: ByteArray): OrphanBlock? {
        return store.orphanBlockDao.getOrphanBlockByHash(hashHash)
    }

    override fun deleteOrphanBlock(block: OrphanBlock) {
        store.orphanBlockDao.delete(block)
    }

    override fun getBlocks(stale: Boolean): List<Block> {
        return store.block.getBlocksByStale(stale)
    }

    override fun getBlocks(heightGreaterThan: Int, sortedBy: String, limit: Int): List<Block> {
        return store.block.getBlocks(heightGreaterThan, limit)
    }

    override fun getBlocks(heightGreaterOrEqualTo: Int, stale: Boolean): List<Block> {
        return store.block.getBlocks(heightGreaterOrEqualTo, stale)
    }

    override fun getBlocks(hashes: List<ByteArray>): List<Block> {
        return store.block.getBlocks(hashes)
    }

    override fun getBlocksChunk(fromHeight: Int, toHeight: Int): List<Block> {
        return store.block.getBlocksChunk(fromHeight, toHeight)
    }

    override fun blocksCount(headerHashes: List<ByteArray>?): Int {
        return if (headerHashes == null) {
            store.block.count()
        } else {
            store.block.getBlocksCount(headerHashes)
        }
    }

    override fun addBlock(block: Block) {
        store.block.insert(block)
    }

    override fun saveBlock(block: Block) {
        store.block.insert(block)
    }

    override fun setBlockPartial(headerHash: ByteArray) {
        store.block.setBlockPartial(headerHash)
    }

    override fun lastBlock(): Block? {
        return store.block.getLastBlock()
    }

    override fun updateBlock(staleBlock: Block) {
        store.block.update(staleBlock)
    }

    override fun deleteBlocks(blocks: List<Block>) {
        blocks.forEach { block ->
            val transactions = store.transaction.getBlockTransactions(block.headerHash)

            transactions.forEach {
                store.input.deleteAll(getTransactionInputs(it))
                store.output.deleteAll(getTransactionOutputs(it))
            }

            store.transaction.deleteAll(transactions)
        }

        store.block.deleteAll(blocks)
    }

    override fun deleteBlocksWithoutTransactions(toHeight: Int) {
        if (toHeight <= 0) {
            return
        }
        store.block.deleteBlocksWithoutTransactions(toHeight)
    }

    override fun unstaleAllBlocks() {
        store.block.unstaleAllBlocks()
    }

    override fun timestamps(from: Int, to: Int): List<Long> {
        return store.block.getTimestamps(from, to)
    }

    // Transaction

    override fun getFullTransactionInfo(transactions: List<TransactionWithBlock>): List<FullTransactionInfo> {
        val txHashes = transactions.map { it.transaction.hash }
        val inputs = store.input.getInputsWithPrevouts(txHashes)
        val outputs = store.output.getTransactionsOutputs(txHashes)
        val metadataByTransaction = store.transactionMetadata.getTransactionMetadata(txHashes)
            .associateBy { it.transactionHash.toHexString() }
        val transactionSerializer = requireNotNull(transactionSerializer)

        return transactions.map { tx ->
            val transactionHash = tx.transaction.hash
            FullTransactionInfo(
                tx.block,
                if (tx.transaction.status == Transaction.Status.INVALID) InvalidTransaction(
                    tx.transaction,
                    tx.transaction.serializedTxInfo,
                    tx.transaction.rawTransaction
                ) else tx.transaction,
                inputs.filter { it.input.transactionHash.contentEquals(transactionHash) },
                outputs.filter { it.transactionHash.contentEquals(transactionHash) },
                metadataByTransaction[transactionHash.toHexString()] ?: TransactionMetadata(transactionHash),
                transactionSerializer
            )
        }
    }

    override fun getFullTransactionInfo(fromTransaction: Transaction?, type: TransactionFilterType?, limit: Int?): List<FullTransactionInfo> {
        var query = "SELECT transactions.*, Block.*" +
                " FROM (SELECT * FROM `Transaction` UNION ALL SELECT * FROM InvalidTransaction) as transactions" +
                " LEFT JOIN Block ON transactions.blockHash = Block.headerHash" +
                " LEFT JOIN TransactionMetadata ON transactions.hash = TransactionMetadata.transactionHash"

        val whereConditions = mutableListOf<String>()
        if (fromTransaction != null) {
            whereConditions.add("(transactions.timestamp < ${fromTransaction.timestamp} OR (transactions.timestamp = ${fromTransaction.timestamp} AND transactions.`order` < ${fromTransaction.order}))")
        }

        type?.let { filterType ->
            val types = filterType.types.map { it.value }.joinToString(", ")
            whereConditions.add("TransactionMetadata.type IN ($types)")
        }

        if (whereConditions.isNotEmpty()) {
            query += " WHERE " + whereConditions.joinToString(" AND ")
        }

        query += " ORDER BY timestamp DESC, `order` DESC"

        if (limit != null) {
            query += " LIMIT $limit"
        }

        return getFullTransactionInfo(store.transaction.getTransactionWithBlockBySql(SimpleSQLiteQuery(query)))
    }

    override fun getFullTransactionInfo(txHash: ByteArray): FullTransactionInfo? {
        return store.transaction.getTransactionWithBlock(txHash)?.let { tx ->
            val inputs = store.input.getInputsWithPrevouts(listOf(txHash))
            val outputs = store.output.getTransactionsOutputs(listOf(txHash))
            val metadata = store.transactionMetadata.getTransactionMetadata(listOf(txHash))
            val transactionSerializer = requireNotNull(transactionSerializer)

            FullTransactionInfo(
                tx.block,
                tx.transaction,
                inputs.filter { it.input.transactionHash.contentEquals(tx.transaction.hash) },
                outputs.filter { it.transactionHash.contentEquals(tx.transaction.hash) },
                metadata.firstOrNull { it.transactionHash.contentEquals(tx.transaction.hash) }
                    ?: TransactionMetadata(tx.transaction.hash),
                transactionSerializer
            )
        }
    }

    override fun getTransaction(hash: ByteArray): Transaction? {
        return store.transaction.getByHash(hash)
    }

    override fun getFullTransaction(hash: ByteArray): FullTransaction? {
        return store.transaction.getByHash(hash)?.let { convertToFullTransaction(it) }
    }

    override fun getFullTransactions(transactions: List<Transaction>): List<FullTransaction> {
        val hashes = transactions.map { it.hash }
        val inputsByTransaction = store.input.getTransactionInputs(hashes).groupBy { it.transactionHash.toHexString() }
        val outputsByTransaction = store.output.getTransactionsOutputs(hashes).groupBy { it.transactionHash.toHexString() }
        val metadataByTransaction = store.transactionMetadata.getTransactionMetadata(hashes).associateBy { it.transactionHash.toHexString() }
        val transactionSerializer = requireNotNull(transactionSerializer)

        return transactions.map { transaction ->
            val inputs = inputsByTransaction[transaction.hash.toHexString()] ?: listOf()
            val outputs = outputsByTransaction[transaction.hash.toHexString()] ?: listOf()
            FullTransaction(transaction, inputs, outputs, transactionSerializer, false).apply {
                metadata = metadataByTransaction[transaction.hash.toHexString()] ?: TransactionMetadata(transaction.hash)
            }
        }
    }

    override fun getValidOrInvalidTransaction(uid: String): Transaction? {
        return store.transaction.getValidOrInvalidByUid(uid)
    }

    override fun getTransactionOfOutput(output: TransactionOutput): Transaction? {
        return store.transaction.getByHash(output.transactionHash)
    }

    override fun getTransactionOutputsCount(hash: ByteArray): Int {
        return store.output.getCountByHash(hash)
    }

    override fun addTransaction(transaction: FullTransaction) {
        store.runInTransaction {
            addWithoutTransaction(transaction)
        }
    }

    override fun updateTransaction(transaction: Transaction) {
        store.transaction.update(transaction)
    }

    override fun updateTransaction(transaction: FullTransaction) {
        store.runInTransaction {
            store.transaction.update(transaction.header)
            transaction.inputs.forEach {
                store.input.update(it)
            }

            transaction.outputs.forEach {
                store.output.update(it)
            }
        }

    }

    override fun getBlockTransactions(block: Block): List<Transaction> {
        return store.transaction.getBlockTransactions(block.headerHash)
    }

    override fun getNewTransaction(hash: ByteArray): Transaction? {
        return store.transaction.getNewTransaction(hash)
    }

    override fun getNewTransactions(): List<FullTransaction> {
        return store.transaction.getNewTransactions().map { convertToFullTransaction(it) }
    }

    override fun isRelayedTransactionExists(hash: ByteArray): Boolean {
        return store.transaction.getByHashAndStatus(hash, Transaction.Status.RELAYED) != null
    }

    override fun isTransactionExists(hash: ByteArray): Boolean {
        return store.transaction.getByHash(hash) != null
    }

    override fun getConflictingTransactions(transaction: FullTransaction): List<Transaction> {
        val txHashes = HashSet<String>()
        transaction.inputs.forEach { input ->
            store.input.getInput(input.previousOutputTxHash, input.previousOutputIndex)?.transactionHash?.let { txHash ->
                txHashes.add(txHash.toHexString())
            }
        }

        txHashes.remove(transaction.header.hash.toHexString())

        return if (txHashes.isNotEmpty()) {
            txHashes.mapNotNull {
                store.transaction.getByHash(it.hexToByteArray())
            }
        } else {
            listOf()
        }
    }

    override fun getRelayedPendingTransactions(status: Int): List<Transaction> {
        return store.transaction.getRelayedPendingTransactions(status)
    }

    override fun getIncomingPendingTxHashes(): List<ByteArray> {
        return store.transaction.getIncomingPendingTxHashes()
    }

    override fun incomingPendingTransactionsExist(): Boolean {
        return store.transaction.getIncomingPendingTxCount() > 0
    }

    override fun deleteRelayedPendingTransactions(transactions: List<Transaction>): List<Transaction> {
        val deletedTransactions = mutableListOf<Transaction>()

        store.runInTransaction {
            transactions.forEach { transaction ->
                // The transaction may be confirmed while the reconciler is doing network lookup.
                val pendingTransaction = store.transaction.getByHash(transaction.hash)
                    ?.takeIf { it.blockHash == null && it.status == Transaction.Status.RELAYED }
                    ?: return@forEach

                store.sentTransaction.getTransaction(pendingTransaction.hash)?.let {
                    store.sentTransaction.delete(it)
                }

                store.input.deleteAll(getTransactionInputs(pendingTransaction))
                store.output.deleteAll(getTransactionOutputs(pendingTransaction))
                store.transactionMetadata.delete(pendingTransaction.hash)
                store.transaction.delete(pendingTransaction)
                deletedTransactions += pendingTransaction
            }
        }

        return deletedTransactions
    }

    private fun convertToFullTransaction(transaction: Transaction): FullTransaction {
        val transactionSerializer = requireNotNull(transactionSerializer)
        return FullTransaction(
            header = transaction,
            inputs = getTransactionInputs(transaction),
            outputs = getTransactionOutputs(transaction),
            transactionSerializer = transactionSerializer,
            forceHashUpdate = false,
        ).apply {
            metadata = TransactionMetadata(transaction.hash)
        }
    }

    private fun addWithoutTransaction(transaction: FullTransaction) {
        store.transaction.insert(transaction.header)
        store.transactionMetadata.insert(transaction.metadata)

        transaction.inputs.forEach {
            store.input.insert(it)
        }

        transaction.outputs.forEach {
            store.output.insert(it)
        }
    }

    // InvalidTransaction

    override fun getInvalidTransaction(hash: ByteArray): InvalidTransaction? {
        return store.transaction.getInvalidTransaction(hash)
    }

    override fun getDescendantTransactionsFullInfo(txHash: ByteArray): List<FullTransactionInfo> {
        val fullTransactionInfo = getFullTransactionInfo(txHash) ?: return listOf()
        val list = mutableListOf(fullTransactionInfo)

        val inputs = getTransactionInputsByPrevOutputTxHash(fullTransactionInfo.header.hash)

        inputs.forEach { input ->
            val descendantTxs = getDescendantTransactionsFullInfo(input.transactionHash)
            list.addAll(descendantTxs)
        }

        return list
    }

    override fun getDescendantTransactions(txHash: ByteArray): List<Transaction> {
        val transaction = getTransaction(txHash) ?: return listOf()
        val list = mutableListOf(transaction)

        val inputs = getTransactionInputsByPrevOutputTxHash(txHash)

        inputs.forEach { input ->
            val descendantTxs = getDescendantTransactions(input.transactionHash)
            list.addAll(descendantTxs)
        }

        return list
    }

    override fun moveTransactionToInvalidTransactions(invalidTransactions: List<InvalidTransaction>) {
        store.runInTransaction {
            invalidTransactions.forEach { invalidTransaction ->
                store.invalidTransaction.insert(invalidTransaction)

                val inputs = store.input.getInputsWithPrevouts(listOf(invalidTransaction.hash))
                inputs.forEach { input ->
                    input.previousOutput?.let {
                        store.output.markFailedToSpend(it.transactionHash, it.index)
                    }
                }

                store.input.deleteByTxHash(invalidTransaction.hash)

                store.output.deleteByTxHash(invalidTransaction.hash)

                store.transaction.deleteByHash(invalidTransaction.hash)
            }
        }
    }

    override fun moveInvalidTransactionToTransactions(invalidTransaction: InvalidTransaction, toTransactions: FullTransaction) {
        store.runInTransaction {
            addWithoutTransaction(toTransactions)
            store.invalidTransaction.delete(invalidTransaction.uid)
        }
    }

    override fun deleteAllInvalidTransactions() {
        store.invalidTransaction.deleteAll()
    }

    // TransactionOutput

    override fun getUnspentOutputs(): List<UnspentOutput> {
        return store.output.getUnspents()
    }

    override fun getPreviousOutput(input: TransactionInput): TransactionOutput? {
        return store.output.getPreviousOutput(input.previousOutputTxHash, input.previousOutputIndex.toInt())
    }

    override fun getOutput(transactionHash: ByteArray, index: Int): TransactionOutput? {
        return store.output.getPreviousOutput(transactionHash, index)
    }

    override fun getTransactionOutputs(transaction: Transaction): List<TransactionOutput> {
        return store.output.getByHash(transaction.hash)
    }

    override fun getOutputsOfPublicKey(publicKey: PublicKey): List<TransactionOutput> {
        return store.output.getListByPath(publicKey.path)
    }

    override fun getMyOutputs(): List<TransactionOutput> {
        return store.output.getMyOutputs()
    }

    override fun getOutputsForBloomFilter(blockHeight: Int, irregularScriptTypes: List<ScriptType>): List<TransactionOutput> {
        return store.output.getOutputsForBloomFilter(blockHeight, irregularScriptTypes.map { it.value })
    }

    // TransactionInput

    override fun getTransactionInputs(transaction: Transaction): List<TransactionInput> {
        return store.input.getTransactionInputs(transaction.hash)
    }

    override fun getTransactionInputs(txHash: ByteArray): List<TransactionInput> {
        return store.input.getTransactionInputs(txHash)
    }

    override fun getTransactionInputs(txHashes: List<ByteArray>): List<TransactionInput> {
        return store.input.getTransactionInputs(txHashes)
    }

    override fun getTransactionInput(previousOutputTxHash: ByteArray, previousOutputIndex: Long): TransactionInput? {
        return store.input.getInput(previousOutputTxHash, previousOutputIndex)
    }

    override fun getTransactionInputsByPrevOutputTxHash(txHash: ByteArray): List<TransactionInput> {
        return store.input.getInputsByPrevOutputTxHash(txHash)
    }

    // PublicKey

    override fun getPublicKeyByHashP2TR(hashP2TR: ByteArray): PublicKey? {
        return store.publicKey.getByHashP2TR(hashP2TR)
    }

    override fun getPublicKeyByScriptHashForP2PWKH(keyHash: ByteArray): PublicKey? {
        return store.publicKey.getByScriptHashWPKH(keyHash)
    }

    override fun getPublicKeyByKeyOrKeyHash(keyHash: ByteArray): PublicKey? {
        return store.publicKey.getByKeyOrKeyHash(keyHash)
    }

    override fun getPublicKeys(): List<PublicKey> {
        return store.publicKey.getAll()
    }

    override fun getPublicKeysUsed(): List<PublicKey> {
        return store.publicKey.getAllUsed()
    }

    override fun getPublicKeysUnused(): List<PublicKey> {
        return store.publicKey.getAllUnused()
    }

    override fun getPublicKeysWithUsedState(): List<PublicKeyWithUsedState> {
        return store.publicKey.getAllWithUsedState()
    }

    override fun savePublicKeys(keys: List<PublicKey>) {
        store.publicKey.insertOrIgnore(keys)
    }

    // SentTransaction

    override fun getSentTransaction(hash: ByteArray): SentTransaction? {
        return store.sentTransaction.getTransaction(hash)
    }

    override fun getSentTransactionHashes(): List<ByteArray> {
        return store.sentTransaction.getAll().map { it.hash }
    }

    override fun addSentTransaction(transaction: SentTransaction) {
        store.sentTransaction.insert(transaction)
    }

    override fun updateSentTransaction(transaction: SentTransaction) {
        store.sentTransaction.insert(transaction)
    }

    override fun deleteSentTransaction(transaction: SentTransaction) {
        store.sentTransaction.delete(transaction)
    }

    override fun getChainWork(block: Block): BigInteger {
        var totalWork = BigInteger.ZERO
        var currentBlock: Block? = block
        val visited = mutableSetOf<String>()

        while (currentBlock != null) {
            val hash = currentBlock.headerHash.toHexString()

            if (!visited.add(hash)) {
                break
            }

            // Protection against excessively long chains (typical reorgs < 10 blocks, but giving safety margin)
            if (visited.size > 100) {
                break
            }

            totalWork = totalWork.add(blockWork(currentBlock.bits))

            if (currentBlock.height == 0 || currentBlock.previousBlockHash.isEmpty()) {
                break
            }

            val parent = getBlock(currentBlock.previousBlockHash)
            if (parent == null || parent.height >= currentBlock.height) {
                break
            }

            currentBlock = parent
        }

        return totalWork
    }

    private fun blockWork(bits: Long): BigInteger {
        val target = decodeCompactBits(bits)
        val two256 = BigInteger.ONE.shiftLeft(256)
        return two256.divide(target.add(BigInteger.ONE))
    }

    private fun decodeCompactBits(compact: Long): BigInteger {
        val size = ((compact ushr 24) and 0xFF).toInt()
        val mantissa = compact and 0x007FFFFF

        if ((compact and 0x00800000) != 0L) {
            return BigInteger.ZERO
        }

        return if (size <= 3) {
            BigInteger.valueOf(mantissa shr (8 * (3 - size)))
        } else {
            BigInteger.valueOf(mantissa).shiftLeft(8 * (size - 3))
        }
    }
}
