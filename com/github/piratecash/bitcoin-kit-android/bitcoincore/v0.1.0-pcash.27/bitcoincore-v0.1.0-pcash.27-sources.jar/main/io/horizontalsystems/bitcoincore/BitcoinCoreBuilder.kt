package io.horizontalsystems.bitcoincore

import android.content.Context
import io.horizontalsystems.bitcoincore.apisync.blockchair.Api
import io.horizontalsystems.bitcoincore.apisync.blockchair.BlockchairApi
import io.horizontalsystems.bitcoincore.apisync.blockchair.BlockchairApiSyncer
import io.horizontalsystems.bitcoincore.apisync.blockchair.BlockchairLastBlockProvider
import io.horizontalsystems.bitcoincore.apisync.blockchair.BlockchairTransactionProvider
import io.horizontalsystems.bitcoincore.apisync.blockchair.LastBlockProvider
import io.horizontalsystems.bitcoincore.network.NetworkErrorListenerHolder
import io.horizontalsystems.bitcoincore.apisync.legacy.ApiSyncer
import io.horizontalsystems.bitcoincore.apisync.legacy.BlockHashDiscoveryBatch
import io.horizontalsystems.bitcoincore.apisync.legacy.BlockHashScanHelper
import io.horizontalsystems.bitcoincore.apisync.legacy.BlockHashScanner
import io.horizontalsystems.bitcoincore.apisync.legacy.IMultiAccountPublicKeyFetcher
import io.horizontalsystems.bitcoincore.apisync.legacy.IPublicKeyFetcher
import io.horizontalsystems.bitcoincore.apisync.legacy.MultiAccountPublicKeyFetcher
import io.horizontalsystems.bitcoincore.apisync.legacy.PublicKeyFetcher
import io.horizontalsystems.bitcoincore.apisync.legacy.WatchAddressBlockHashScanHelper
import io.horizontalsystems.bitcoincore.apisync.legacy.WatchPublicKeyFetcher
import io.horizontalsystems.bitcoincore.blocks.BlockDownload
import io.horizontalsystems.bitcoincore.blocks.BlockMessageExtractor
import io.horizontalsystems.bitcoincore.blocks.BlockSyncer
import io.horizontalsystems.bitcoincore.blocks.Blockchain
import io.horizontalsystems.bitcoincore.blocks.BloomFilterLoader
import io.horizontalsystems.bitcoincore.blocks.InitialBlockDownload
import io.horizontalsystems.bitcoincore.blocks.MerkleBlockExtractor
import io.horizontalsystems.bitcoincore.blocks.validators.IBlockValidator
import io.horizontalsystems.bitcoincore.core.AccountWallet
import io.horizontalsystems.bitcoincore.core.BaseTransactionInfoConverter
import io.horizontalsystems.bitcoincore.core.DataProvider
import io.horizontalsystems.bitcoincore.core.DoubleSha256Hasher
import io.horizontalsystems.bitcoincore.core.IApiSyncer
import io.horizontalsystems.bitcoincore.core.IApiTransactionProvider
import io.horizontalsystems.bitcoincore.core.IHasher
import io.horizontalsystems.bitcoincore.core.IInitialDownload
import io.horizontalsystems.bitcoincore.core.IInstantTransactionChecker
import io.horizontalsystems.bitcoincore.core.IPlugin
import io.horizontalsystems.bitcoincore.core.IPrivateWallet
import io.horizontalsystems.bitcoincore.core.IPublicKeyManager
import io.horizontalsystems.bitcoincore.core.IStorage
import io.horizontalsystems.bitcoincore.core.ITransactionInfoConverter
import io.horizontalsystems.bitcoincore.core.PluginManager
import io.horizontalsystems.bitcoincore.core.TransactionDataSorterFactory
import io.horizontalsystems.bitcoincore.core.TransactionInfoConverter
import io.horizontalsystems.bitcoincore.core.Wallet
import io.horizontalsystems.bitcoincore.core.WatchAccountWallet
import io.horizontalsystems.bitcoincore.core.scriptType
import io.horizontalsystems.bitcoincore.managers.AccountPublicKeyManager
import io.horizontalsystems.bitcoincore.managers.ApiSyncStateManager
import io.horizontalsystems.bitcoincore.managers.BloomFilterManager
import io.horizontalsystems.bitcoincore.managers.ConnectionManager
import io.horizontalsystems.bitcoincore.managers.IBloomFilterProvider
import io.horizontalsystems.bitcoincore.managers.IrregularOutputFinder
import io.horizontalsystems.bitcoincore.managers.PendingOutpointsProvider
import io.horizontalsystems.bitcoincore.managers.PublicKeyManager
import io.horizontalsystems.bitcoincore.managers.RestoreKeyConverterChain
import io.horizontalsystems.bitcoincore.managers.SyncManager
import io.horizontalsystems.bitcoincore.managers.UnspentOutputProvider
import io.horizontalsystems.bitcoincore.managers.UnspentOutputSelector
import io.horizontalsystems.bitcoincore.managers.UnspentOutputSelectorChain
import io.horizontalsystems.bitcoincore.managers.UnspentOutputSelectorSingleNoChange
import io.horizontalsystems.bitcoincore.models.Checkpoint
import io.horizontalsystems.bitcoincore.models.WatchAddressPublicKey
import io.horizontalsystems.bitcoincore.network.Network
import io.horizontalsystems.bitcoincore.network.messages.AddrMessageParser
import io.horizontalsystems.bitcoincore.network.messages.FilterLoadMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.GetBlocksMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.GetDataMessageParser
import io.horizontalsystems.bitcoincore.network.messages.GetDataMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.GetAddrMessageParser
import io.horizontalsystems.bitcoincore.network.messages.GetAddrMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.GetHeadersMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.HeadersMessageParser
import io.horizontalsystems.bitcoincore.network.messages.InvMessageParser
import io.horizontalsystems.bitcoincore.network.messages.InvMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.MempoolMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.MerkleBlockMessageParser
import io.horizontalsystems.bitcoincore.network.messages.NetworkMessageParser
import io.horizontalsystems.bitcoincore.network.messages.NetworkMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.PingMessageParser
import io.horizontalsystems.bitcoincore.network.messages.PingMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.PongMessageParser
import io.horizontalsystems.bitcoincore.network.messages.PongMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.RejectMessageParser
import io.horizontalsystems.bitcoincore.network.messages.TransactionMessageParser
import io.horizontalsystems.bitcoincore.network.messages.TransactionMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.VerAckMessageParser
import io.horizontalsystems.bitcoincore.network.messages.VerAckMessageSerializer
import io.horizontalsystems.bitcoincore.network.messages.VersionMessageParser
import io.horizontalsystems.bitcoincore.network.messages.VersionMessageSerializer
import io.horizontalsystems.bitcoincore.network.peer.MempoolTransactions
import io.horizontalsystems.bitcoincore.network.peer.PeerAddressManager
import io.horizontalsystems.bitcoincore.network.peer.PeerGroup
import io.horizontalsystems.bitcoincore.network.peer.PeerManager
import io.horizontalsystems.bitcoincore.network.peer.SharedPeerGroupHolder
import io.horizontalsystems.bitcoincore.rbf.ReplacementTransactionBuilder
import io.horizontalsystems.bitcoincore.serializers.BaseTransactionSerializer
import io.horizontalsystems.bitcoincore.serializers.BlockHeaderParser
import io.horizontalsystems.bitcoincore.transactions.AddressExtractor
import io.horizontalsystems.bitcoincore.transactions.BlockTransactionProcessor
import io.horizontalsystems.bitcoincore.transactions.BlockchairPendingTransactionStatusProvider
import io.horizontalsystems.bitcoincore.transactions.PendingTransactionProcessor
import io.horizontalsystems.bitcoincore.transactions.PendingTransactionReconciler
import io.horizontalsystems.bitcoincore.transactions.SendTransactionsOnPeersSynced
import io.horizontalsystems.bitcoincore.transactions.TransactionConflictsResolver
import io.horizontalsystems.bitcoincore.transactions.TransactionCreator
import io.horizontalsystems.bitcoincore.transactions.TransactionFeeCalculator
import io.horizontalsystems.bitcoincore.transactions.TransactionInvalidator
import io.horizontalsystems.bitcoincore.transactions.TransactionSendTimer
import io.horizontalsystems.bitcoincore.transactions.TransactionSender
import io.horizontalsystems.bitcoincore.transactions.TransactionSizeCalculator
import io.horizontalsystems.bitcoincore.transactions.TransactionSyncer
import io.horizontalsystems.bitcoincore.transactions.builder.EcdsaInputSigner
import io.horizontalsystems.bitcoincore.transactions.builder.IInputSigner
import io.horizontalsystems.bitcoincore.transactions.builder.ISchnorrInputSigner
import io.horizontalsystems.bitcoincore.transactions.builder.InputSetter
import io.horizontalsystems.bitcoincore.transactions.builder.LockTimeSetter
import io.horizontalsystems.bitcoincore.transactions.builder.OutputSetter
import io.horizontalsystems.bitcoincore.transactions.builder.RecipientSetter
import io.horizontalsystems.bitcoincore.transactions.builder.SchnorrInputSigner
import io.horizontalsystems.bitcoincore.transactions.builder.TransactionBuilder
import io.horizontalsystems.bitcoincore.transactions.builder.TransactionSigner
import io.horizontalsystems.bitcoincore.transactions.extractors.MyOutputsCache
import io.horizontalsystems.bitcoincore.transactions.extractors.TransactionExtractor
import io.horizontalsystems.bitcoincore.transactions.extractors.TransactionMetadataExtractor
import io.horizontalsystems.bitcoincore.transactions.extractors.TransactionOutputProvider
import io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType
import io.horizontalsystems.bitcoincore.utils.AddressConverterChain
import io.horizontalsystems.bitcoincore.utils.Base58AddressConverter
import io.horizontalsystems.bitcoincore.utils.PaymentAddressParser
import io.horizontalsystems.hdwalletkit.HDExtendedKey
import io.horizontalsystems.hdwalletkit.HDWallet
import io.horizontalsystems.hdwalletkit.HDWalletAccount
import io.horizontalsystems.hdwalletkit.HDWalletAccountWatch
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

class BitcoinCoreBuilder {

    val addressConverter = AddressConverterChain()

    // required parameters
    private var context: Context? = null
    private var extendedKey: HDExtendedKey? = null
    private var watchAddressPublicKey: WatchAddressPublicKey? = null
    private var purpose: HDWallet.Purpose? = null
    private var network: Network? = null
    private var customLastBLockProvider: LastBlockProvider? = null
    private var paymentAddressParser: PaymentAddressParser? = null
    private var storage: IStorage? = null
    private var apiTransactionProvider: IApiTransactionProvider? = null
    private var blockHeaderHasher: IHasher? = null
    private var transactionInfoConverter: ITransactionInfoConverter? = null
    private var blockValidator: IBlockValidator? = null
    private var checkpoint: Checkpoint? = null
    private var apiSyncStateManager: ApiSyncStateManager? = null
    private var networkErrorHolder: NetworkErrorListenerHolder? = null

    // parameters with default values
    private var confirmationsThreshold = 6
    private var syncMode: BitcoinCore.SyncMode = BitcoinCore.SyncMode.Api()
    private var peerSize = 10
    private var minConnectedPeerSize = TransactionSender.DEFAULT_MIN_CONNECTED_PEER_SIZE
    private val plugins = mutableListOf<IPlugin>()
    private var handleAddrMessage = true
    private var requestUnknownBlocks = false
    private var sendType: BitcoinCore.SendType = BitcoinCore.SendType.P2P
    private var transactionSerializer: BaseTransactionSerializer = BaseTransactionSerializer()
    private var allowBroadcastFromUnsyncedPeers = false
    private var instantChecker: IInstantTransactionChecker? = null
    private var sharedPeerGroupHolder: SharedPeerGroupHolder? = null
    private var coroutineDispatcher: CoroutineDispatcher = Dispatchers.IO

    // parameters for signing
    private var iInputSigner: IInputSigner? = null
    private var iSchnorrInputSigner: ISchnorrInputSigner? = null

    fun setContext(context: Context): BitcoinCoreBuilder {
        this.context = context
        return this
    }

    fun setExtendedKey(extendedKey: HDExtendedKey?): BitcoinCoreBuilder {
        this.extendedKey = extendedKey
        return this
    }

    fun setWatchAddressPublicKey(publicKey: WatchAddressPublicKey?): BitcoinCoreBuilder {
        this.watchAddressPublicKey = publicKey
        return this
    }

    fun setPurpose(purpose: HDWallet.Purpose): BitcoinCoreBuilder {
        this.purpose = purpose
        return this
    }

    fun setNetwork(network: Network): BitcoinCoreBuilder {
        this.network = network
        return this
    }

    fun setSigners(iInputSigner: IInputSigner, iSchnorrInputSigner: ISchnorrInputSigner): BitcoinCoreBuilder {
        this.iInputSigner = iInputSigner
        this.iSchnorrInputSigner = iSchnorrInputSigner
        return this
    }

    fun setCustomLastBlockProvider(customLastBLockProvider: LastBlockProvider): BitcoinCoreBuilder {
        this.customLastBLockProvider = customLastBLockProvider
        return this
    }

    fun setPaymentAddressParser(paymentAddressParser: PaymentAddressParser): BitcoinCoreBuilder {
        this.paymentAddressParser = paymentAddressParser
        return this
    }

    fun setConfirmationThreshold(confirmationsThreshold: Int): BitcoinCoreBuilder {
        this.confirmationsThreshold = confirmationsThreshold
        return this
    }

    fun setSyncMode(syncMode: BitcoinCore.SyncMode): BitcoinCoreBuilder {
        this.syncMode = syncMode
        return this
    }

    fun setSendType(sendType: BitcoinCore.SendType): BitcoinCoreBuilder {
        this.sendType = sendType
        return this
    }

    fun setAllowBroadcastFromUnsyncedPeers(value: Boolean): BitcoinCoreBuilder {
        allowBroadcastFromUnsyncedPeers = value
        return this
    }

    fun setInstantChecker(instantChecker: IInstantTransactionChecker): BitcoinCoreBuilder {
        this.instantChecker = instantChecker
        return this
    }

    fun setMinConnectedPeerSize(minConnectedPeerSize: Int): BitcoinCoreBuilder {
        this.minConnectedPeerSize = minConnectedPeerSize
        return this
    }

    fun setPeerSize(peerSize: Int): BitcoinCoreBuilder {
        this.peerSize = peerSize
        return this
    }

    fun setStorage(storage: IStorage): BitcoinCoreBuilder {
        this.storage = storage
        return this
    }

    fun setBlockHeaderHasher(blockHeaderHasher: IHasher): BitcoinCoreBuilder {
        this.blockHeaderHasher = blockHeaderHasher
        return this
    }

    fun setApiTransactionProvider(apiTransactionProvider: IApiTransactionProvider?): BitcoinCoreBuilder {
        this.apiTransactionProvider = apiTransactionProvider
        return this
    }

    fun setTransactionInfoConverter(transactionInfoConverter: ITransactionInfoConverter): BitcoinCoreBuilder {
        this.transactionInfoConverter = transactionInfoConverter
        return this
    }

    fun setBlockValidator(blockValidator: IBlockValidator): BitcoinCoreBuilder {
        this.blockValidator = blockValidator
        return this
    }

    fun setHandleAddrMessage(handle: Boolean): BitcoinCoreBuilder {
        handleAddrMessage = handle
        return this
    }

    fun setRequestUnknownBlocks(handle: Boolean): BitcoinCoreBuilder {
        requestUnknownBlocks = handle
        return this
    }

    fun addPlugin(plugin: IPlugin): BitcoinCoreBuilder {
        plugins.add(plugin)
        return this
    }

    fun setCheckpoint(checkpoint: Checkpoint): BitcoinCoreBuilder {
        this.checkpoint = checkpoint
        return this
    }

    fun setApiSyncStateManager(apiSyncStateManager: ApiSyncStateManager): BitcoinCoreBuilder {
        this.apiSyncStateManager = apiSyncStateManager
        return this
    }

    fun setNetworkErrorHolder(networkErrorHolder: NetworkErrorListenerHolder): BitcoinCoreBuilder {
        this.networkErrorHolder = networkErrorHolder
        return this
    }

    fun setTransactionSerializer(transactionSerializer: BaseTransactionSerializer): BitcoinCoreBuilder {
        this.transactionSerializer = transactionSerializer
        return this
    }

    fun setSharedPeerGroupHolder(holder: SharedPeerGroupHolder): BitcoinCoreBuilder {
        this.sharedPeerGroupHolder = holder
        return this
    }

    fun setCoroutineDispatcher(coroutineDispatcher: CoroutineDispatcher): BitcoinCoreBuilder {
        this.coroutineDispatcher = coroutineDispatcher
        return this
    }

    fun build(): BitcoinCore {
        require(peerSize >= minConnectedPeerSize) {
            "peerSize cannot be less than $minConnectedPeerSize"
        }
        require(minConnectedPeerSize > 0) {
            "minConnectedPeerSize must be greater than zero"
        }

        val context = checkNotNull(this.context)
        val extendedKey = this.extendedKey
        val watchAddressPublicKey = this.watchAddressPublicKey
        val purpose = checkNotNull(this.purpose)
        val network = checkNotNull(this.network)
        val paymentAddressParser = checkNotNull(this.paymentAddressParser)
        val storage = checkNotNull(this.storage)
        val apiTransactionProvider = checkNotNull(this.apiTransactionProvider)
        val checkpoint = checkNotNull(this.checkpoint)
        val apiSyncStateManager = checkNotNull(this.apiSyncStateManager)
        val blockHeaderHasher = this.blockHeaderHasher ?: DoubleSha256Hasher()
        val transactionInfoConverter = this.transactionInfoConverter ?: TransactionInfoConverter()

        val restoreKeyConverterChain = RestoreKeyConverterChain()

        storage.setTransactionSerializer(transactionSerializer)

        val pluginManager = PluginManager()
        plugins.forEach { pluginManager.addPlugin(it) }

        transactionInfoConverter.baseConverter = BaseTransactionInfoConverter(pluginManager)

        val unspentOutputProvider =
            UnspentOutputProvider(storage, confirmationsThreshold, pluginManager, instantChecker)

        val dataProvider = DataProvider(
            storage = storage,
            unspentOutputProvider = unspentOutputProvider,
            transactionInfoConverter = transactionInfoConverter,
            logTag = network.logTag
        )

        val connectionManager = ConnectionManager.getInstance(context)

        var privateWallet: IPrivateWallet? = null
        val publicKeyFetcher: IPublicKeyFetcher
        var multiAccountPublicKeyFetcher: IMultiAccountPublicKeyFetcher? = null
        val publicKeyManager: IPublicKeyManager
        val bloomFilterProvider: IBloomFilterProvider
        val gapLimit = 20

        if (watchAddressPublicKey != null) {
            storage.savePublicKeys(listOf(watchAddressPublicKey))

            WatchAddressPublicKeyManager(watchAddressPublicKey, restoreKeyConverterChain).let {
                publicKeyFetcher = it
                publicKeyManager = it
                bloomFilterProvider = it
            }
        } else if (extendedKey != null) {
            if (!extendedKey.isPublic) {
                when (extendedKey.derivedType) {
                    HDExtendedKey.DerivedType.Master -> {
                        val wallet =
                            Wallet(HDWallet(extendedKey.key, network.coinType, purpose), gapLimit)
                        privateWallet = wallet
                        val fetcher = MultiAccountPublicKeyFetcher(wallet)
                        publicKeyFetcher = fetcher
                        multiAccountPublicKeyFetcher = fetcher
                        PublicKeyManager.create(storage, wallet, restoreKeyConverterChain).apply {
                            publicKeyManager = this
                            bloomFilterProvider = this
                        }
                    }

                    HDExtendedKey.DerivedType.Account -> {
                        val wallet = AccountWallet(HDWalletAccount(extendedKey.key), gapLimit)
                        privateWallet = wallet
                        val fetcher = PublicKeyFetcher(wallet)
                        publicKeyFetcher = fetcher
                        AccountPublicKeyManager.create(storage, wallet, restoreKeyConverterChain)
                            .apply {
                                publicKeyManager = this
                                bloomFilterProvider = this
                            }

                    }

                    HDExtendedKey.DerivedType.Bip32 -> {
                        throw IllegalStateException("Custom Bip32 Extended Keys are not supported")
                    }
                }
            } else {
                when (extendedKey.derivedType) {
                    HDExtendedKey.DerivedType.Account -> {
                        val wallet =
                            WatchAccountWallet(HDWalletAccountWatch(extendedKey.key), gapLimit)
                        val fetcher = WatchPublicKeyFetcher(wallet)
                        publicKeyFetcher = fetcher
                        AccountPublicKeyManager.create(storage, wallet, restoreKeyConverterChain)
                            .apply {
                                publicKeyManager = this
                                bloomFilterProvider = this
                            }

                    }

                    HDExtendedKey.DerivedType.Bip32, HDExtendedKey.DerivedType.Master -> {
                        throw IllegalStateException("Only Account Extended Public Keys are supported")
                    }
                }
            }
        } else {
            throw IllegalStateException("Both extendedKey and watchAddressPublicKey are NULL!")
        }

        val pendingOutpointsProvider = PendingOutpointsProvider(storage)

        val additionalScriptTypes =
            if (watchAddressPublicKey != null) listOf(ScriptType.P2PKH) else emptyList()
        val irregularOutputFinder = IrregularOutputFinder(storage, additionalScriptTypes)
        val metadataExtractor = TransactionMetadataExtractor(
            MyOutputsCache.create(storage),
            TransactionOutputProvider(storage)
        )

        val blockchairApi =
            if (apiTransactionProvider is BlockchairTransactionProvider) {
                apiTransactionProvider.blockchairApi
            } else {
                BlockchairApi(network.blockchairChainId, networkErrorHolder)
            }

        // Best provider for a live "does this tx already exist?" lookup on raw broadcast:
        // - chains with their own Api-backed transaction provider (e.g. Cosanta, PirateCash) use it directly
        // - chains synced through Blockchair use blockchairApi, but only where getTransactions() is reliable
        // - everyone else (e.g. eCash) gets no live check and simply falls back to a normal broadcast
        val existenceCheckApi: Api? = when {
            apiTransactionProvider is Api -> apiTransactionProvider
            BlockchairPendingTransactionStatusProvider.isChainSupported(network.blockchairChainId) -> blockchairApi
            else -> null
        }

        val addressExtractor = AddressExtractor(blockchairApi, storage, dataProvider, network.logTag)
        val transactionExtractor =
            TransactionExtractor(addressConverter, storage, pluginManager, metadataExtractor, addressExtractor)

        val conflictsResolver = TransactionConflictsResolver(storage)
        val ignorePendingIncoming = false //syncMode is BitcoinCore.SyncMode.Blockchair
        val pendingTransactionProcessor = PendingTransactionProcessor(
            storage,
            transactionExtractor,
            publicKeyManager,
            irregularOutputFinder,
            dataProvider,
            conflictsResolver,
            ignorePendingIncoming
        )
        val invalidator = TransactionInvalidator(storage, transactionInfoConverter, dataProvider)
        val blockTransactionProcessor = BlockTransactionProcessor(
            storage,
            transactionExtractor,
            publicKeyManager,
            irregularOutputFinder,
            dataProvider,
            conflictsResolver,
            invalidator
        )
        val pendingTransactionReconciler = PendingTransactionReconciler(
            storage = storage,
            statusProvider = BlockchairPendingTransactionStatusProvider.create(blockchairApi, network.blockchairChainId),
            dataListener = dataProvider,
            outgoingInvalidator = invalidator,
            logTag = network.logTag,
            coroutineDispatcher = coroutineDispatcher,
        )

        val isShared = sharedPeerGroupHolder != null
        val peerHostManager = if (!isShared) PeerAddressManager(network, storage) else null
        val bloomFilterManager = sharedPeerGroupHolder?.bloomFilterManager ?: BloomFilterManager()

        val peerManager = sharedPeerGroupHolder?.peerManager ?: PeerManager().also {
            it.setAllowBroadcastFromUnsyncedPeers(allowBroadcastFromUnsyncedPeers)
        }

        val networkMessageParser = sharedPeerGroupHolder?.networkMessageParser ?: NetworkMessageParser(network.magic)
        val networkMessageSerializer = sharedPeerGroupHolder?.networkMessageSerializer ?: NetworkMessageSerializer(network.magic)

        val blockchain = Blockchain(
            storage = storage,
            blockValidator = blockValidator,
            dataListener = dataProvider,
            logTag = network.logTag
        )
        val blockSyncer = BlockSyncer(
            storage = storage,
            blockchain = blockchain,
            transactionProcessor = blockTransactionProcessor,
            publicKeyManager = publicKeyManager,
            checkpoint = checkpoint
        )


        val peerGroup = sharedPeerGroupHolder?.peerGroup ?: PeerGroup(
            hostManager = peerHostManager!!,
            network = network,
            peerManager = peerManager,
            peerSize = peerSize,
            networkMessageParser = networkMessageParser,
            networkMessageSerializer = networkMessageSerializer,
            connectionManager = connectionManager,
            localDownloadedBestBlockHeight = blockSyncer.localDownloadedBestBlockHeight,
            handleAddrMessage = handleAddrMessage
        ).also {
            peerHostManager.listener = it
        }

        val blockHashScanHelper =
            if (watchAddressPublicKey == null) BlockHashScanHelper() else WatchAddressBlockHashScanHelper()
        val blockHashScanner =
            BlockHashScanner(restoreKeyConverterChain, apiTransactionProvider, blockHashScanHelper)

        val apiSyncer: IApiSyncer
        val initialDownload: IInitialDownload
        val merkleBlockExtractor = MerkleBlockExtractor(network.maxBlockSize)
        val blockMessageExtractor = BlockMessageExtractor(network.maxBlockSize)

        when (syncMode) {
            is BitcoinCore.SyncMode.Blockchair -> {
                val lastBlockProvider = if (customLastBLockProvider != null) {
                    customLastBLockProvider!!
                } else {
                    BlockchairLastBlockProvider(blockchairApi)
                }

                apiSyncer = BlockchairApiSyncer(
                    storage = storage,
                    restoreKeyConverter = restoreKeyConverterChain,
                    transactionProvider = apiTransactionProvider,
                    lastBlockProvider = lastBlockProvider,
                    publicKeyManager = publicKeyManager,
                    blockchain = blockchain,
                    apiSyncStateManager = apiSyncStateManager
                )
                initialDownload = BlockDownload(
                    blockSyncer,
                    peerManager,
                    merkleBlockExtractor,
                    blockMessageExtractor,
                    requestUnknownBlocks,
                    network.logTag
                )
            }

            else -> {
                val blockDiscovery = BlockHashDiscoveryBatch(
                    blockHashScanner,
                    publicKeyFetcher,
                    checkpoint.block.height,
                    gapLimit
                )
                apiSyncer = ApiSyncer(
                    storage,
                    blockDiscovery,
                    publicKeyManager,
                    multiAccountPublicKeyFetcher,
                    apiSyncStateManager
                )
                initialDownload =
                    InitialBlockDownload(
                        blockSyncer = blockSyncer,
                        peerManager = peerManager,
                        merkleBlockExtractor = merkleBlockExtractor,
                        blockMessageExtractor = blockMessageExtractor,
                        logTag = network.logTag
                    )
            }
        }

        val syncManager = SyncManager(
            connectionManager,
            apiSyncer,
            peerGroup,
            storage,
            syncMode,
            blockSyncer.localDownloadedBestBlockHeight,
            peerSize,
            pendingTransactionReconciler
        )
        apiSyncer.listener = syncManager
        blockSyncer.listener = syncManager
        initialDownload.listener = syncManager
        blockHashScanner.listener = syncManager

        connectionManager.addListener(syncManager)
        // syncManager is registered as a peer-group listener below, AFTER
        // BitcoinCore is constructed, so it goes through bitcoinCore's tracked
        // registration (registeredPeerGroupListeners). Registering it here
        // directly on peerGroup would skip the tracking and leak the listener
        // on shared-peer-group teardown — the stopped (non-last) kit would
        // stay live in peerGroup.peerGroupListeners, still receiving callbacks.

        val unspentOutputSelector = UnspentOutputSelectorChain(unspentOutputProvider)
        val pendingTransactionSyncer =
            TransactionSyncer(storage, pendingTransactionProcessor, invalidator, publicKeyManager)
        val transactionDataSorterFactory = TransactionDataSorterFactory()

        var dustCalculator: DustCalculator? = null
        var transactionSizeCalculator: TransactionSizeCalculator? = null
        var transactionFeeCalculator: TransactionFeeCalculator? = null
        var transactionSender: TransactionSender? = null
        var transactionCreator: TransactionCreator? = null
        var replacementTransactionBuilder: ReplacementTransactionBuilder? = null

        if (privateWallet != null && iInputSigner == null && iSchnorrInputSigner == null) {
            iInputSigner = EcdsaInputSigner(privateWallet, transactionSerializer, network)
            iSchnorrInputSigner = SchnorrInputSigner(privateWallet, transactionSerializer)
        }
        iInputSigner?.apply {
            setNetwork(network)
            setTransactionSerializer(transactionSerializer)
        }
        iSchnorrInputSigner?.apply {
            setNetwork(network)
            setTransactionSerializer(transactionSerializer)
        }

        if (iInputSigner != null && iSchnorrInputSigner != null) {
            val transactionSizeCalculatorInstance = TransactionSizeCalculator()
            val dustCalculatorInstance =
                DustCalculator(network.dustRelayTxFee, transactionSizeCalculatorInstance)
            val recipientSetter = RecipientSetter(addressConverter, pluginManager)
            val outputSetter = OutputSetter(transactionDataSorterFactory)
            val inputSetter = InputSetter(
                unspentOutputSelector,
                publicKeyManager,
                addressConverter,
                purpose.scriptType,
                transactionSizeCalculatorInstance,
                pluginManager,
                dustCalculatorInstance,
                transactionDataSorterFactory
            )
            val lockTimeSetter = LockTimeSetter(storage, network.usesLastBlockHeightAsLockTime)
            val transactionBuilder =
                TransactionBuilder(recipientSetter, outputSetter, inputSetter, lockTimeSetter, network.transactionVersion)
            transactionFeeCalculator = TransactionFeeCalculator(
                recipientSetter,
                inputSetter,
                addressConverter,
                publicKeyManager,
                purpose.scriptType,
                network.transactionVersion,
            )
            val transactionSendTimer = TransactionSendTimer(60)
            val transactionSenderInstance = TransactionSender(
                transactionSyncer = pendingTransactionSyncer,
                peerManager = peerManager,
                initialBlockDownload = initialDownload,
                storage = storage,
                timer = transactionSendTimer,
                sendType = sendType,
                transactionSerializer = transactionSerializer,
                allowBroadcastFromUnsyncedPeers = allowBroadcastFromUnsyncedPeers,
                minConnectedPeerSize = minConnectedPeerSize,
                logTag = network.logTag,
            )

            dustCalculator = dustCalculatorInstance
            transactionSizeCalculator = transactionSizeCalculatorInstance
            transactionSender = transactionSenderInstance

            transactionSendTimer.listener = transactionSender
            val signer = TransactionSigner(iInputSigner!!, iSchnorrInputSigner!!)
            transactionCreator = TransactionCreator(
                builder = transactionBuilder,
                processor = pendingTransactionProcessor,
                transactionSender = transactionSenderInstance,
                transactionSigner = signer,
                bloomFilterManager = bloomFilterManager,
                transactionSerializer = transactionSerializer,
                existenceCheckApi = existenceCheckApi,
            )
            replacementTransactionBuilder = ReplacementTransactionBuilder(
                storage = storage,
                sizeCalculator = transactionSizeCalculator,
                dustCalculator = dustCalculator,
                metadataExtractor = metadataExtractor,
                pluginManager = pluginManager,
                unspentOutputProvider = unspentOutputProvider,
                publicKeyManager = publicKeyManager,
                conflictsResolver = conflictsResolver,
                lockTimeSetter = lockTimeSetter,
                transactionSerializer = transactionSerializer,
                transactionVersion = network.transactionVersion,
            )
        }

        val bitcoinCore = BitcoinCore(
            storage,
            dataProvider,
            addressExtractor,
            publicKeyManager,
            addressConverter,
            restoreKeyConverterChain,
            transactionCreator,
            transactionFeeCalculator,
            replacementTransactionBuilder,
            paymentAddressParser,
            syncManager,
            purpose,
            peerManager,
            dustCalculator,
            pluginManager,
            connectionManager
        )

        dataProvider.listener = bitcoinCore
        syncManager.listener = bitcoinCore
        bitcoinCore.bloomFilterManager = bloomFilterManager

        val watchedTransactionManager = WatchedTransactionManager()
        bitcoinCore.addBloomFilterProvider(watchedTransactionManager)
        bitcoinCore.addBloomFilterProvider(bloomFilterProvider)
        bitcoinCore.addBloomFilterProvider(pendingOutpointsProvider)
        bitcoinCore.addBloomFilterProvider(irregularOutputFinder)

        bitcoinCore.watchedTransactionManager = watchedTransactionManager
        pendingTransactionProcessor.transactionListener = watchedTransactionManager
        blockTransactionProcessor.transactionListener = watchedTransactionManager

        bitcoinCore.peerGroup = peerGroup
        bitcoinCore.isShared = isShared
        bitcoinCore.transactionSyncer = pendingTransactionSyncer
        bitcoinCore.networkMessageParser = networkMessageParser
        bitcoinCore.networkMessageSerializer = networkMessageSerializer
        bitcoinCore.unspentOutputSelector = unspentOutputSelector

        peerGroup.addPeerTaskHandler(bitcoinCore.peerTaskHandlerChain)
        peerGroup.addInventoryItemsHandler(bitcoinCore.inventoryItemsHandlerChain)

        bitcoinCore.prependAddressConverter(
            Base58AddressConverter(
                network.addressVersion,
                network.addressScriptVersion
            )
        )

        // Message parsers/serializers and BloomFilterLoader are only created
        // for non-shared PeerGroups. Shared ones have these set up already.
        if (!isShared) {
            bitcoinCore.addMessageParser(AddrMessageParser())
                .addMessageParser(MerkleBlockMessageParser(BlockHeaderParser(blockHeaderHasher)))
                .addMessageParser(InvMessageParser())
                .addMessageParser(GetDataMessageParser())
                .addMessageParser(PingMessageParser())
                .addMessageParser(PongMessageParser())
                .addMessageParser(TransactionMessageParser(transactionSerializer))
                .addMessageParser(VerAckMessageParser())
                .addMessageParser(VersionMessageParser())
                .addMessageParser(RejectMessageParser())

            bitcoinCore.addMessageSerializer(FilterLoadMessageSerializer())
                .addMessageSerializer(GetBlocksMessageSerializer())
                .addMessageSerializer(InvMessageSerializer())
                .addMessageSerializer(GetDataMessageSerializer())
                .addMessageSerializer(MempoolMessageSerializer())
                .addMessageSerializer(PingMessageSerializer())
                .addMessageSerializer(PongMessageSerializer())
                .addMessageSerializer(TransactionMessageSerializer(transactionSerializer))
                .addMessageSerializer(VerAckMessageSerializer())
                .addMessageSerializer(VersionMessageSerializer())

            networkMessageParser.add(GetAddrMessageParser())
            networkMessageSerializer.add(GetAddrMessageSerializer())

            // The chain-identity probe (see Peer) sends getheaders and parses the headers reply.
            // Only networks that share their wire format with another chain (eCash) define an anchor.
            if (network.chainIdentityAnchorHash != null) {
                networkMessageParser.add(HeadersMessageParser(blockHeaderHasher))
                networkMessageSerializer.add(GetHeadersMessageSerializer())
            }

            val bloomFilterLoader = BloomFilterLoader(bloomFilterManager, peerManager)
            bloomFilterManager.listener = bloomFilterLoader
            bitcoinCore.addPeerGroupListener(bloomFilterLoader)
        }

        // todo: now this part cannot be moved to another place since bitcoinCore requires initialBlockDownload to be set. find solution to do so
        bitcoinCore.initialDownload = initialDownload
        bitcoinCore.addPeerTaskHandler(initialDownload)
        bitcoinCore.addInventoryItemsHandler(initialDownload)
        bitcoinCore.addPeerGroupListener(initialDownload)

        bitcoinCore.addPeerGroupListener(syncManager)


        val mempoolTransactions = MempoolTransactions(pendingTransactionSyncer, transactionSender)
        bitcoinCore.addPeerTaskHandler(mempoolTransactions)
        bitcoinCore.addInventoryItemsHandler(mempoolTransactions)
        bitcoinCore.addPeerGroupListener(mempoolTransactions)

        transactionSender?.let {
            bitcoinCore.transactionSender = it
            bitcoinCore.addPeerSyncListener(SendTransactionsOnPeersSynced(transactionSender))
            bitcoinCore.addPeerTaskHandler(transactionSender)
            bitcoinCore.addPeerGroupListener(transactionSender)
        }

        if (transactionSizeCalculator != null && dustCalculator != null) {
            bitcoinCore.prependUnspentOutputSelector(
                UnspentOutputSelector(
                    transactionSizeCalculator,
                    dustCalculator,
                    unspentOutputProvider
                )
            )
            bitcoinCore.prependUnspentOutputSelector(
                UnspentOutputSelectorSingleNoChange(
                    transactionSizeCalculator,
                    dustCalculator,
                    unspentOutputProvider
                )
            )
        }

        return bitcoinCore
    }
}
