package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.ScriptTypeConverter;
import io.horizontalsystems.bitcoincore.models.TransactionInput;
import io.horizontalsystems.bitcoincore.models.TransactionOutput;
import io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType;
import java.lang.Byte;
import java.lang.Class;
import java.lang.IllegalStateException;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class TransactionInputDao_Impl implements TransactionInputDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<TransactionInput> __insertionAdapterOfTransactionInput;

  private final WitnessConverter __witnessConverter = new WitnessConverter();

  private final EntityDeletionOrUpdateAdapter<TransactionInput> __deletionAdapterOfTransactionInput;

  private final EntityDeletionOrUpdateAdapter<TransactionInput> __updateAdapterOfTransactionInput;

  private final SharedSQLiteStatement __preparedStmtOfDeleteByTxHash;

  private final ScriptTypeConverter __scriptTypeConverter = new ScriptTypeConverter();

  public TransactionInputDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfTransactionInput = new EntityInsertionAdapter<TransactionInput>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `TransactionInput` (`previousOutputTxHash`,`previousOutputIndex`,`sigScript`,`sequence`,`transactionHash`,`lockingScriptPayload`,`address`,`witness`) VALUES (?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TransactionInput entity) {
        statement.bindBlob(1, entity.getPreviousOutputTxHash());
        statement.bindLong(2, entity.getPreviousOutputIndex());
        statement.bindBlob(3, entity.getSigScript());
        statement.bindLong(4, entity.getSequence());
        statement.bindBlob(5, entity.getTransactionHash());
        if (entity.getLockingScriptPayload() == null) {
          statement.bindNull(6);
        } else {
          statement.bindBlob(6, entity.getLockingScriptPayload());
        }
        if (entity.getAddress() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getAddress());
        }
        final String _tmp = __witnessConverter.fromWitness(entity.getWitness());
        statement.bindString(8, _tmp);
      }
    };
    this.__deletionAdapterOfTransactionInput = new EntityDeletionOrUpdateAdapter<TransactionInput>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `TransactionInput` WHERE `previousOutputTxHash` = ? AND `previousOutputIndex` = ? AND `sequence` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TransactionInput entity) {
        statement.bindBlob(1, entity.getPreviousOutputTxHash());
        statement.bindLong(2, entity.getPreviousOutputIndex());
        statement.bindLong(3, entity.getSequence());
      }
    };
    this.__updateAdapterOfTransactionInput = new EntityDeletionOrUpdateAdapter<TransactionInput>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR REPLACE `TransactionInput` SET `previousOutputTxHash` = ?,`previousOutputIndex` = ?,`sigScript` = ?,`sequence` = ?,`transactionHash` = ?,`lockingScriptPayload` = ?,`address` = ?,`witness` = ? WHERE `previousOutputTxHash` = ? AND `previousOutputIndex` = ? AND `sequence` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TransactionInput entity) {
        statement.bindBlob(1, entity.getPreviousOutputTxHash());
        statement.bindLong(2, entity.getPreviousOutputIndex());
        statement.bindBlob(3, entity.getSigScript());
        statement.bindLong(4, entity.getSequence());
        statement.bindBlob(5, entity.getTransactionHash());
        if (entity.getLockingScriptPayload() == null) {
          statement.bindNull(6);
        } else {
          statement.bindBlob(6, entity.getLockingScriptPayload());
        }
        if (entity.getAddress() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getAddress());
        }
        final String _tmp = __witnessConverter.fromWitness(entity.getWitness());
        statement.bindString(8, _tmp);
        statement.bindBlob(9, entity.getPreviousOutputTxHash());
        statement.bindLong(10, entity.getPreviousOutputIndex());
        statement.bindLong(11, entity.getSequence());
      }
    };
    this.__preparedStmtOfDeleteByTxHash = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM TransactionInput WHERE transactionHash = ?";
        return _query;
      }
    };
  }

  @Override
  public void insert(final TransactionInput input) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfTransactionInput.insert(input);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final TransactionInput input) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfTransactionInput.handle(input);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteAll(final List<TransactionInput> inputs) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfTransactionInput.handleMultiple(inputs);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void update(final TransactionInput input) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __updateAdapterOfTransactionInput.handle(input);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public List<InputWithPreviousOutput> getInputsWithPrevouts(final List<byte[]> txHashes) {
    __db.beginTransaction();
    try {
      final List<InputWithPreviousOutput> _result;
      _result = TransactionInputDao.DefaultImpls.getInputsWithPrevouts(TransactionInputDao_Impl.this, txHashes);
      __db.setTransactionSuccessful();
      return _result;
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteByTxHash(final byte[] txHash) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteByTxHash.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, txHash);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDeleteByTxHash.release(_stmt);
    }
  }

  @Override
  public List<TransactionInput> getTransactionInputs(final byte[] hash) {
    final String _sql = "select * from TransactionInput where transactionHash = ? order by rowId";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPreviousOutputTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputTxHash");
      final int _cursorIndexOfPreviousOutputIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputIndex");
      final int _cursorIndexOfSigScript = CursorUtil.getColumnIndexOrThrow(_cursor, "sigScript");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfWitness = CursorUtil.getColumnIndexOrThrow(_cursor, "witness");
      final List<TransactionInput> _result = new ArrayList<TransactionInput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionInput _item;
        final byte[] _tmpPreviousOutputTxHash;
        _tmpPreviousOutputTxHash = _cursor.getBlob(_cursorIndexOfPreviousOutputTxHash);
        final long _tmpPreviousOutputIndex;
        _tmpPreviousOutputIndex = _cursor.getLong(_cursorIndexOfPreviousOutputIndex);
        final byte[] _tmpSigScript;
        _tmpSigScript = _cursor.getBlob(_cursorIndexOfSigScript);
        final long _tmpSequence;
        _tmpSequence = _cursor.getLong(_cursorIndexOfSequence);
        _item = new TransactionInput(_tmpPreviousOutputTxHash,_tmpPreviousOutputIndex,_tmpSigScript,_tmpSequence);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item.setTransactionHash(_tmpTransactionHash);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item.setAddress(_tmpAddress);
        final List<byte[]> _tmpWitness;
        final String _tmp;
        _tmp = _cursor.getString(_cursorIndexOfWitness);
        _tmpWitness = __witnessConverter.toWitness(_tmp);
        _item.setWitness(_tmpWitness);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<TransactionInput> getTransactionInputs(final List<byte[]> hashes) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("select * from TransactionInput where transactionHash IN (");
    final int _inputSize = hashes.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (byte[] _item : hashes) {
      _statement.bindBlob(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPreviousOutputTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputTxHash");
      final int _cursorIndexOfPreviousOutputIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputIndex");
      final int _cursorIndexOfSigScript = CursorUtil.getColumnIndexOrThrow(_cursor, "sigScript");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfWitness = CursorUtil.getColumnIndexOrThrow(_cursor, "witness");
      final List<TransactionInput> _result = new ArrayList<TransactionInput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionInput _item_1;
        final byte[] _tmpPreviousOutputTxHash;
        _tmpPreviousOutputTxHash = _cursor.getBlob(_cursorIndexOfPreviousOutputTxHash);
        final long _tmpPreviousOutputIndex;
        _tmpPreviousOutputIndex = _cursor.getLong(_cursorIndexOfPreviousOutputIndex);
        final byte[] _tmpSigScript;
        _tmpSigScript = _cursor.getBlob(_cursorIndexOfSigScript);
        final long _tmpSequence;
        _tmpSequence = _cursor.getLong(_cursorIndexOfSequence);
        _item_1 = new TransactionInput(_tmpPreviousOutputTxHash,_tmpPreviousOutputIndex,_tmpSigScript,_tmpSequence);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item_1.setTransactionHash(_tmpTransactionHash);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item_1.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item_1.setAddress(_tmpAddress);
        final List<byte[]> _tmpWitness;
        final String _tmp;
        _tmp = _cursor.getString(_cursorIndexOfWitness);
        _tmpWitness = __witnessConverter.toWitness(_tmp);
        _item_1.setWitness(_tmpWitness);
        _result.add(_item_1);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public TransactionOutput output(final byte[] transactionHash, final long index) {
    final String _sql = "select * from TransactionOutput where transactionHash=? AND `index`=? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, transactionHash);
    _argIndex = 2;
    _statement.bindLong(_argIndex, index);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final TransactionOutput _result;
      if (_cursor.moveToFirst()) {
        _result = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _result.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _result.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _result.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _result.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _result.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _result.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _result.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _result.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _result.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _result.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _result.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _result.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _result.setPluginData(_tmpPluginData);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<TransactionInput> getInputsByPrevOutputTxHash(final byte[] txHash) {
    final String _sql = "SELECT * FROM TransactionInput WHERE previousOutputTxHash = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, txHash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPreviousOutputTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputTxHash");
      final int _cursorIndexOfPreviousOutputIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputIndex");
      final int _cursorIndexOfSigScript = CursorUtil.getColumnIndexOrThrow(_cursor, "sigScript");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfWitness = CursorUtil.getColumnIndexOrThrow(_cursor, "witness");
      final List<TransactionInput> _result = new ArrayList<TransactionInput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionInput _item;
        final byte[] _tmpPreviousOutputTxHash;
        _tmpPreviousOutputTxHash = _cursor.getBlob(_cursorIndexOfPreviousOutputTxHash);
        final long _tmpPreviousOutputIndex;
        _tmpPreviousOutputIndex = _cursor.getLong(_cursorIndexOfPreviousOutputIndex);
        final byte[] _tmpSigScript;
        _tmpSigScript = _cursor.getBlob(_cursorIndexOfSigScript);
        final long _tmpSequence;
        _tmpSequence = _cursor.getLong(_cursorIndexOfSequence);
        _item = new TransactionInput(_tmpPreviousOutputTxHash,_tmpPreviousOutputIndex,_tmpSigScript,_tmpSequence);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item.setTransactionHash(_tmpTransactionHash);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item.setAddress(_tmpAddress);
        final List<byte[]> _tmpWitness;
        final String _tmp;
        _tmp = _cursor.getString(_cursorIndexOfWitness);
        _tmpWitness = __witnessConverter.toWitness(_tmp);
        _item.setWitness(_tmpWitness);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public TransactionInput getInput(final byte[] prevOutputTxHash, final long prevOutputIndex) {
    final String _sql = "SELECT * FROM TransactionInput where TransactionInput.previousOutputTxHash = ? and TransactionInput.previousOutputIndex = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, prevOutputTxHash);
    _argIndex = 2;
    _statement.bindLong(_argIndex, prevOutputIndex);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPreviousOutputTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputTxHash");
      final int _cursorIndexOfPreviousOutputIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "previousOutputIndex");
      final int _cursorIndexOfSigScript = CursorUtil.getColumnIndexOrThrow(_cursor, "sigScript");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfWitness = CursorUtil.getColumnIndexOrThrow(_cursor, "witness");
      final TransactionInput _result;
      if (_cursor.moveToFirst()) {
        final byte[] _tmpPreviousOutputTxHash;
        _tmpPreviousOutputTxHash = _cursor.getBlob(_cursorIndexOfPreviousOutputTxHash);
        final long _tmpPreviousOutputIndex;
        _tmpPreviousOutputIndex = _cursor.getLong(_cursorIndexOfPreviousOutputIndex);
        final byte[] _tmpSigScript;
        _tmpSigScript = _cursor.getBlob(_cursorIndexOfSigScript);
        final long _tmpSequence;
        _tmpSequence = _cursor.getLong(_cursorIndexOfSequence);
        _result = new TransactionInput(_tmpPreviousOutputTxHash,_tmpPreviousOutputIndex,_tmpSigScript,_tmpSequence);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _result.setTransactionHash(_tmpTransactionHash);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _result.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _result.setAddress(_tmpAddress);
        final List<byte[]> _tmpWitness;
        final String _tmp;
        _tmp = _cursor.getString(_cursorIndexOfWitness);
        _tmpWitness = __witnessConverter.toWitness(_tmp);
        _result.setWitness(_tmpWitness);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
