package io.horizontalsystems.bitcoincore.storage;

import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.BlockHashPublicKey;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class BlockHashPublicKeyDao_Impl implements BlockHashPublicKeyDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<BlockHashPublicKey> __insertionAdapterOfBlockHashPublicKey;

  public BlockHashPublicKeyDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfBlockHashPublicKey = new EntityInsertionAdapter<BlockHashPublicKey>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `BlockHashPublicKey` (`blockHash`,`publicKeyPath`) VALUES (?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BlockHashPublicKey entity) {
        statement.bindBlob(1, entity.getBlockHash());
        statement.bindString(2, entity.getPublicKeyPath());
      }
    };
  }

  @Override
  public void insertAll(final List<BlockHashPublicKey> users) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfBlockHashPublicKey.insert(users);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
