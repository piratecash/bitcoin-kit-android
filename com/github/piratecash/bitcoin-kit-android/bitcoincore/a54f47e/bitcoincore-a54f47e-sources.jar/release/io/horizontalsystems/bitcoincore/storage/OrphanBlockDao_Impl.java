package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.MerkleBlock;
import io.horizontalsystems.bitcoincore.models.OrphanBlock;
import io.horizontalsystems.bitcoincore.models.converters.MerkleBlockConverter;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class OrphanBlockDao_Impl implements OrphanBlockDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<OrphanBlock> __insertionAdapterOfOrphanBlock;

  private final MerkleBlockConverter __merkleBlockConverter = new MerkleBlockConverter();

  private final EntityDeletionOrUpdateAdapter<OrphanBlock> __deletionAdapterOfOrphanBlock;

  public OrphanBlockDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfOrphanBlock = new EntityInsertionAdapter<OrphanBlock>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `OrphanBlock` (`block_version`,`previousBlockHash`,`merkleRoot`,`block_timestamp`,`bits`,`nonce`,`hasTransactions`,`headerHash`,`merkleBlock`) VALUES (?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final OrphanBlock entity) {
        statement.bindLong(1, entity.getVersion());
        statement.bindBlob(2, entity.getPreviousBlockHash());
        statement.bindBlob(3, entity.getMerkleRoot());
        statement.bindLong(4, entity.getTimestamp());
        statement.bindLong(5, entity.getBits());
        statement.bindLong(6, entity.getNonce());
        final int _tmp = entity.getHasTransactions() ? 1 : 0;
        statement.bindLong(7, _tmp);
        statement.bindBlob(8, entity.getHeaderHash());
        final String _tmp_1 = __merkleBlockConverter.fromMerkleBlock(entity.getMerkleBlock());
        if (_tmp_1 == null) {
          statement.bindNull(9);
        } else {
          statement.bindString(9, _tmp_1);
        }
      }
    };
    this.__deletionAdapterOfOrphanBlock = new EntityDeletionOrUpdateAdapter<OrphanBlock>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `OrphanBlock` WHERE `headerHash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final OrphanBlock entity) {
        statement.bindBlob(1, entity.getHeaderHash());
      }
    };
  }

  @Override
  public void insert(final OrphanBlock block) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfOrphanBlock.insert(block);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final OrphanBlock block) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfOrphanBlock.handle(block);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteAll(final List<OrphanBlock> blocks) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfOrphanBlock.handleMultiple(blocks);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public OrphanBlock getOrphanBlockByHash(final byte[] hash) {
    final String _sql = "SELECT * FROM OrphanBlock WHERE headerHash = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfMerkleBlock = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleBlock");
      final OrphanBlock _result;
      if (_cursor.moveToFirst()) {
        _result = new OrphanBlock();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final MerkleBlock _tmpMerkleBlock;
        final String _tmp_1;
        if (_cursor.isNull(_cursorIndexOfMerkleBlock)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getString(_cursorIndexOfMerkleBlock);
        }
        _tmpMerkleBlock = __merkleBlockConverter.toMerkleBlock(_tmp_1);
        _result.setMerkleBlock(_tmpMerkleBlock);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public OrphanBlock getOrphanChild(final byte[] parentHash) {
    final String _sql = "SELECT * FROM OrphanBlock WHERE previousBlockHash = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, parentHash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfMerkleBlock = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleBlock");
      final OrphanBlock _result;
      if (_cursor.moveToFirst()) {
        _result = new OrphanBlock();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final MerkleBlock _tmpMerkleBlock;
        final String _tmp_1;
        if (_cursor.isNull(_cursorIndexOfMerkleBlock)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getString(_cursorIndexOfMerkleBlock);
        }
        _tmpMerkleBlock = __merkleBlockConverter.toMerkleBlock(_tmp_1);
        _result.setMerkleBlock(_tmpMerkleBlock);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<OrphanBlock> getOrphanBlocks() {
    final String _sql = "SELECT * FROM OrphanBlock";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfMerkleBlock = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleBlock");
      final List<OrphanBlock> _result = new ArrayList<OrphanBlock>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final OrphanBlock _item;
        _item = new OrphanBlock();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _item.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _item.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _item.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _item.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _item.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _item.setHeaderHash(_tmpHeaderHash);
        final MerkleBlock _tmpMerkleBlock;
        final String _tmp_1;
        if (_cursor.isNull(_cursorIndexOfMerkleBlock)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getString(_cursorIndexOfMerkleBlock);
        }
        _tmpMerkleBlock = __merkleBlockConverter.toMerkleBlock(_tmp_1);
        _item.setMerkleBlock(_tmpMerkleBlock);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
