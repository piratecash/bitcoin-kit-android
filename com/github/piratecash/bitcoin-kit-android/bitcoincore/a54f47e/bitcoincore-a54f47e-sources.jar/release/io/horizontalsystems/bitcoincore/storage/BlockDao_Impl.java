package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.Block;
import java.lang.Class;
import java.lang.Long;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class BlockDao_Impl implements BlockDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Block> __insertionAdapterOfBlock;

  private final EntityDeletionOrUpdateAdapter<Block> __deletionAdapterOfBlock;

  private final EntityDeletionOrUpdateAdapter<Block> __updateAdapterOfBlock;

  private final SharedSQLiteStatement __preparedStmtOfSetBlockPartial;

  private final SharedSQLiteStatement __preparedStmtOfDeleteBlocksWithoutTransactions;

  private final SharedSQLiteStatement __preparedStmtOfUnstaleAllBlocks;

  public BlockDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfBlock = new EntityInsertionAdapter<Block>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `Block` (`block_version`,`previousBlockHash`,`merkleRoot`,`block_timestamp`,`bits`,`nonce`,`hasTransactions`,`headerHash`,`height`,`stale`,`partial`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Block entity) {
        statement.bindLong(1, entity.getVersion());
        statement.bindBlob(2, entity.getPreviousBlockHash());
        statement.bindBlob(3, entity.getMerkleRoot());
        statement.bindLong(4, entity.getTimestamp());
        statement.bindLong(5, entity.getBits());
        statement.bindLong(6, entity.getNonce());
        final int _tmp = entity.getHasTransactions() ? 1 : 0;
        statement.bindLong(7, _tmp);
        statement.bindBlob(8, entity.getHeaderHash());
        statement.bindLong(9, entity.getHeight());
        final int _tmp_1 = entity.getStale() ? 1 : 0;
        statement.bindLong(10, _tmp_1);
        final int _tmp_2 = entity.getPartial() ? 1 : 0;
        statement.bindLong(11, _tmp_2);
      }
    };
    this.__deletionAdapterOfBlock = new EntityDeletionOrUpdateAdapter<Block>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `Block` WHERE `headerHash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Block entity) {
        statement.bindBlob(1, entity.getHeaderHash());
      }
    };
    this.__updateAdapterOfBlock = new EntityDeletionOrUpdateAdapter<Block>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR REPLACE `Block` SET `block_version` = ?,`previousBlockHash` = ?,`merkleRoot` = ?,`block_timestamp` = ?,`bits` = ?,`nonce` = ?,`hasTransactions` = ?,`headerHash` = ?,`height` = ?,`stale` = ?,`partial` = ? WHERE `headerHash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Block entity) {
        statement.bindLong(1, entity.getVersion());
        statement.bindBlob(2, entity.getPreviousBlockHash());
        statement.bindBlob(3, entity.getMerkleRoot());
        statement.bindLong(4, entity.getTimestamp());
        statement.bindLong(5, entity.getBits());
        statement.bindLong(6, entity.getNonce());
        final int _tmp = entity.getHasTransactions() ? 1 : 0;
        statement.bindLong(7, _tmp);
        statement.bindBlob(8, entity.getHeaderHash());
        statement.bindLong(9, entity.getHeight());
        final int _tmp_1 = entity.getStale() ? 1 : 0;
        statement.bindLong(10, _tmp_1);
        final int _tmp_2 = entity.getPartial() ? 1 : 0;
        statement.bindLong(11, _tmp_2);
        statement.bindBlob(12, entity.getHeaderHash());
      }
    };
    this.__preparedStmtOfSetBlockPartial = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE Block SET partial = 1 WHERE headerHash = ?";
        return _query;
      }
    };
    this.__preparedStmtOfDeleteBlocksWithoutTransactions = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM Block WHERE height < ? AND hasTransactions = 0";
        return _query;
      }
    };
    this.__preparedStmtOfUnstaleAllBlocks = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE Block SET stale = 0";
        return _query;
      }
    };
  }

  @Override
  public void insert(final Block block) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfBlock.insert(block);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final Block block) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfBlock.handle(block);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteAll(final List<Block> blocks) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfBlock.handleMultiple(blocks);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void update(final Block block) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __updateAdapterOfBlock.handle(block);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void setBlockPartial(final byte[] headerHash) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfSetBlockPartial.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, headerHash);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfSetBlockPartial.release(_stmt);
    }
  }

  @Override
  public void deleteBlocksWithoutTransactions(final int toHeight) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteBlocksWithoutTransactions.acquire();
    int _argIndex = 1;
    _stmt.bindLong(_argIndex, toHeight);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDeleteBlocksWithoutTransactions.release(_stmt);
    }
  }

  @Override
  public void unstaleAllBlocks() {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfUnstaleAllBlocks.acquire();
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfUnstaleAllBlocks.release(_stmt);
    }
  }

  @Override
  public Block getLast(final boolean stale) {
    final String _sql = "SELECT * FROM Block WHERE stale = ? ORDER BY height DESC limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    final int _tmp = stale ? 1 : 0;
    _statement.bindLong(_argIndex, _tmp);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp_1 != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_2 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_3 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Block getFirst(final boolean stale) {
    final String _sql = "SELECT * FROM Block WHERE stale = ? ORDER BY height ASC limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    final int _tmp = stale ? 1 : 0;
    _statement.bindLong(_argIndex, _tmp);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp_1 != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_2 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_3 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Block getLastBlock() {
    final String _sql = "SELECT * FROM Block ORDER BY height DESC limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Block getLastBlockWithTransactions() {
    final String _sql = "SELECT * FROM Block WHERE hasTransactions = 1 ORDER BY height DESC limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Block> getBlocks(final List<byte[]> hashes) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("SELECT * FROM Block WHERE headerHash IN (");
    final int _inputSize = hashes.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (byte[] _item : hashes) {
      _statement.bindBlob(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final List<Block> _result = new ArrayList<Block>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Block _item_1;
        _item_1 = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item_1.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _item_1.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _item_1.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item_1.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _item_1.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _item_1.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _item_1.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _item_1.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _item_1.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _item_1.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _item_1.setPartial(_tmpPartial);
        _result.add(_item_1);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Block> getBlocks(final int heightGreaterOrEqualTo, final boolean stale) {
    final String _sql = "SELECT * FROM Block WHERE height >= ? AND stale = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, heightGreaterOrEqualTo);
    _argIndex = 2;
    final int _tmp = stale ? 1 : 0;
    _statement.bindLong(_argIndex, _tmp);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final List<Block> _result = new ArrayList<Block>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Block _item;
        _item = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _item.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _item.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _item.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _item.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp_1 != 0;
        _item.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _item.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _item.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_2 != 0;
        _item.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_3 != 0;
        _item.setPartial(_tmpPartial);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Block> getBlocks(final int heightGreaterThan, final int limit) {
    final String _sql = "SELECT * FROM Block WHERE height > ? ORDER BY height DESC LIMIT ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, heightGreaterThan);
    _argIndex = 2;
    _statement.bindLong(_argIndex, limit);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final List<Block> _result = new ArrayList<Block>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Block _item;
        _item = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _item.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _item.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _item.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _item.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _item.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _item.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _item.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _item.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _item.setPartial(_tmpPartial);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public int getBlocksCount(final List<byte[]> hashes) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("SELECT COUNT(headerHash) FROM Block WHERE headerHash IN (");
    final int _inputSize = hashes.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (byte[] _item : hashes) {
      _statement.bindBlob(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _result;
      if (_cursor.moveToFirst()) {
        _result = _cursor.getInt(0);
      } else {
        _result = 0;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Block> getBlocksByStale(final boolean stale) {
    final String _sql = "SELECT * FROM Block WHERE stale = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    final int _tmp = stale ? 1 : 0;
    _statement.bindLong(_argIndex, _tmp);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final List<Block> _result = new ArrayList<Block>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Block _item;
        _item = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _item.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _item.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _item.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _item.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp_1 != 0;
        _item.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _item.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _item.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_2 != 0;
        _item.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_3 != 0;
        _item.setPartial(_tmpPartial);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Block> getBlocksChunk(final int fromHeight, final int toHeight) {
    final String _sql = "SELECT * FROM Block WHERE height >= ? AND height <= ? ORDER BY height ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, fromHeight);
    _argIndex = 2;
    _statement.bindLong(_argIndex, toHeight);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final List<Block> _result = new ArrayList<Block>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Block _item;
        _item = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _item.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _item.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _item.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _item.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _item.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _item.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _item.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _item.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _item.setPartial(_tmpPartial);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Block getBlockByHash(final byte[] hash) {
    final String _sql = "SELECT * FROM Block WHERE headerHash = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Block getBlockByHeight(final int height) {
    final String _sql = "SELECT * FROM Block WHERE height = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, height);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Block getBlockByHeightStalePrioritized(final int height) {
    final String _sql = "SELECT * FROM Block WHERE height = ? ORDER by stale DESC limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, height);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Block getBlockByHeightStalePrioritizedByHash(final byte[] hash) {
    final String _sql = "SELECT * FROM Block WHERE headerHash = ? ORDER by stale DESC limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final Block _result;
      if (_cursor.moveToFirst()) {
        _result = new Block();
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final byte[] _tmpPreviousBlockHash;
        _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
        _result.setPreviousBlockHash(_tmpPreviousBlockHash);
        final byte[] _tmpMerkleRoot;
        _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
        _result.setMerkleRoot(_tmpMerkleRoot);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final long _tmpBits;
        _tmpBits = _cursor.getLong(_cursorIndexOfBits);
        _result.setBits(_tmpBits);
        final long _tmpNonce;
        _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
        _result.setNonce(_tmpNonce);
        final boolean _tmpHasTransactions;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfHasTransactions);
        _tmpHasTransactions = _tmp != 0;
        _result.setHasTransactions(_tmpHasTransactions);
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        _result.setHeaderHash(_tmpHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        _result.setHeight(_tmpHeight);
        final boolean _tmpStale;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfStale);
        _tmpStale = _tmp_1 != 0;
        _result.setStale(_tmpStale);
        final boolean _tmpPartial;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfPartial);
        _tmpPartial = _tmp_2 != 0;
        _result.setPartial(_tmpPartial);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public int count() {
    final String _sql = "SELECT COUNT(headerHash) FROM Block";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _result;
      if (_cursor.moveToFirst()) {
        _result = _cursor.getInt(0);
      } else {
        _result = 0;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Long> getTimestamps(final int from, final int to) {
    final String _sql = "SELECT block_timestamp FROM Block WHERE height >= ? AND height <= ? ORDER BY block_timestamp ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, from);
    _argIndex = 2;
    _statement.bindLong(_argIndex, to);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final List<Long> _result = new ArrayList<Long>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Long _item;
        _item = _cursor.getLong(0);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
