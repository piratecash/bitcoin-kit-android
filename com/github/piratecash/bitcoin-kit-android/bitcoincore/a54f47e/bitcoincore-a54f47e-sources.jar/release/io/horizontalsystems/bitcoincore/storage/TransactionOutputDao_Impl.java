package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.Block;
import io.horizontalsystems.bitcoincore.models.PublicKey;
import io.horizontalsystems.bitcoincore.models.ScriptTypeConverter;
import io.horizontalsystems.bitcoincore.models.Transaction;
import io.horizontalsystems.bitcoincore.models.TransactionOutput;
import io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType;
import java.lang.Byte;
import java.lang.Class;
import java.lang.IllegalStateException;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class TransactionOutputDao_Impl implements TransactionOutputDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<TransactionOutput> __insertionAdapterOfTransactionOutput;

  private final ScriptTypeConverter __scriptTypeConverter = new ScriptTypeConverter();

  private final EntityDeletionOrUpdateAdapter<TransactionOutput> __deletionAdapterOfTransactionOutput;

  private final EntityDeletionOrUpdateAdapter<TransactionOutput> __updateAdapterOfTransactionOutput;

  private final SharedSQLiteStatement __preparedStmtOfDeleteByTxHash;

  private final SharedSQLiteStatement __preparedStmtOfMarkFailedToSpend;

  public TransactionOutputDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfTransactionOutput = new EntityInsertionAdapter<TransactionOutput>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `TransactionOutput` (`value`,`lockingScript`,`redeemScript`,`index`,`transactionHash`,`publicKeyPath`,`changeOutput`,`scriptType`,`lockingScriptPayload`,`address`,`failedToSpend`,`pluginId`,`pluginData`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TransactionOutput entity) {
        statement.bindLong(1, entity.getValue());
        statement.bindBlob(2, entity.getLockingScript());
        if (entity.getRedeemScript() == null) {
          statement.bindNull(3);
        } else {
          statement.bindBlob(3, entity.getRedeemScript());
        }
        statement.bindLong(4, entity.getIndex());
        statement.bindBlob(5, entity.getTransactionHash());
        if (entity.getPublicKeyPath() == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, entity.getPublicKeyPath());
        }
        final int _tmp = entity.getChangeOutput() ? 1 : 0;
        statement.bindLong(7, _tmp);
        final Integer _tmp_1 = __scriptTypeConverter.scriptTypeToInt(entity.getScriptType());
        if (_tmp_1 == null) {
          statement.bindNull(8);
        } else {
          statement.bindLong(8, _tmp_1);
        }
        if (entity.getLockingScriptPayload() == null) {
          statement.bindNull(9);
        } else {
          statement.bindBlob(9, entity.getLockingScriptPayload());
        }
        if (entity.getAddress() == null) {
          statement.bindNull(10);
        } else {
          statement.bindString(10, entity.getAddress());
        }
        final int _tmp_2 = entity.getFailedToSpend() ? 1 : 0;
        statement.bindLong(11, _tmp_2);
        if (entity.getPluginId() == null) {
          statement.bindNull(12);
        } else {
          statement.bindLong(12, entity.getPluginId());
        }
        if (entity.getPluginData() == null) {
          statement.bindNull(13);
        } else {
          statement.bindString(13, entity.getPluginData());
        }
      }
    };
    this.__deletionAdapterOfTransactionOutput = new EntityDeletionOrUpdateAdapter<TransactionOutput>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `TransactionOutput` WHERE `transactionHash` = ? AND `index` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TransactionOutput entity) {
        statement.bindBlob(1, entity.getTransactionHash());
        statement.bindLong(2, entity.getIndex());
      }
    };
    this.__updateAdapterOfTransactionOutput = new EntityDeletionOrUpdateAdapter<TransactionOutput>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR REPLACE `TransactionOutput` SET `value` = ?,`lockingScript` = ?,`redeemScript` = ?,`index` = ?,`transactionHash` = ?,`publicKeyPath` = ?,`changeOutput` = ?,`scriptType` = ?,`lockingScriptPayload` = ?,`address` = ?,`failedToSpend` = ?,`pluginId` = ?,`pluginData` = ? WHERE `transactionHash` = ? AND `index` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TransactionOutput entity) {
        statement.bindLong(1, entity.getValue());
        statement.bindBlob(2, entity.getLockingScript());
        if (entity.getRedeemScript() == null) {
          statement.bindNull(3);
        } else {
          statement.bindBlob(3, entity.getRedeemScript());
        }
        statement.bindLong(4, entity.getIndex());
        statement.bindBlob(5, entity.getTransactionHash());
        if (entity.getPublicKeyPath() == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, entity.getPublicKeyPath());
        }
        final int _tmp = entity.getChangeOutput() ? 1 : 0;
        statement.bindLong(7, _tmp);
        final Integer _tmp_1 = __scriptTypeConverter.scriptTypeToInt(entity.getScriptType());
        if (_tmp_1 == null) {
          statement.bindNull(8);
        } else {
          statement.bindLong(8, _tmp_1);
        }
        if (entity.getLockingScriptPayload() == null) {
          statement.bindNull(9);
        } else {
          statement.bindBlob(9, entity.getLockingScriptPayload());
        }
        if (entity.getAddress() == null) {
          statement.bindNull(10);
        } else {
          statement.bindString(10, entity.getAddress());
        }
        final int _tmp_2 = entity.getFailedToSpend() ? 1 : 0;
        statement.bindLong(11, _tmp_2);
        if (entity.getPluginId() == null) {
          statement.bindNull(12);
        } else {
          statement.bindLong(12, entity.getPluginId());
        }
        if (entity.getPluginData() == null) {
          statement.bindNull(13);
        } else {
          statement.bindString(13, entity.getPluginData());
        }
        statement.bindBlob(14, entity.getTransactionHash());
        statement.bindLong(15, entity.getIndex());
      }
    };
    this.__preparedStmtOfDeleteByTxHash = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM TransactionOutput WHERE transactionHash = ?";
        return _query;
      }
    };
    this.__preparedStmtOfMarkFailedToSpend = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE `transactionOutput` SET failedToSpend = 1 WHERE transactionHash = ? AND `index` = ?";
        return _query;
      }
    };
  }

  @Override
  public void insert(final TransactionOutput output) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfTransactionOutput.insert(output);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final TransactionOutput output) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfTransactionOutput.handle(output);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteAll(final List<TransactionOutput> outputs) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfTransactionOutput.handleMultiple(outputs);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void update(final TransactionOutput output) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __updateAdapterOfTransactionOutput.handle(output);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteByTxHash(final byte[] txHash) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteByTxHash.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, txHash);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDeleteByTxHash.release(_stmt);
    }
  }

  @Override
  public void markFailedToSpend(final byte[] transactionHash, final int index) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfMarkFailedToSpend.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, transactionHash);
    _argIndex = 2;
    _stmt.bindLong(_argIndex, index);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfMarkFailedToSpend.release(_stmt);
    }
  }

  @Override
  public List<TransactionOutput> getTransactionsOutputs(final List<byte[]> txHashes) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("select * from transactionOutput where transactionHash in (");
    final int _inputSize = txHashes.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (byte[] _item : txHashes) {
      _statement.bindBlob(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final List<TransactionOutput> _result = new ArrayList<TransactionOutput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionOutput _item_1;
        _item_1 = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _item_1.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _item_1.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _item_1.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item_1.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item_1.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _item_1.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _item_1.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _item_1.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item_1.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item_1.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _item_1.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _item_1.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _item_1.setPluginData(_tmpPluginData);
        _result.add(_item_1);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public int getCountByHash(final byte[] hash) {
    final String _sql = "select count(*) from TransactionOutput where transactionHash = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _result;
      if (_cursor.moveToFirst()) {
        _result = _cursor.getInt(0);
      } else {
        _result = 0;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<UnspentOutput> getUnspents() {
    final String _sql = "\n"
            + "        SELECT TransactionOutput.*, PublicKey.*, `Transaction`.*, Block.*\n"
            + "        FROM TransactionOutput\n"
            + "          INNER JOIN PublicKey ON TransactionOutput.publicKeyPath = PublicKey.path\n"
            + "          INNER JOIN `Transaction` ON TransactionOutput.transactionHash = `Transaction`.hash\n"
            + "          LEFT JOIN Block ON `Transaction`.blockHash = Block.headerHash\n"
            + "        WHERE TransactionOutput.scriptType != 0 AND `Transaction`.conflictingTxHash IS NULL\n"
            + "          AND NOT EXISTS (SELECT previousOutputIndex FROM TransactionInput where TransactionInput.previousOutputTxHash = TransactionOutput.transactionHash and TransactionInput.previousOutputIndex = TransactionOutput.`index`)\n"
            + "    ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex_1 = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final int _cursorIndexOfVersion_1 = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp_1 = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final List<UnspentOutput> _result = new ArrayList<UnspentOutput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final UnspentOutput _item;
        final TransactionOutput _tmpOutput;
        _tmpOutput = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _tmpOutput.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _tmpOutput.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _tmpOutput.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _tmpOutput.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _tmpOutput.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _tmpOutput.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _tmpOutput.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _tmpOutput.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _tmpOutput.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _tmpOutput.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _tmpOutput.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _tmpOutput.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _tmpOutput.setPluginData(_tmpPluginData);
        final PublicKey _tmpPublicKey;
        _tmpPublicKey = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _tmpPublicKey.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _tmpPublicKey.setAccount(_tmpAccount);
        final int _tmpIndex_1;
        _tmpIndex_1 = _cursor.getInt(_cursorIndexOfIndex_1);
        _tmpPublicKey.setIndex(_tmpIndex_1);
        final boolean _tmpExternal;
        final int _tmp_4;
        _tmp_4 = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp_4 != 0;
        _tmpPublicKey.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _tmpPublicKey.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey_1;
        _tmpPublicKey_1 = _cursor.getBlob(_cursorIndexOfPublicKey);
        _tmpPublicKey.setPublicKey(_tmpPublicKey_1);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _tmpPublicKey.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _tmpPublicKey.setConvertedForP2TR(_tmpConvertedForP2TR);
        final Transaction _tmpTransaction;
        _tmpTransaction = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _tmpTransaction.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _tmpTransaction.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _tmpTransaction.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _tmpTransaction.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _tmpTransaction.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _tmpTransaction.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _tmpTransaction.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp_5;
        _tmp_5 = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp_5 != 0;
        _tmpTransaction.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_6;
        _tmp_6 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_6 != 0;
        _tmpTransaction.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_7;
        _tmp_7 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_7 != 0;
        _tmpTransaction.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _tmpTransaction.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _tmpTransaction.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _tmpTransaction.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _tmpTransaction.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _tmpTransaction.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _tmpTransaction.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _tmpTransaction.setType(_tmpType);
        final Block _tmpBlock;
        if (!(_cursor.isNull(_cursorIndexOfVersion_1) && _cursor.isNull(_cursorIndexOfPreviousBlockHash) && _cursor.isNull(_cursorIndexOfMerkleRoot) && _cursor.isNull(_cursorIndexOfTimestamp_1) && _cursor.isNull(_cursorIndexOfBits) && _cursor.isNull(_cursorIndexOfNonce) && _cursor.isNull(_cursorIndexOfHasTransactions) && _cursor.isNull(_cursorIndexOfHeaderHash) && _cursor.isNull(_cursorIndexOfHeight) && _cursor.isNull(_cursorIndexOfStale) && _cursor.isNull(_cursorIndexOfPartial))) {
          _tmpBlock = new Block();
          final int _tmpVersion_1;
          _tmpVersion_1 = _cursor.getInt(_cursorIndexOfVersion_1);
          _tmpBlock.setVersion(_tmpVersion_1);
          final byte[] _tmpPreviousBlockHash;
          _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
          _tmpBlock.setPreviousBlockHash(_tmpPreviousBlockHash);
          final byte[] _tmpMerkleRoot;
          _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
          _tmpBlock.setMerkleRoot(_tmpMerkleRoot);
          final long _tmpTimestamp_1;
          _tmpTimestamp_1 = _cursor.getLong(_cursorIndexOfTimestamp_1);
          _tmpBlock.setTimestamp(_tmpTimestamp_1);
          final long _tmpBits;
          _tmpBits = _cursor.getLong(_cursorIndexOfBits);
          _tmpBlock.setBits(_tmpBits);
          final long _tmpNonce;
          _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
          _tmpBlock.setNonce(_tmpNonce);
          final boolean _tmpHasTransactions;
          final int _tmp_8;
          _tmp_8 = _cursor.getInt(_cursorIndexOfHasTransactions);
          _tmpHasTransactions = _tmp_8 != 0;
          _tmpBlock.setHasTransactions(_tmpHasTransactions);
          final byte[] _tmpHeaderHash;
          _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
          _tmpBlock.setHeaderHash(_tmpHeaderHash);
          final int _tmpHeight;
          _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
          _tmpBlock.setHeight(_tmpHeight);
          final boolean _tmpStale;
          final int _tmp_9;
          _tmp_9 = _cursor.getInt(_cursorIndexOfStale);
          _tmpStale = _tmp_9 != 0;
          _tmpBlock.setStale(_tmpStale);
          final boolean _tmpPartial;
          final int _tmp_10;
          _tmp_10 = _cursor.getInt(_cursorIndexOfPartial);
          _tmpPartial = _tmp_10 != 0;
          _tmpBlock.setPartial(_tmpPartial);
        } else {
          _tmpBlock = null;
        }
        _item = new UnspentOutput(_tmpOutput,_tmpPublicKey,_tmpTransaction,_tmpBlock);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public TransactionOutput getPreviousOutput(final byte[] previousOutputTxHash,
      final int previousOutputIndex) {
    final String _sql = "select * from TransactionOutput where transactionHash = ? and `index` = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, previousOutputTxHash);
    _argIndex = 2;
    _statement.bindLong(_argIndex, previousOutputIndex);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final TransactionOutput _result;
      if (_cursor.moveToFirst()) {
        _result = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _result.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _result.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _result.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _result.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _result.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _result.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _result.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _result.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _result.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _result.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _result.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _result.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _result.setPluginData(_tmpPluginData);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<TransactionOutput> getByHash(final byte[] hash) {
    final String _sql = "select * from TransactionOutput where transactionHash = ? order by rowId";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final List<TransactionOutput> _result = new ArrayList<TransactionOutput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionOutput _item;
        _item = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _item.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _item.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _item.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _item.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _item.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _item.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _item.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _item.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _item.setPluginData(_tmpPluginData);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<TransactionOutput> getListByPath(final String path) {
    final String _sql = "select * from TransactionOutput where publicKeyPath = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindString(_argIndex, path);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final List<TransactionOutput> _result = new ArrayList<TransactionOutput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionOutput _item;
        _item = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _item.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _item.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _item.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _item.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _item.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _item.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _item.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _item.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _item.setPluginData(_tmpPluginData);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<TransactionOutput> getMyOutputs() {
    final String _sql = "SELECT * FROM TransactionOutput WHERE publicKeyPath IS NOT NULL";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final List<TransactionOutput> _result = new ArrayList<TransactionOutput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionOutput _item;
        _item = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _item.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _item.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _item.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _item.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _item.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _item.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _item.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _item.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _item.setPluginData(_tmpPluginData);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<TransactionOutput> getOutputsForBloomFilter(final int blockHeight,
      final List<Integer> irregularScriptTypes) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("\n");
    _stringBuilder.append("        SELECT outputs.*");
    _stringBuilder.append("\n");
    _stringBuilder.append("        FROM TransactionOutput AS outputs");
    _stringBuilder.append("\n");
    _stringBuilder.append("        INNER JOIN PublicKey as publicKey ON outputs.publicKeyPath = publicKey.path");
    _stringBuilder.append("\n");
    _stringBuilder.append("        LEFT JOIN (");
    _stringBuilder.append("\n");
    _stringBuilder.append("          SELECT");
    _stringBuilder.append("\n");
    _stringBuilder.append("            inputs.previousOutputIndex,");
    _stringBuilder.append("\n");
    _stringBuilder.append("            inputs.previousOutputTxHash,");
    _stringBuilder.append("\n");
    _stringBuilder.append("            inputs.transactionHash AS txHash,");
    _stringBuilder.append("\n");
    _stringBuilder.append("            Block.*");
    _stringBuilder.append("\n");
    _stringBuilder.append("          FROM TransactionInput AS inputs");
    _stringBuilder.append("\n");
    _stringBuilder.append("          INNER JOIN `Transaction` AS transactions ON inputs.transactionHash = transactions.hash");
    _stringBuilder.append("\n");
    _stringBuilder.append("          LEFT JOIN Block ON transactions.blockHash = Block.headerHash");
    _stringBuilder.append("\n");
    _stringBuilder.append("        )");
    _stringBuilder.append("\n");
    _stringBuilder.append("        AS input ON input.previousOutputTxHash = outputs.transactionHash AND input.previousOutputIndex = outputs.`index`");
    _stringBuilder.append("\n");
    _stringBuilder.append("        WHERE outputs.scriptType IN(");
    final int _inputSize = irregularScriptTypes.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(") AND (height IS NULL OR height > ");
    _stringBuilder.append("?");
    _stringBuilder.append(")");
    _stringBuilder.append("\n");
    _stringBuilder.append("    ");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 1 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (int _item : irregularScriptTypes) {
      _statement.bindLong(_argIndex, _item);
      _argIndex++;
    }
    _argIndex = 1 + _inputSize;
    _statement.bindLong(_argIndex, blockHeight);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfValue = CursorUtil.getColumnIndexOrThrow(_cursor, "value");
      final int _cursorIndexOfLockingScript = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScript");
      final int _cursorIndexOfRedeemScript = CursorUtil.getColumnIndexOrThrow(_cursor, "redeemScript");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "index");
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfPublicKeyPath = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyPath");
      final int _cursorIndexOfChangeOutput = CursorUtil.getColumnIndexOrThrow(_cursor, "changeOutput");
      final int _cursorIndexOfScriptType = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptType");
      final int _cursorIndexOfLockingScriptPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "lockingScriptPayload");
      final int _cursorIndexOfAddress = CursorUtil.getColumnIndexOrThrow(_cursor, "address");
      final int _cursorIndexOfFailedToSpend = CursorUtil.getColumnIndexOrThrow(_cursor, "failedToSpend");
      final int _cursorIndexOfPluginId = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginId");
      final int _cursorIndexOfPluginData = CursorUtil.getColumnIndexOrThrow(_cursor, "pluginData");
      final List<TransactionOutput> _result = new ArrayList<TransactionOutput>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionOutput _item_1;
        _item_1 = new TransactionOutput();
        final long _tmpValue;
        _tmpValue = _cursor.getLong(_cursorIndexOfValue);
        _item_1.setValue(_tmpValue);
        final byte[] _tmpLockingScript;
        _tmpLockingScript = _cursor.getBlob(_cursorIndexOfLockingScript);
        _item_1.setLockingScript(_tmpLockingScript);
        final byte[] _tmpRedeemScript;
        if (_cursor.isNull(_cursorIndexOfRedeemScript)) {
          _tmpRedeemScript = null;
        } else {
          _tmpRedeemScript = _cursor.getBlob(_cursorIndexOfRedeemScript);
        }
        _item_1.setRedeemScript(_tmpRedeemScript);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item_1.setIndex(_tmpIndex);
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item_1.setTransactionHash(_tmpTransactionHash);
        final String _tmpPublicKeyPath;
        if (_cursor.isNull(_cursorIndexOfPublicKeyPath)) {
          _tmpPublicKeyPath = null;
        } else {
          _tmpPublicKeyPath = _cursor.getString(_cursorIndexOfPublicKeyPath);
        }
        _item_1.setPublicKeyPath(_tmpPublicKeyPath);
        final boolean _tmpChangeOutput;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfChangeOutput);
        _tmpChangeOutput = _tmp != 0;
        _item_1.setChangeOutput(_tmpChangeOutput);
        final ScriptType _tmpScriptType;
        final Integer _tmp_1;
        if (_cursor.isNull(_cursorIndexOfScriptType)) {
          _tmp_1 = null;
        } else {
          _tmp_1 = _cursor.getInt(_cursorIndexOfScriptType);
        }
        final ScriptType _tmp_2 = __scriptTypeConverter.fromInt(_tmp_1);
        if (_tmp_2 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.transactions.scripts.ScriptType', but it was NULL.");
        } else {
          _tmpScriptType = _tmp_2;
        }
        _item_1.setScriptType(_tmpScriptType);
        final byte[] _tmpLockingScriptPayload;
        if (_cursor.isNull(_cursorIndexOfLockingScriptPayload)) {
          _tmpLockingScriptPayload = null;
        } else {
          _tmpLockingScriptPayload = _cursor.getBlob(_cursorIndexOfLockingScriptPayload);
        }
        _item_1.setLockingScriptPayload(_tmpLockingScriptPayload);
        final String _tmpAddress;
        if (_cursor.isNull(_cursorIndexOfAddress)) {
          _tmpAddress = null;
        } else {
          _tmpAddress = _cursor.getString(_cursorIndexOfAddress);
        }
        _item_1.setAddress(_tmpAddress);
        final boolean _tmpFailedToSpend;
        final int _tmp_3;
        _tmp_3 = _cursor.getInt(_cursorIndexOfFailedToSpend);
        _tmpFailedToSpend = _tmp_3 != 0;
        _item_1.setFailedToSpend(_tmpFailedToSpend);
        final Byte _tmpPluginId;
        if (_cursor.isNull(_cursorIndexOfPluginId)) {
          _tmpPluginId = null;
        } else {
          _tmpPluginId = (byte) (_cursor.getShort(_cursorIndexOfPluginId));
        }
        _item_1.setPluginId(_tmpPluginId);
        final String _tmpPluginData;
        if (_cursor.isNull(_cursorIndexOfPluginData)) {
          _tmpPluginData = null;
        } else {
          _tmpPluginData = _cursor.getString(_cursorIndexOfPluginData);
        }
        _item_1.setPluginData(_tmpPluginData);
        _result.add(_item_1);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
