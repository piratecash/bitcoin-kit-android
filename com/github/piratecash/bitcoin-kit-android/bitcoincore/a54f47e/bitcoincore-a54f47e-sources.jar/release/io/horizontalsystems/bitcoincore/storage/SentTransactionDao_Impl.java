package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.SentTransaction;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class SentTransactionDao_Impl implements SentTransactionDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<SentTransaction> __insertionAdapterOfSentTransaction;

  private final EntityDeletionOrUpdateAdapter<SentTransaction> __deletionAdapterOfSentTransaction;

  private final EntityDeletionOrUpdateAdapter<SentTransaction> __updateAdapterOfSentTransaction;

  public SentTransactionDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfSentTransaction = new EntityInsertionAdapter<SentTransaction>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `SentTransaction` (`hash`,`firstSendTime`,`lastSendTime`,`retriesCount`,`sendSuccess`) VALUES (?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final SentTransaction entity) {
        statement.bindBlob(1, entity.getHash());
        statement.bindLong(2, entity.getFirstSendTime());
        statement.bindLong(3, entity.getLastSendTime());
        statement.bindLong(4, entity.getRetriesCount());
        final int _tmp = entity.getSendSuccess() ? 1 : 0;
        statement.bindLong(5, _tmp);
      }
    };
    this.__deletionAdapterOfSentTransaction = new EntityDeletionOrUpdateAdapter<SentTransaction>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `SentTransaction` WHERE `hash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final SentTransaction entity) {
        statement.bindBlob(1, entity.getHash());
      }
    };
    this.__updateAdapterOfSentTransaction = new EntityDeletionOrUpdateAdapter<SentTransaction>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR REPLACE `SentTransaction` SET `hash` = ?,`firstSendTime` = ?,`lastSendTime` = ?,`retriesCount` = ?,`sendSuccess` = ? WHERE `hash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final SentTransaction entity) {
        statement.bindBlob(1, entity.getHash());
        statement.bindLong(2, entity.getFirstSendTime());
        statement.bindLong(3, entity.getLastSendTime());
        statement.bindLong(4, entity.getRetriesCount());
        final int _tmp = entity.getSendSuccess() ? 1 : 0;
        statement.bindLong(5, _tmp);
        statement.bindBlob(6, entity.getHash());
      }
    };
  }

  @Override
  public void insert(final SentTransaction transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfSentTransaction.insert(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final SentTransaction transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfSentTransaction.handle(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void update(final SentTransaction transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __updateAdapterOfSentTransaction.handle(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public SentTransaction getTransaction(final byte[] hash) {
    final String _sql = "select * from SentTransaction where hash = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfFirstSendTime = CursorUtil.getColumnIndexOrThrow(_cursor, "firstSendTime");
      final int _cursorIndexOfLastSendTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lastSendTime");
      final int _cursorIndexOfRetriesCount = CursorUtil.getColumnIndexOrThrow(_cursor, "retriesCount");
      final int _cursorIndexOfSendSuccess = CursorUtil.getColumnIndexOrThrow(_cursor, "sendSuccess");
      final SentTransaction _result;
      if (_cursor.moveToFirst()) {
        _result = new SentTransaction();
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _result.setHash(_tmpHash);
        final long _tmpFirstSendTime;
        _tmpFirstSendTime = _cursor.getLong(_cursorIndexOfFirstSendTime);
        _result.setFirstSendTime(_tmpFirstSendTime);
        final long _tmpLastSendTime;
        _tmpLastSendTime = _cursor.getLong(_cursorIndexOfLastSendTime);
        _result.setLastSendTime(_tmpLastSendTime);
        final int _tmpRetriesCount;
        _tmpRetriesCount = _cursor.getInt(_cursorIndexOfRetriesCount);
        _result.setRetriesCount(_tmpRetriesCount);
        final boolean _tmpSendSuccess;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfSendSuccess);
        _tmpSendSuccess = _tmp != 0;
        _result.setSendSuccess(_tmpSendSuccess);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<SentTransaction> getAll() {
    final String _sql = "select * from SentTransaction";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfFirstSendTime = CursorUtil.getColumnIndexOrThrow(_cursor, "firstSendTime");
      final int _cursorIndexOfLastSendTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lastSendTime");
      final int _cursorIndexOfRetriesCount = CursorUtil.getColumnIndexOrThrow(_cursor, "retriesCount");
      final int _cursorIndexOfSendSuccess = CursorUtil.getColumnIndexOrThrow(_cursor, "sendSuccess");
      final List<SentTransaction> _result = new ArrayList<SentTransaction>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final SentTransaction _item;
        _item = new SentTransaction();
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _item.setHash(_tmpHash);
        final long _tmpFirstSendTime;
        _tmpFirstSendTime = _cursor.getLong(_cursorIndexOfFirstSendTime);
        _item.setFirstSendTime(_tmpFirstSendTime);
        final long _tmpLastSendTime;
        _tmpLastSendTime = _cursor.getLong(_cursorIndexOfLastSendTime);
        _item.setLastSendTime(_tmpLastSendTime);
        final int _tmpRetriesCount;
        _tmpRetriesCount = _cursor.getInt(_cursorIndexOfRetriesCount);
        _item.setRetriesCount(_tmpRetriesCount);
        final boolean _tmpSendSuccess;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfSendSuccess);
        _tmpSendSuccess = _tmp != 0;
        _item.setSendSuccess(_tmpSendSuccess);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
