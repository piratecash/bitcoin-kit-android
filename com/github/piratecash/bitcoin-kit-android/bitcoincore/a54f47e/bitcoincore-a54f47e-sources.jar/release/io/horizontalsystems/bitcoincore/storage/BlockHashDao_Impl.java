package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.BlockHash;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class BlockHashDao_Impl implements BlockHashDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<BlockHash> __insertionAdapterOfBlockHash;

  private final EntityDeletionOrUpdateAdapter<BlockHash> __deletionAdapterOfBlockHash;

  private final SharedSQLiteStatement __preparedStmtOfDelete;

  private final SharedSQLiteStatement __preparedStmtOfDelete_1;

  public BlockHashDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfBlockHash = new EntityInsertionAdapter<BlockHash>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `BlockHash` (`headerHash`,`height`,`sequence`) VALUES (?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BlockHash entity) {
        statement.bindBlob(1, entity.getHeaderHash());
        statement.bindLong(2, entity.getHeight());
        statement.bindLong(3, entity.getSequence());
      }
    };
    this.__deletionAdapterOfBlockHash = new EntityDeletionOrUpdateAdapter<BlockHash>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `BlockHash` WHERE `headerHash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BlockHash entity) {
        statement.bindBlob(1, entity.getHeaderHash());
      }
    };
    this.__preparedStmtOfDelete = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM BlockHash WHERE height = ?";
        return _query;
      }
    };
    this.__preparedStmtOfDelete_1 = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM BlockHash WHERE headerHash = ?";
        return _query;
      }
    };
  }

  @Override
  public void insert(final BlockHash blockHash) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfBlockHash.insert(blockHash);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void insertAll(final List<BlockHash> users) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfBlockHash.insert(users);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final BlockHash blockHash) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfBlockHash.handle(blockHash);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final int height) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDelete.acquire();
    int _argIndex = 1;
    _stmt.bindLong(_argIndex, height);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDelete.release(_stmt);
    }
  }

  @Override
  public void delete(final byte[] hash) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDelete_1.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, hash);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDelete_1.release(_stmt);
    }
  }

  @Override
  public List<byte[]> allBlockHashes() {
    final String _sql = "SELECT headerHash FROM BlockHash";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final List<byte[]> _result = new ArrayList<byte[]>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final byte[] _item;
        _item = _cursor.getBlob(0);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<byte[]> allBlockHashes(final List<byte[]> excludedHash) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("SELECT headerHash FROM BlockHash WHERE headerHash NOT IN(");
    final int _inputSize = excludedHash.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (byte[] _item : excludedHash) {
      _statement.bindBlob(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final List<byte[]> _result = new ArrayList<byte[]>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final byte[] _item_1;
        _item_1 = _cursor.getBlob(0);
        _result.add(_item_1);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<BlockHash> getBlockHashesSortedSequenceHeight(final int limit) {
    final String _sql = "SELECT * FROM BlockHash ORDER BY sequence ASC, height ASC LIMIT ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, limit);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final List<BlockHash> _result = new ArrayList<BlockHash>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final BlockHash _item;
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        final int _tmpSequence;
        _tmpSequence = _cursor.getInt(_cursorIndexOfSequence);
        _item = new BlockHash(_tmpHeaderHash,_tmpHeight,_tmpSequence);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public boolean exists(final byte[] hash) {
    final String _sql = "SELECT EXISTS(SELECT 1 FROM BlockHash WHERE headerHash = ?)";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final boolean _result;
      if (_cursor.moveToFirst()) {
        final int _tmp;
        _tmp = _cursor.getInt(0);
        _result = _tmp != 0;
      } else {
        _result = false;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<BlockHash> getBlockchainBlockHashes() {
    final String _sql = "SELECT * FROM BlockHash WHERE height = 0";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final List<BlockHash> _result = new ArrayList<BlockHash>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final BlockHash _item;
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        final int _tmpSequence;
        _tmpSequence = _cursor.getInt(_cursorIndexOfSequence);
        _item = new BlockHash(_tmpHeaderHash,_tmpHeight,_tmpSequence);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public int getApiBlockHashesCount() {
    final String _sql = "SELECT COUNT(*) FROM BlockHash WHERE height > 0";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _result;
      if (_cursor.moveToFirst()) {
        _result = _cursor.getInt(0);
      } else {
        _result = 0;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public BlockHash getLastBlockHash() {
    final String _sql = "SELECT * FROM BlockHash ORDER BY sequence DESC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final BlockHash _result;
      if (_cursor.moveToFirst()) {
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        final int _tmpSequence;
        _tmpSequence = _cursor.getInt(_cursorIndexOfSequence);
        _result = new BlockHash(_tmpHeaderHash,_tmpHeight,_tmpSequence);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public BlockHash getLastBlockHashByHeight() {
    final String _sql = "SELECT * FROM BlockHash ORDER BY height DESC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final BlockHash _result;
      if (_cursor.moveToFirst()) {
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        final int _tmpSequence;
        _tmpSequence = _cursor.getInt(_cursorIndexOfSequence);
        _result = new BlockHash(_tmpHeaderHash,_tmpHeight,_tmpSequence);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public BlockHash getLastBlockchainBlockHash() {
    final String _sql = "SELECT * FROM BlockHash WHERE height = 0 ORDER BY sequence DESC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfSequence = CursorUtil.getColumnIndexOrThrow(_cursor, "sequence");
      final BlockHash _result;
      if (_cursor.moveToFirst()) {
        final byte[] _tmpHeaderHash;
        _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
        final int _tmpHeight;
        _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
        final int _tmpSequence;
        _tmpSequence = _cursor.getInt(_cursorIndexOfSequence);
        _result = new BlockHash(_tmpHeaderHash,_tmpHeight,_tmpSequence);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
