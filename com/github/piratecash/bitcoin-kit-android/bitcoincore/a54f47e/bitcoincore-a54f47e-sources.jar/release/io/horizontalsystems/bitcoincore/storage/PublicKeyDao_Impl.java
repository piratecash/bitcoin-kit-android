package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.PublicKey;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class PublicKeyDao_Impl implements PublicKeyDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<PublicKey> __insertionAdapterOfPublicKey;

  private final EntityDeletionOrUpdateAdapter<PublicKey> __deletionAdapterOfPublicKey;

  public PublicKeyDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfPublicKey = new EntityInsertionAdapter<PublicKey>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR IGNORE INTO `PublicKey` (`path`,`account`,`address_index`,`external`,`publicKeyHash`,`publicKey`,`scriptHashP2WPKH`,`convertedForP2TR`) VALUES (?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final PublicKey entity) {
        statement.bindString(1, entity.getPath());
        statement.bindLong(2, entity.getAccount());
        statement.bindLong(3, entity.getIndex());
        final int _tmp = entity.getExternal() ? 1 : 0;
        statement.bindLong(4, _tmp);
        statement.bindBlob(5, entity.getPublicKeyHash());
        statement.bindBlob(6, entity.getPublicKey());
        statement.bindBlob(7, entity.getScriptHashP2WPKH());
        statement.bindBlob(8, entity.getConvertedForP2TR());
      }
    };
    this.__deletionAdapterOfPublicKey = new EntityDeletionOrUpdateAdapter<PublicKey>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `PublicKey` WHERE `path` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final PublicKey entity) {
        statement.bindString(1, entity.getPath());
      }
    };
  }

  @Override
  public void insertOrIgnore(final List<? extends PublicKey> keys) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfPublicKey.insert(keys);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final PublicKey publicKey) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfPublicKey.handle(publicKey);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public List<PublicKey> getAll() {
    final String _sql = "select * from PublicKey";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final List<PublicKey> _result = new ArrayList<PublicKey>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final PublicKey _item;
        _item = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _item.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _item.setAccount(_tmpAccount);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item.setIndex(_tmpIndex);
        final boolean _tmpExternal;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp != 0;
        _item.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _item.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey;
        _tmpPublicKey = _cursor.getBlob(_cursorIndexOfPublicKey);
        _item.setPublicKey(_tmpPublicKey);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _item.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _item.setConvertedForP2TR(_tmpConvertedForP2TR);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<PublicKey> getAllUsed() {
    final String _sql = "\n"
            + "        SELECT k.*, COUNT(o.publicKeyPath) c1, COUNT(bhp.publicKeyPath) c2  FROM PublicKey AS k \n"
            + "        LEFT JOIN TransactionOutput o ON o.publicKeyPath = k.path \n"
            + "        LEFT JOIN BlockHashPublicKey bhp on bhp.publicKeyPath = k.path\n"
            + "        GROUP BY k.path \n"
            + "        HAVING c1 > 0 OR c2 > 0\n"
            + "        ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final List<PublicKey> _result = new ArrayList<PublicKey>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final PublicKey _item;
        _item = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _item.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _item.setAccount(_tmpAccount);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item.setIndex(_tmpIndex);
        final boolean _tmpExternal;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp != 0;
        _item.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _item.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey;
        _tmpPublicKey = _cursor.getBlob(_cursorIndexOfPublicKey);
        _item.setPublicKey(_tmpPublicKey);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _item.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _item.setConvertedForP2TR(_tmpConvertedForP2TR);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<PublicKey> getAllUnused() {
    final String _sql = "\n"
            + "        SELECT k.*, COUNT(o.publicKeyPath) c1, COUNT(bhp.publicKeyPath) c2 FROM PublicKey AS k \n"
            + "        LEFT JOIN TransactionOutput o ON o.publicKeyPath = k.path \n"
            + "        LEFT JOIN BlockHashPublicKey bhp on bhp.publicKeyPath = k.path\n"
            + "        GROUP BY k.path \n"
            + "        HAVING c1 = 0 AND c2 = 0\n"
            + "        ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final List<PublicKey> _result = new ArrayList<PublicKey>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final PublicKey _item;
        _item = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _item.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _item.setAccount(_tmpAccount);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _item.setIndex(_tmpIndex);
        final boolean _tmpExternal;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp != 0;
        _item.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _item.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey;
        _tmpPublicKey = _cursor.getBlob(_cursorIndexOfPublicKey);
        _item.setPublicKey(_tmpPublicKey);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _item.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _item.setConvertedForP2TR(_tmpConvertedForP2TR);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<PublicKeyWithUsedState> getAllWithUsedState() {
    final String _sql = "\n"
            + "        SELECT k.*, (COUNT(o.publicKeyPath) + COUNT(bhp.publicKeyPath)) usedCount FROM PublicKey AS k \n"
            + "        LEFT JOIN TransactionOutput o ON o.publicKeyPath = k.path \n"
            + "        LEFT JOIN BlockHashPublicKey bhp on bhp.publicKeyPath = k.path\n"
            + "        GROUP BY k.path \n"
            + "        ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final int _cursorIndexOfUsedCount = CursorUtil.getColumnIndexOrThrow(_cursor, "usedCount");
      final List<PublicKeyWithUsedState> _result = new ArrayList<PublicKeyWithUsedState>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final PublicKeyWithUsedState _item;
        final int _tmpUsedCount;
        _tmpUsedCount = _cursor.getInt(_cursorIndexOfUsedCount);
        final PublicKey _tmpPublicKey;
        _tmpPublicKey = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _tmpPublicKey.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _tmpPublicKey.setAccount(_tmpAccount);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _tmpPublicKey.setIndex(_tmpIndex);
        final boolean _tmpExternal;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp != 0;
        _tmpPublicKey.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _tmpPublicKey.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey_1;
        _tmpPublicKey_1 = _cursor.getBlob(_cursorIndexOfPublicKey);
        _tmpPublicKey.setPublicKey(_tmpPublicKey_1);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _tmpPublicKey.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _tmpPublicKey.setConvertedForP2TR(_tmpConvertedForP2TR);
        _item = new PublicKeyWithUsedState(_tmpPublicKey,_tmpUsedCount);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public PublicKey getByScriptHashWPKH(final byte[] keyHash) {
    final String _sql = "SELECT * from PublicKey where scriptHashP2WPKH = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, keyHash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final PublicKey _result;
      if (_cursor.moveToFirst()) {
        _result = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _result.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _result.setAccount(_tmpAccount);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _result.setIndex(_tmpIndex);
        final boolean _tmpExternal;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp != 0;
        _result.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _result.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey;
        _tmpPublicKey = _cursor.getBlob(_cursorIndexOfPublicKey);
        _result.setPublicKey(_tmpPublicKey);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _result.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _result.setConvertedForP2TR(_tmpConvertedForP2TR);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public PublicKey getByKeyOrKeyHash(final byte[] keyHash) {
    final String _sql = "SELECT * from PublicKey where publicKey = ? or publicKeyHash =? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, keyHash);
    _argIndex = 2;
    _statement.bindBlob(_argIndex, keyHash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final PublicKey _result;
      if (_cursor.moveToFirst()) {
        _result = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _result.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _result.setAccount(_tmpAccount);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _result.setIndex(_tmpIndex);
        final boolean _tmpExternal;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp != 0;
        _result.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _result.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey;
        _tmpPublicKey = _cursor.getBlob(_cursorIndexOfPublicKey);
        _result.setPublicKey(_tmpPublicKey);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _result.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _result.setConvertedForP2TR(_tmpConvertedForP2TR);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public PublicKey getByHashP2TR(final byte[] hashP2TR) {
    final String _sql = "SELECT * from PublicKey where convertedForP2TR = ? limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hashP2TR);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfPath = CursorUtil.getColumnIndexOrThrow(_cursor, "path");
      final int _cursorIndexOfAccount = CursorUtil.getColumnIndexOrThrow(_cursor, "account");
      final int _cursorIndexOfIndex = CursorUtil.getColumnIndexOrThrow(_cursor, "address_index");
      final int _cursorIndexOfExternal = CursorUtil.getColumnIndexOrThrow(_cursor, "external");
      final int _cursorIndexOfPublicKeyHash = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKeyHash");
      final int _cursorIndexOfPublicKey = CursorUtil.getColumnIndexOrThrow(_cursor, "publicKey");
      final int _cursorIndexOfScriptHashP2WPKH = CursorUtil.getColumnIndexOrThrow(_cursor, "scriptHashP2WPKH");
      final int _cursorIndexOfConvertedForP2TR = CursorUtil.getColumnIndexOrThrow(_cursor, "convertedForP2TR");
      final PublicKey _result;
      if (_cursor.moveToFirst()) {
        _result = new PublicKey();
        final String _tmpPath;
        _tmpPath = _cursor.getString(_cursorIndexOfPath);
        _result.setPath(_tmpPath);
        final int _tmpAccount;
        _tmpAccount = _cursor.getInt(_cursorIndexOfAccount);
        _result.setAccount(_tmpAccount);
        final int _tmpIndex;
        _tmpIndex = _cursor.getInt(_cursorIndexOfIndex);
        _result.setIndex(_tmpIndex);
        final boolean _tmpExternal;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfExternal);
        _tmpExternal = _tmp != 0;
        _result.setExternal(_tmpExternal);
        final byte[] _tmpPublicKeyHash;
        _tmpPublicKeyHash = _cursor.getBlob(_cursorIndexOfPublicKeyHash);
        _result.setPublicKeyHash(_tmpPublicKeyHash);
        final byte[] _tmpPublicKey;
        _tmpPublicKey = _cursor.getBlob(_cursorIndexOfPublicKey);
        _result.setPublicKey(_tmpPublicKey);
        final byte[] _tmpScriptHashP2WPKH;
        _tmpScriptHashP2WPKH = _cursor.getBlob(_cursorIndexOfScriptHashP2WPKH);
        _result.setScriptHashP2WPKH(_tmpScriptHashP2WPKH);
        final byte[] _tmpConvertedForP2TR;
        _tmpConvertedForP2TR = _cursor.getBlob(_cursorIndexOfConvertedForP2TR);
        _result.setConvertedForP2TR(_tmpConvertedForP2TR);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
