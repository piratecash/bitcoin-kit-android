package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.BlockchainState;
import java.lang.Boolean;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class BlockchainStateDao_Impl implements BlockchainStateDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<BlockchainState> __insertionAdapterOfBlockchainState;

  private final EntityDeletionOrUpdateAdapter<BlockchainState> __deletionAdapterOfBlockchainState;

  public BlockchainStateDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfBlockchainState = new EntityInsertionAdapter<BlockchainState>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `BlockchainState` (`initialRestored`,`primaryKey`) VALUES (?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BlockchainState entity) {
        final Integer _tmp = entity.getInitialRestored() == null ? null : (entity.getInitialRestored() ? 1 : 0);
        if (_tmp == null) {
          statement.bindNull(1);
        } else {
          statement.bindLong(1, _tmp);
        }
        statement.bindString(2, entity.getPrimaryKey());
      }
    };
    this.__deletionAdapterOfBlockchainState = new EntityDeletionOrUpdateAdapter<BlockchainState>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `BlockchainState` WHERE `primaryKey` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final BlockchainState entity) {
        statement.bindString(1, entity.getPrimaryKey());
      }
    };
  }

  @Override
  public void insert(final BlockchainState state) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfBlockchainState.insert(state);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final BlockchainState state) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfBlockchainState.handle(state);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public BlockchainState getState() {
    final String _sql = "SELECT * FROM BlockchainState LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfInitialRestored = CursorUtil.getColumnIndexOrThrow(_cursor, "initialRestored");
      final int _cursorIndexOfPrimaryKey = CursorUtil.getColumnIndexOrThrow(_cursor, "primaryKey");
      final BlockchainState _result;
      if (_cursor.moveToFirst()) {
        final Boolean _tmpInitialRestored;
        final Integer _tmp;
        if (_cursor.isNull(_cursorIndexOfInitialRestored)) {
          _tmp = null;
        } else {
          _tmp = _cursor.getInt(_cursorIndexOfInitialRestored);
        }
        _tmpInitialRestored = _tmp == null ? null : _tmp != 0;
        _result = new BlockchainState(_tmpInitialRestored);
        final String _tmpPrimaryKey;
        _tmpPrimaryKey = _cursor.getString(_cursorIndexOfPrimaryKey);
        _result.setPrimaryKey(_tmpPrimaryKey);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
