package io.horizontalsystems.bitcoincore.storage;

import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.SharedSQLiteStatement;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.InvalidTransaction;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class InvalidTransactionDao_Impl implements InvalidTransactionDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<InvalidTransaction> __insertionAdapterOfInvalidTransaction;

  private final SharedSQLiteStatement __preparedStmtOfDeleteAll;

  private final SharedSQLiteStatement __preparedStmtOfDelete;

  public InvalidTransactionDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfInvalidTransaction = new EntityInsertionAdapter<InvalidTransaction>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `InvalidTransaction` (`uid`,`hash`,`blockHash`,`version`,`lockTime`,`timestamp`,`order`,`isMine`,`isOutgoing`,`segwit`,`status`,`serializedTxInfo`,`conflictingTxHash`,`rawTransaction`,`extraPayload`,`nTime`,`type`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final InvalidTransaction entity) {
        statement.bindString(1, entity.getUid());
        statement.bindBlob(2, entity.getHash());
        if (entity.getBlockHash() == null) {
          statement.bindNull(3);
        } else {
          statement.bindBlob(3, entity.getBlockHash());
        }
        statement.bindLong(4, entity.getVersion());
        statement.bindLong(5, entity.getLockTime());
        statement.bindLong(6, entity.getTimestamp());
        statement.bindLong(7, entity.getOrder());
        final int _tmp = entity.isMine() ? 1 : 0;
        statement.bindLong(8, _tmp);
        final int _tmp_1 = entity.isOutgoing() ? 1 : 0;
        statement.bindLong(9, _tmp_1);
        final int _tmp_2 = entity.getSegwit() ? 1 : 0;
        statement.bindLong(10, _tmp_2);
        statement.bindLong(11, entity.getStatus());
        statement.bindString(12, entity.getSerializedTxInfo());
        if (entity.getConflictingTxHash() == null) {
          statement.bindNull(13);
        } else {
          statement.bindBlob(13, entity.getConflictingTxHash());
        }
        if (entity.getRawTransaction() == null) {
          statement.bindNull(14);
        } else {
          statement.bindString(14, entity.getRawTransaction());
        }
        statement.bindBlob(15, entity.getExtraPayload());
        statement.bindLong(16, entity.getNTime());
        statement.bindLong(17, entity.getType());
      }
    };
    this.__preparedStmtOfDeleteAll = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM InvalidTransaction";
        return _query;
      }
    };
    this.__preparedStmtOfDelete = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM InvalidTransaction where uid = ?";
        return _query;
      }
    };
  }

  @Override
  public void insert(final InvalidTransaction transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfInvalidTransaction.insert(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteAll() {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteAll.acquire();
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDeleteAll.release(_stmt);
    }
  }

  @Override
  public void delete(final String uid) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDelete.acquire();
    int _argIndex = 1;
    _stmt.bindString(_argIndex, uid);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDelete.release(_stmt);
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
