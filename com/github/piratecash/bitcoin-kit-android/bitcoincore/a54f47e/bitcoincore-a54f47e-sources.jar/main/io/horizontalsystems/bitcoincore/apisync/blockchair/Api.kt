package io.horizontalsystems.bitcoincore.apisync.blockchair

import com.eclipsesource.json.JsonValue
import io.horizontalsystems.bitcoincore.apisync.model.BlockHeaderItem
import io.horizontalsystems.bitcoincore.apisync.model.TransactionItem

interface Api {

    fun transactions(addresses: List<String>, stopHeight: Int?): List<TransactionItem>
    suspend fun getTransactions(hashes: List<String>): List<FullApiTransaction>

    fun blockHashes(heights: List<Int>): Map<Int, String>

    fun lastBlockHeader(): BlockHeaderItem

    fun broadcastTransaction(rawTransactionHex: String): JsonValue
}
