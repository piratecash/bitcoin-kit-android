package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.PeerAddress;
import java.lang.Class;
import java.lang.Long;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class PeerAddressDao_Impl implements PeerAddressDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<PeerAddress> __insertionAdapterOfPeerAddress;

  private final EntityDeletionOrUpdateAdapter<PeerAddress> __deletionAdapterOfPeerAddress;

  private final SharedSQLiteStatement __preparedStmtOfSetSuccessConnectionTime;

  public PeerAddressDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfPeerAddress = new EntityInsertionAdapter<PeerAddress>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR IGNORE INTO `PeerAddress` (`ip`,`score`,`connectionTime`) VALUES (?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final PeerAddress entity) {
        statement.bindString(1, entity.getIp());
        statement.bindLong(2, entity.getScore());
        if (entity.getConnectionTime() == null) {
          statement.bindNull(3);
        } else {
          statement.bindLong(3, entity.getConnectionTime());
        }
      }
    };
    this.__deletionAdapterOfPeerAddress = new EntityDeletionOrUpdateAdapter<PeerAddress>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `PeerAddress` WHERE `ip` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final PeerAddress entity) {
        statement.bindString(1, entity.getIp());
      }
    };
    this.__preparedStmtOfSetSuccessConnectionTime = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE PeerAddress SET connectionTime = ?, score = score + 1 WHERE ip = ?";
        return _query;
      }
    };
  }

  @Override
  public void insertAll(final List<PeerAddress> peers) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfPeerAddress.insert(peers);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final PeerAddress peerAddress) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfPeerAddress.handle(peerAddress);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void setSuccessConnectionTime(final long time, final String ip) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfSetSuccessConnectionTime.acquire();
    int _argIndex = 1;
    _stmt.bindLong(_argIndex, time);
    _argIndex = 2;
    _stmt.bindString(_argIndex, ip);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfSetSuccessConnectionTime.release(_stmt);
    }
  }

  @Override
  public PeerAddress getLeastScoreFastest(final List<String> ips) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("\n");
    _stringBuilder.append("        SELECT * FROM PeerAddress");
    _stringBuilder.append("\n");
    _stringBuilder.append("        WHERE ip NOT IN(");
    final int _inputSize = ips.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    _stringBuilder.append("\n");
    _stringBuilder.append("        ORDER BY");
    _stringBuilder.append("\n");
    _stringBuilder.append("            CASE WHEN connectionTime IS NULL THEN 1 ELSE 0 END ASC,");
    _stringBuilder.append("\n");
    _stringBuilder.append("            score DESC,");
    _stringBuilder.append("\n");
    _stringBuilder.append("            connectionTime ASC");
    _stringBuilder.append("\n");
    _stringBuilder.append("        LIMIT 1");
    _stringBuilder.append("\n");
    _stringBuilder.append("        ");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (String _item : ips) {
      _statement.bindString(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfIp = CursorUtil.getColumnIndexOrThrow(_cursor, "ip");
      final int _cursorIndexOfScore = CursorUtil.getColumnIndexOrThrow(_cursor, "score");
      final int _cursorIndexOfConnectionTime = CursorUtil.getColumnIndexOrThrow(_cursor, "connectionTime");
      final PeerAddress _result;
      if (_cursor.moveToFirst()) {
        final String _tmpIp;
        _tmpIp = _cursor.getString(_cursorIndexOfIp);
        final int _tmpScore;
        _tmpScore = _cursor.getInt(_cursorIndexOfScore);
        final Long _tmpConnectionTime;
        if (_cursor.isNull(_cursorIndexOfConnectionTime)) {
          _tmpConnectionTime = null;
        } else {
          _tmpConnectionTime = _cursor.getLong(_cursorIndexOfConnectionTime);
        }
        _result = new PeerAddress(_tmpIp,_tmpScore,_tmpConnectionTime);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public boolean hasFresh(final List<String> ips) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("SELECT COUNT(*) > 0 FROM PeerAddress WHERE connectionTime IS NULL AND ip NOT IN(");
    final int _inputSize = ips.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (String _item : ips) {
      _statement.bindString(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final boolean _result;
      if (_cursor.moveToFirst()) {
        final int _tmp;
        _tmp = _cursor.getInt(0);
        _result = _tmp != 0;
      } else {
        _result = false;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
