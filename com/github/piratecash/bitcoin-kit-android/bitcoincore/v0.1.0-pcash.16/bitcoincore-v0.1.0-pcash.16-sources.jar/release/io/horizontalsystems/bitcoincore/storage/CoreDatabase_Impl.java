package io.horizontalsystems.bitcoincore.storage;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class CoreDatabase_Impl extends CoreDatabase {
  private volatile BlockchainStateDao _blockchainStateDao;

  private volatile PeerAddressDao _peerAddressDao;

  private volatile BlockHashDao _blockHashDao;

  private volatile BlockHashPublicKeyDao _blockHashPublicKeyDao;

  private volatile BlockDao _blockDao;

  private volatile OrphanBlockDao _orphanBlockDao;

  private volatile SentTransactionDao _sentTransactionDao;

  private volatile TransactionDao _transactionDao;

  private volatile TransactionMetadataDao _transactionMetadataDao;

  private volatile TransactionInputDao _transactionInputDao;

  private volatile TransactionOutputDao _transactionOutputDao;

  private volatile PublicKeyDao _publicKeyDao;

  private volatile InvalidTransactionDao _invalidTransactionDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(33) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `BlockchainState` (`initialRestored` INTEGER, `primaryKey` TEXT NOT NULL, PRIMARY KEY(`primaryKey`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `PeerAddress` (`ip` TEXT NOT NULL, `score` INTEGER NOT NULL, `connectionTime` INTEGER, PRIMARY KEY(`ip`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `BlockHash` (`headerHash` BLOB NOT NULL, `height` INTEGER NOT NULL, `sequence` INTEGER NOT NULL, PRIMARY KEY(`headerHash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `BlockHashPublicKey` (`blockHash` BLOB NOT NULL, `publicKeyPath` TEXT NOT NULL, PRIMARY KEY(`blockHash`, `publicKeyPath`), FOREIGN KEY(`blockHash`) REFERENCES `BlockHash`(`headerHash`) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(`publicKeyPath`) REFERENCES `PublicKey`(`path`) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `Block` (`block_version` INTEGER NOT NULL, `previousBlockHash` BLOB NOT NULL, `merkleRoot` BLOB NOT NULL, `block_timestamp` INTEGER NOT NULL, `bits` INTEGER NOT NULL, `nonce` INTEGER NOT NULL, `hasTransactions` INTEGER NOT NULL, `headerHash` BLOB NOT NULL, `height` INTEGER NOT NULL, `stale` INTEGER NOT NULL, `partial` INTEGER NOT NULL, PRIMARY KEY(`headerHash`))");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_Block_height` ON `Block` (`height`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `OrphanBlock` (`block_version` INTEGER NOT NULL, `previousBlockHash` BLOB NOT NULL, `merkleRoot` BLOB NOT NULL, `block_timestamp` INTEGER NOT NULL, `bits` INTEGER NOT NULL, `nonce` INTEGER NOT NULL, `hasTransactions` INTEGER NOT NULL, `headerHash` BLOB NOT NULL, `merkleBlock` TEXT, PRIMARY KEY(`headerHash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `SentTransaction` (`hash` BLOB NOT NULL, `firstSendTime` INTEGER NOT NULL, `lastSendTime` INTEGER NOT NULL, `retriesCount` INTEGER NOT NULL, `sendSuccess` INTEGER NOT NULL, `rawTransactionHex` TEXT, `external` INTEGER NOT NULL, PRIMARY KEY(`hash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `Transaction` (`uid` TEXT NOT NULL, `hash` BLOB NOT NULL, `blockHash` BLOB, `version` INTEGER NOT NULL, `lockTime` INTEGER NOT NULL, `timestamp` INTEGER NOT NULL, `order` INTEGER NOT NULL, `isMine` INTEGER NOT NULL, `isOutgoing` INTEGER NOT NULL, `segwit` INTEGER NOT NULL, `status` INTEGER NOT NULL, `serializedTxInfo` TEXT NOT NULL, `conflictingTxHash` BLOB, `rawTransaction` TEXT, `extraPayload` BLOB NOT NULL, `nTime` INTEGER NOT NULL, `type` INTEGER NOT NULL, PRIMARY KEY(`hash`), FOREIGN KEY(`blockHash`) REFERENCES `Block`(`headerHash`) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_Transaction_blockHash_status_isMine` ON `Transaction` (`blockHash`, `status`, `isMine`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `TransactionInput` (`previousOutputTxHash` BLOB NOT NULL, `previousOutputIndex` INTEGER NOT NULL, `sigScript` BLOB NOT NULL, `sequence` INTEGER NOT NULL, `transactionHash` BLOB NOT NULL, `lockingScriptPayload` BLOB, `address` TEXT, `witness` TEXT NOT NULL, PRIMARY KEY(`previousOutputTxHash`, `previousOutputIndex`, `sequence`), FOREIGN KEY(`transactionHash`) REFERENCES `Transaction`(`hash`) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `TransactionOutput` (`value` INTEGER NOT NULL, `lockingScript` BLOB NOT NULL, `redeemScript` BLOB, `index` INTEGER NOT NULL, `transactionHash` BLOB NOT NULL, `publicKeyPath` TEXT, `changeOutput` INTEGER NOT NULL, `scriptType` INTEGER NOT NULL, `lockingScriptPayload` BLOB, `address` TEXT, `failedToSpend` INTEGER NOT NULL, `pluginId` INTEGER, `pluginData` TEXT, PRIMARY KEY(`transactionHash`, `index`), FOREIGN KEY(`publicKeyPath`) REFERENCES `PublicKey`(`path`) ON UPDATE SET NULL ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(`transactionHash`) REFERENCES `Transaction`(`hash`) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `PublicKey` (`path` TEXT NOT NULL, `account` INTEGER NOT NULL, `address_index` INTEGER NOT NULL, `external` INTEGER NOT NULL, `publicKeyHash` BLOB NOT NULL, `publicKey` BLOB NOT NULL, `scriptHashP2WPKH` BLOB NOT NULL, `convertedForP2TR` BLOB NOT NULL, PRIMARY KEY(`path`))");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_PublicKey_publicKey` ON `PublicKey` (`publicKey`)");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_PublicKey_publicKeyHash` ON `PublicKey` (`publicKeyHash`)");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_PublicKey_scriptHashP2WPKH` ON `PublicKey` (`scriptHashP2WPKH`)");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_PublicKey_convertedForP2TR` ON `PublicKey` (`convertedForP2TR`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `InvalidTransaction` (`uid` TEXT NOT NULL, `hash` BLOB NOT NULL, `blockHash` BLOB, `version` INTEGER NOT NULL, `lockTime` INTEGER NOT NULL, `timestamp` INTEGER NOT NULL, `order` INTEGER NOT NULL, `isMine` INTEGER NOT NULL, `isOutgoing` INTEGER NOT NULL, `segwit` INTEGER NOT NULL, `status` INTEGER NOT NULL, `serializedTxInfo` TEXT NOT NULL, `conflictingTxHash` BLOB, `rawTransaction` TEXT, `extraPayload` BLOB NOT NULL, `nTime` INTEGER NOT NULL, `type` INTEGER NOT NULL, PRIMARY KEY(`hash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS `TransactionMetadata` (`transactionHash` BLOB NOT NULL, `amount` INTEGER NOT NULL, `type` INTEGER NOT NULL, `fee` INTEGER, PRIMARY KEY(`transactionHash`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '6d75221037f1b80a8613375d6b661d6f')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `BlockchainState`");
        db.execSQL("DROP TABLE IF EXISTS `PeerAddress`");
        db.execSQL("DROP TABLE IF EXISTS `BlockHash`");
        db.execSQL("DROP TABLE IF EXISTS `BlockHashPublicKey`");
        db.execSQL("DROP TABLE IF EXISTS `Block`");
        db.execSQL("DROP TABLE IF EXISTS `OrphanBlock`");
        db.execSQL("DROP TABLE IF EXISTS `SentTransaction`");
        db.execSQL("DROP TABLE IF EXISTS `Transaction`");
        db.execSQL("DROP TABLE IF EXISTS `TransactionInput`");
        db.execSQL("DROP TABLE IF EXISTS `TransactionOutput`");
        db.execSQL("DROP TABLE IF EXISTS `PublicKey`");
        db.execSQL("DROP TABLE IF EXISTS `InvalidTransaction`");
        db.execSQL("DROP TABLE IF EXISTS `TransactionMetadata`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        db.execSQL("PRAGMA foreign_keys = ON");
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsBlockchainState = new HashMap<String, TableInfo.Column>(2);
        _columnsBlockchainState.put("initialRestored", new TableInfo.Column("initialRestored", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlockchainState.put("primaryKey", new TableInfo.Column("primaryKey", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysBlockchainState = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesBlockchainState = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoBlockchainState = new TableInfo("BlockchainState", _columnsBlockchainState, _foreignKeysBlockchainState, _indicesBlockchainState);
        final TableInfo _existingBlockchainState = TableInfo.read(db, "BlockchainState");
        if (!_infoBlockchainState.equals(_existingBlockchainState)) {
          return new RoomOpenHelper.ValidationResult(false, "BlockchainState(io.horizontalsystems.bitcoincore.models.BlockchainState).\n"
                  + " Expected:\n" + _infoBlockchainState + "\n"
                  + " Found:\n" + _existingBlockchainState);
        }
        final HashMap<String, TableInfo.Column> _columnsPeerAddress = new HashMap<String, TableInfo.Column>(3);
        _columnsPeerAddress.put("ip", new TableInfo.Column("ip", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPeerAddress.put("score", new TableInfo.Column("score", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPeerAddress.put("connectionTime", new TableInfo.Column("connectionTime", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysPeerAddress = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesPeerAddress = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoPeerAddress = new TableInfo("PeerAddress", _columnsPeerAddress, _foreignKeysPeerAddress, _indicesPeerAddress);
        final TableInfo _existingPeerAddress = TableInfo.read(db, "PeerAddress");
        if (!_infoPeerAddress.equals(_existingPeerAddress)) {
          return new RoomOpenHelper.ValidationResult(false, "PeerAddress(io.horizontalsystems.bitcoincore.models.PeerAddress).\n"
                  + " Expected:\n" + _infoPeerAddress + "\n"
                  + " Found:\n" + _existingPeerAddress);
        }
        final HashMap<String, TableInfo.Column> _columnsBlockHash = new HashMap<String, TableInfo.Column>(3);
        _columnsBlockHash.put("headerHash", new TableInfo.Column("headerHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlockHash.put("height", new TableInfo.Column("height", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlockHash.put("sequence", new TableInfo.Column("sequence", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysBlockHash = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesBlockHash = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoBlockHash = new TableInfo("BlockHash", _columnsBlockHash, _foreignKeysBlockHash, _indicesBlockHash);
        final TableInfo _existingBlockHash = TableInfo.read(db, "BlockHash");
        if (!_infoBlockHash.equals(_existingBlockHash)) {
          return new RoomOpenHelper.ValidationResult(false, "BlockHash(io.horizontalsystems.bitcoincore.models.BlockHash).\n"
                  + " Expected:\n" + _infoBlockHash + "\n"
                  + " Found:\n" + _existingBlockHash);
        }
        final HashMap<String, TableInfo.Column> _columnsBlockHashPublicKey = new HashMap<String, TableInfo.Column>(2);
        _columnsBlockHashPublicKey.put("blockHash", new TableInfo.Column("blockHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlockHashPublicKey.put("publicKeyPath", new TableInfo.Column("publicKeyPath", "TEXT", true, 2, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysBlockHashPublicKey = new HashSet<TableInfo.ForeignKey>(2);
        _foreignKeysBlockHashPublicKey.add(new TableInfo.ForeignKey("BlockHash", "CASCADE", "CASCADE", Arrays.asList("blockHash"), Arrays.asList("headerHash")));
        _foreignKeysBlockHashPublicKey.add(new TableInfo.ForeignKey("PublicKey", "CASCADE", "CASCADE", Arrays.asList("publicKeyPath"), Arrays.asList("path")));
        final HashSet<TableInfo.Index> _indicesBlockHashPublicKey = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoBlockHashPublicKey = new TableInfo("BlockHashPublicKey", _columnsBlockHashPublicKey, _foreignKeysBlockHashPublicKey, _indicesBlockHashPublicKey);
        final TableInfo _existingBlockHashPublicKey = TableInfo.read(db, "BlockHashPublicKey");
        if (!_infoBlockHashPublicKey.equals(_existingBlockHashPublicKey)) {
          return new RoomOpenHelper.ValidationResult(false, "BlockHashPublicKey(io.horizontalsystems.bitcoincore.models.BlockHashPublicKey).\n"
                  + " Expected:\n" + _infoBlockHashPublicKey + "\n"
                  + " Found:\n" + _existingBlockHashPublicKey);
        }
        final HashMap<String, TableInfo.Column> _columnsBlock = new HashMap<String, TableInfo.Column>(11);
        _columnsBlock.put("block_version", new TableInfo.Column("block_version", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("previousBlockHash", new TableInfo.Column("previousBlockHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("merkleRoot", new TableInfo.Column("merkleRoot", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("block_timestamp", new TableInfo.Column("block_timestamp", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("bits", new TableInfo.Column("bits", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("nonce", new TableInfo.Column("nonce", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("hasTransactions", new TableInfo.Column("hasTransactions", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("headerHash", new TableInfo.Column("headerHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("height", new TableInfo.Column("height", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("stale", new TableInfo.Column("stale", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsBlock.put("partial", new TableInfo.Column("partial", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysBlock = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesBlock = new HashSet<TableInfo.Index>(1);
        _indicesBlock.add(new TableInfo.Index("index_Block_height", false, Arrays.asList("height"), Arrays.asList("ASC")));
        final TableInfo _infoBlock = new TableInfo("Block", _columnsBlock, _foreignKeysBlock, _indicesBlock);
        final TableInfo _existingBlock = TableInfo.read(db, "Block");
        if (!_infoBlock.equals(_existingBlock)) {
          return new RoomOpenHelper.ValidationResult(false, "Block(io.horizontalsystems.bitcoincore.models.Block).\n"
                  + " Expected:\n" + _infoBlock + "\n"
                  + " Found:\n" + _existingBlock);
        }
        final HashMap<String, TableInfo.Column> _columnsOrphanBlock = new HashMap<String, TableInfo.Column>(9);
        _columnsOrphanBlock.put("block_version", new TableInfo.Column("block_version", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("previousBlockHash", new TableInfo.Column("previousBlockHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("merkleRoot", new TableInfo.Column("merkleRoot", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("block_timestamp", new TableInfo.Column("block_timestamp", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("bits", new TableInfo.Column("bits", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("nonce", new TableInfo.Column("nonce", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("hasTransactions", new TableInfo.Column("hasTransactions", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("headerHash", new TableInfo.Column("headerHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsOrphanBlock.put("merkleBlock", new TableInfo.Column("merkleBlock", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysOrphanBlock = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesOrphanBlock = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoOrphanBlock = new TableInfo("OrphanBlock", _columnsOrphanBlock, _foreignKeysOrphanBlock, _indicesOrphanBlock);
        final TableInfo _existingOrphanBlock = TableInfo.read(db, "OrphanBlock");
        if (!_infoOrphanBlock.equals(_existingOrphanBlock)) {
          return new RoomOpenHelper.ValidationResult(false, "OrphanBlock(io.horizontalsystems.bitcoincore.models.OrphanBlock).\n"
                  + " Expected:\n" + _infoOrphanBlock + "\n"
                  + " Found:\n" + _existingOrphanBlock);
        }
        final HashMap<String, TableInfo.Column> _columnsSentTransaction = new HashMap<String, TableInfo.Column>(7);
        _columnsSentTransaction.put("hash", new TableInfo.Column("hash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentTransaction.put("firstSendTime", new TableInfo.Column("firstSendTime", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentTransaction.put("lastSendTime", new TableInfo.Column("lastSendTime", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentTransaction.put("retriesCount", new TableInfo.Column("retriesCount", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentTransaction.put("sendSuccess", new TableInfo.Column("sendSuccess", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentTransaction.put("rawTransactionHex", new TableInfo.Column("rawTransactionHex", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentTransaction.put("external", new TableInfo.Column("external", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysSentTransaction = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesSentTransaction = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoSentTransaction = new TableInfo("SentTransaction", _columnsSentTransaction, _foreignKeysSentTransaction, _indicesSentTransaction);
        final TableInfo _existingSentTransaction = TableInfo.read(db, "SentTransaction");
        if (!_infoSentTransaction.equals(_existingSentTransaction)) {
          return new RoomOpenHelper.ValidationResult(false, "SentTransaction(io.horizontalsystems.bitcoincore.models.SentTransaction).\n"
                  + " Expected:\n" + _infoSentTransaction + "\n"
                  + " Found:\n" + _existingSentTransaction);
        }
        final HashMap<String, TableInfo.Column> _columnsTransaction = new HashMap<String, TableInfo.Column>(17);
        _columnsTransaction.put("uid", new TableInfo.Column("uid", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("hash", new TableInfo.Column("hash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("blockHash", new TableInfo.Column("blockHash", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("version", new TableInfo.Column("version", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("lockTime", new TableInfo.Column("lockTime", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("timestamp", new TableInfo.Column("timestamp", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("order", new TableInfo.Column("order", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("isMine", new TableInfo.Column("isMine", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("isOutgoing", new TableInfo.Column("isOutgoing", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("segwit", new TableInfo.Column("segwit", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("status", new TableInfo.Column("status", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("serializedTxInfo", new TableInfo.Column("serializedTxInfo", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("conflictingTxHash", new TableInfo.Column("conflictingTxHash", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("rawTransaction", new TableInfo.Column("rawTransaction", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("extraPayload", new TableInfo.Column("extraPayload", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("nTime", new TableInfo.Column("nTime", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransaction.put("type", new TableInfo.Column("type", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysTransaction = new HashSet<TableInfo.ForeignKey>(1);
        _foreignKeysTransaction.add(new TableInfo.ForeignKey("Block", "CASCADE", "CASCADE", Arrays.asList("blockHash"), Arrays.asList("headerHash")));
        final HashSet<TableInfo.Index> _indicesTransaction = new HashSet<TableInfo.Index>(1);
        _indicesTransaction.add(new TableInfo.Index("index_Transaction_blockHash_status_isMine", false, Arrays.asList("blockHash", "status", "isMine"), Arrays.asList("ASC", "ASC", "ASC")));
        final TableInfo _infoTransaction = new TableInfo("Transaction", _columnsTransaction, _foreignKeysTransaction, _indicesTransaction);
        final TableInfo _existingTransaction = TableInfo.read(db, "Transaction");
        if (!_infoTransaction.equals(_existingTransaction)) {
          return new RoomOpenHelper.ValidationResult(false, "Transaction(io.horizontalsystems.bitcoincore.models.Transaction).\n"
                  + " Expected:\n" + _infoTransaction + "\n"
                  + " Found:\n" + _existingTransaction);
        }
        final HashMap<String, TableInfo.Column> _columnsTransactionInput = new HashMap<String, TableInfo.Column>(8);
        _columnsTransactionInput.put("previousOutputTxHash", new TableInfo.Column("previousOutputTxHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionInput.put("previousOutputIndex", new TableInfo.Column("previousOutputIndex", "INTEGER", true, 2, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionInput.put("sigScript", new TableInfo.Column("sigScript", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionInput.put("sequence", new TableInfo.Column("sequence", "INTEGER", true, 3, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionInput.put("transactionHash", new TableInfo.Column("transactionHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionInput.put("lockingScriptPayload", new TableInfo.Column("lockingScriptPayload", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionInput.put("address", new TableInfo.Column("address", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionInput.put("witness", new TableInfo.Column("witness", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysTransactionInput = new HashSet<TableInfo.ForeignKey>(1);
        _foreignKeysTransactionInput.add(new TableInfo.ForeignKey("Transaction", "CASCADE", "CASCADE", Arrays.asList("transactionHash"), Arrays.asList("hash")));
        final HashSet<TableInfo.Index> _indicesTransactionInput = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoTransactionInput = new TableInfo("TransactionInput", _columnsTransactionInput, _foreignKeysTransactionInput, _indicesTransactionInput);
        final TableInfo _existingTransactionInput = TableInfo.read(db, "TransactionInput");
        if (!_infoTransactionInput.equals(_existingTransactionInput)) {
          return new RoomOpenHelper.ValidationResult(false, "TransactionInput(io.horizontalsystems.bitcoincore.models.TransactionInput).\n"
                  + " Expected:\n" + _infoTransactionInput + "\n"
                  + " Found:\n" + _existingTransactionInput);
        }
        final HashMap<String, TableInfo.Column> _columnsTransactionOutput = new HashMap<String, TableInfo.Column>(13);
        _columnsTransactionOutput.put("value", new TableInfo.Column("value", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("lockingScript", new TableInfo.Column("lockingScript", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("redeemScript", new TableInfo.Column("redeemScript", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("index", new TableInfo.Column("index", "INTEGER", true, 2, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("transactionHash", new TableInfo.Column("transactionHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("publicKeyPath", new TableInfo.Column("publicKeyPath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("changeOutput", new TableInfo.Column("changeOutput", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("scriptType", new TableInfo.Column("scriptType", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("lockingScriptPayload", new TableInfo.Column("lockingScriptPayload", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("address", new TableInfo.Column("address", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("failedToSpend", new TableInfo.Column("failedToSpend", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("pluginId", new TableInfo.Column("pluginId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionOutput.put("pluginData", new TableInfo.Column("pluginData", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysTransactionOutput = new HashSet<TableInfo.ForeignKey>(2);
        _foreignKeysTransactionOutput.add(new TableInfo.ForeignKey("PublicKey", "SET NULL", "SET NULL", Arrays.asList("publicKeyPath"), Arrays.asList("path")));
        _foreignKeysTransactionOutput.add(new TableInfo.ForeignKey("Transaction", "CASCADE", "CASCADE", Arrays.asList("transactionHash"), Arrays.asList("hash")));
        final HashSet<TableInfo.Index> _indicesTransactionOutput = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoTransactionOutput = new TableInfo("TransactionOutput", _columnsTransactionOutput, _foreignKeysTransactionOutput, _indicesTransactionOutput);
        final TableInfo _existingTransactionOutput = TableInfo.read(db, "TransactionOutput");
        if (!_infoTransactionOutput.equals(_existingTransactionOutput)) {
          return new RoomOpenHelper.ValidationResult(false, "TransactionOutput(io.horizontalsystems.bitcoincore.models.TransactionOutput).\n"
                  + " Expected:\n" + _infoTransactionOutput + "\n"
                  + " Found:\n" + _existingTransactionOutput);
        }
        final HashMap<String, TableInfo.Column> _columnsPublicKey = new HashMap<String, TableInfo.Column>(8);
        _columnsPublicKey.put("path", new TableInfo.Column("path", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPublicKey.put("account", new TableInfo.Column("account", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPublicKey.put("address_index", new TableInfo.Column("address_index", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPublicKey.put("external", new TableInfo.Column("external", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPublicKey.put("publicKeyHash", new TableInfo.Column("publicKeyHash", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPublicKey.put("publicKey", new TableInfo.Column("publicKey", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPublicKey.put("scriptHashP2WPKH", new TableInfo.Column("scriptHashP2WPKH", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsPublicKey.put("convertedForP2TR", new TableInfo.Column("convertedForP2TR", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysPublicKey = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesPublicKey = new HashSet<TableInfo.Index>(4);
        _indicesPublicKey.add(new TableInfo.Index("index_PublicKey_publicKey", false, Arrays.asList("publicKey"), Arrays.asList("ASC")));
        _indicesPublicKey.add(new TableInfo.Index("index_PublicKey_publicKeyHash", false, Arrays.asList("publicKeyHash"), Arrays.asList("ASC")));
        _indicesPublicKey.add(new TableInfo.Index("index_PublicKey_scriptHashP2WPKH", false, Arrays.asList("scriptHashP2WPKH"), Arrays.asList("ASC")));
        _indicesPublicKey.add(new TableInfo.Index("index_PublicKey_convertedForP2TR", false, Arrays.asList("convertedForP2TR"), Arrays.asList("ASC")));
        final TableInfo _infoPublicKey = new TableInfo("PublicKey", _columnsPublicKey, _foreignKeysPublicKey, _indicesPublicKey);
        final TableInfo _existingPublicKey = TableInfo.read(db, "PublicKey");
        if (!_infoPublicKey.equals(_existingPublicKey)) {
          return new RoomOpenHelper.ValidationResult(false, "PublicKey(io.horizontalsystems.bitcoincore.models.PublicKey).\n"
                  + " Expected:\n" + _infoPublicKey + "\n"
                  + " Found:\n" + _existingPublicKey);
        }
        final HashMap<String, TableInfo.Column> _columnsInvalidTransaction = new HashMap<String, TableInfo.Column>(17);
        _columnsInvalidTransaction.put("uid", new TableInfo.Column("uid", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("hash", new TableInfo.Column("hash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("blockHash", new TableInfo.Column("blockHash", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("version", new TableInfo.Column("version", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("lockTime", new TableInfo.Column("lockTime", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("timestamp", new TableInfo.Column("timestamp", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("order", new TableInfo.Column("order", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("isMine", new TableInfo.Column("isMine", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("isOutgoing", new TableInfo.Column("isOutgoing", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("segwit", new TableInfo.Column("segwit", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("status", new TableInfo.Column("status", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("serializedTxInfo", new TableInfo.Column("serializedTxInfo", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("conflictingTxHash", new TableInfo.Column("conflictingTxHash", "BLOB", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("rawTransaction", new TableInfo.Column("rawTransaction", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("extraPayload", new TableInfo.Column("extraPayload", "BLOB", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("nTime", new TableInfo.Column("nTime", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsInvalidTransaction.put("type", new TableInfo.Column("type", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysInvalidTransaction = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesInvalidTransaction = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoInvalidTransaction = new TableInfo("InvalidTransaction", _columnsInvalidTransaction, _foreignKeysInvalidTransaction, _indicesInvalidTransaction);
        final TableInfo _existingInvalidTransaction = TableInfo.read(db, "InvalidTransaction");
        if (!_infoInvalidTransaction.equals(_existingInvalidTransaction)) {
          return new RoomOpenHelper.ValidationResult(false, "InvalidTransaction(io.horizontalsystems.bitcoincore.models.InvalidTransaction).\n"
                  + " Expected:\n" + _infoInvalidTransaction + "\n"
                  + " Found:\n" + _existingInvalidTransaction);
        }
        final HashMap<String, TableInfo.Column> _columnsTransactionMetadata = new HashMap<String, TableInfo.Column>(4);
        _columnsTransactionMetadata.put("transactionHash", new TableInfo.Column("transactionHash", "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionMetadata.put("amount", new TableInfo.Column("amount", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionMetadata.put("type", new TableInfo.Column("type", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsTransactionMetadata.put("fee", new TableInfo.Column("fee", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysTransactionMetadata = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesTransactionMetadata = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoTransactionMetadata = new TableInfo("TransactionMetadata", _columnsTransactionMetadata, _foreignKeysTransactionMetadata, _indicesTransactionMetadata);
        final TableInfo _existingTransactionMetadata = TableInfo.read(db, "TransactionMetadata");
        if (!_infoTransactionMetadata.equals(_existingTransactionMetadata)) {
          return new RoomOpenHelper.ValidationResult(false, "TransactionMetadata(io.horizontalsystems.bitcoincore.models.TransactionMetadata).\n"
                  + " Expected:\n" + _infoTransactionMetadata + "\n"
                  + " Found:\n" + _existingTransactionMetadata);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "6d75221037f1b80a8613375d6b661d6f", "07ae08380ef02421af692544ff6b7925");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "BlockchainState","PeerAddress","BlockHash","BlockHashPublicKey","Block","OrphanBlock","SentTransaction","Transaction","TransactionInput","TransactionOutput","PublicKey","InvalidTransaction","TransactionMetadata");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    final boolean _supportsDeferForeignKeys = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP;
    try {
      if (!_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA foreign_keys = FALSE");
      }
      super.beginTransaction();
      if (_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA defer_foreign_keys = TRUE");
      }
      _db.execSQL("DELETE FROM `BlockchainState`");
      _db.execSQL("DELETE FROM `PeerAddress`");
      _db.execSQL("DELETE FROM `BlockHash`");
      _db.execSQL("DELETE FROM `BlockHashPublicKey`");
      _db.execSQL("DELETE FROM `Block`");
      _db.execSQL("DELETE FROM `OrphanBlock`");
      _db.execSQL("DELETE FROM `SentTransaction`");
      _db.execSQL("DELETE FROM `Transaction`");
      _db.execSQL("DELETE FROM `TransactionInput`");
      _db.execSQL("DELETE FROM `TransactionOutput`");
      _db.execSQL("DELETE FROM `PublicKey`");
      _db.execSQL("DELETE FROM `InvalidTransaction`");
      _db.execSQL("DELETE FROM `TransactionMetadata`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      if (!_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA foreign_keys = TRUE");
      }
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(BlockchainStateDao.class, BlockchainStateDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(PeerAddressDao.class, PeerAddressDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(BlockHashDao.class, BlockHashDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(BlockHashPublicKeyDao.class, BlockHashPublicKeyDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(BlockDao.class, BlockDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(OrphanBlockDao.class, OrphanBlockDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(SentTransactionDao.class, SentTransactionDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(TransactionDao.class, TransactionDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(TransactionMetadataDao.class, TransactionMetadataDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(TransactionInputDao.class, TransactionInputDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(TransactionOutputDao.class, TransactionOutputDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(PublicKeyDao.class, PublicKeyDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(InvalidTransactionDao.class, InvalidTransactionDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    return _autoMigrations;
  }

  @Override
  public BlockchainStateDao getBlockchainState() {
    if (_blockchainStateDao != null) {
      return _blockchainStateDao;
    } else {
      synchronized(this) {
        if(_blockchainStateDao == null) {
          _blockchainStateDao = new BlockchainStateDao_Impl(this);
        }
        return _blockchainStateDao;
      }
    }
  }

  @Override
  public PeerAddressDao getPeerAddress() {
    if (_peerAddressDao != null) {
      return _peerAddressDao;
    } else {
      synchronized(this) {
        if(_peerAddressDao == null) {
          _peerAddressDao = new PeerAddressDao_Impl(this);
        }
        return _peerAddressDao;
      }
    }
  }

  @Override
  public BlockHashDao getBlockHash() {
    if (_blockHashDao != null) {
      return _blockHashDao;
    } else {
      synchronized(this) {
        if(_blockHashDao == null) {
          _blockHashDao = new BlockHashDao_Impl(this);
        }
        return _blockHashDao;
      }
    }
  }

  @Override
  public BlockHashPublicKeyDao getBlockHashPublicKey() {
    if (_blockHashPublicKeyDao != null) {
      return _blockHashPublicKeyDao;
    } else {
      synchronized(this) {
        if(_blockHashPublicKeyDao == null) {
          _blockHashPublicKeyDao = new BlockHashPublicKeyDao_Impl(this);
        }
        return _blockHashPublicKeyDao;
      }
    }
  }

  @Override
  public BlockDao getBlock() {
    if (_blockDao != null) {
      return _blockDao;
    } else {
      synchronized(this) {
        if(_blockDao == null) {
          _blockDao = new BlockDao_Impl(this);
        }
        return _blockDao;
      }
    }
  }

  @Override
  public OrphanBlockDao getOrphanBlockDao() {
    if (_orphanBlockDao != null) {
      return _orphanBlockDao;
    } else {
      synchronized(this) {
        if(_orphanBlockDao == null) {
          _orphanBlockDao = new OrphanBlockDao_Impl(this);
        }
        return _orphanBlockDao;
      }
    }
  }

  @Override
  public SentTransactionDao getSentTransaction() {
    if (_sentTransactionDao != null) {
      return _sentTransactionDao;
    } else {
      synchronized(this) {
        if(_sentTransactionDao == null) {
          _sentTransactionDao = new SentTransactionDao_Impl(this);
        }
        return _sentTransactionDao;
      }
    }
  }

  @Override
  public TransactionDao getTransaction() {
    if (_transactionDao != null) {
      return _transactionDao;
    } else {
      synchronized(this) {
        if(_transactionDao == null) {
          _transactionDao = new TransactionDao_Impl(this);
        }
        return _transactionDao;
      }
    }
  }

  @Override
  public TransactionMetadataDao getTransactionMetadata() {
    if (_transactionMetadataDao != null) {
      return _transactionMetadataDao;
    } else {
      synchronized(this) {
        if(_transactionMetadataDao == null) {
          _transactionMetadataDao = new TransactionMetadataDao_Impl(this);
        }
        return _transactionMetadataDao;
      }
    }
  }

  @Override
  public TransactionInputDao getInput() {
    if (_transactionInputDao != null) {
      return _transactionInputDao;
    } else {
      synchronized(this) {
        if(_transactionInputDao == null) {
          _transactionInputDao = new TransactionInputDao_Impl(this);
        }
        return _transactionInputDao;
      }
    }
  }

  @Override
  public TransactionOutputDao getOutput() {
    if (_transactionOutputDao != null) {
      return _transactionOutputDao;
    } else {
      synchronized(this) {
        if(_transactionOutputDao == null) {
          _transactionOutputDao = new TransactionOutputDao_Impl(this);
        }
        return _transactionOutputDao;
      }
    }
  }

  @Override
  public PublicKeyDao getPublicKey() {
    if (_publicKeyDao != null) {
      return _publicKeyDao;
    } else {
      synchronized(this) {
        if(_publicKeyDao == null) {
          _publicKeyDao = new PublicKeyDao_Impl(this);
        }
        return _publicKeyDao;
      }
    }
  }

  @Override
  public InvalidTransactionDao getInvalidTransaction() {
    if (_invalidTransactionDao != null) {
      return _invalidTransactionDao;
    } else {
      synchronized(this) {
        if(_invalidTransactionDao == null) {
          _invalidTransactionDao = new InvalidTransactionDao_Impl(this);
        }
        return _invalidTransactionDao;
      }
    }
  }
}
