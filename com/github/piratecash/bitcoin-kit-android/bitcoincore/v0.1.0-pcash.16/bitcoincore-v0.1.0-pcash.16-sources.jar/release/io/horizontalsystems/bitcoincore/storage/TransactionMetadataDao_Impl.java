package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.TransactionMetadata;
import io.horizontalsystems.bitcoincore.models.TransactionType;
import io.horizontalsystems.bitcoincore.models.TransactionTypeConverter;
import java.lang.Class;
import java.lang.IllegalStateException;
import java.lang.Integer;
import java.lang.Long;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class TransactionMetadataDao_Impl implements TransactionMetadataDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<TransactionMetadata> __insertionAdapterOfTransactionMetadata;

  private final TransactionTypeConverter __transactionTypeConverter = new TransactionTypeConverter();

  private final SharedSQLiteStatement __preparedStmtOfDelete;

  public TransactionMetadataDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfTransactionMetadata = new EntityInsertionAdapter<TransactionMetadata>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `TransactionMetadata` (`transactionHash`,`amount`,`type`,`fee`) VALUES (?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TransactionMetadata entity) {
        statement.bindBlob(1, entity.getTransactionHash());
        statement.bindLong(2, entity.getAmount());
        final Integer _tmp = __transactionTypeConverter.transactionTypeToInt(entity.getType());
        if (_tmp == null) {
          statement.bindNull(3);
        } else {
          statement.bindLong(3, _tmp);
        }
        if (entity.getFee() == null) {
          statement.bindNull(4);
        } else {
          statement.bindLong(4, entity.getFee());
        }
      }
    };
    this.__preparedStmtOfDelete = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM `TransactionMetadata` WHERE `transactionHash` = ?";
        return _query;
      }
    };
  }

  @Override
  public void insert(final TransactionMetadata metadata) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfTransactionMetadata.insert(metadata);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final byte[] txHash) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDelete.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, txHash);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDelete.release(_stmt);
    }
  }

  @Override
  public List<TransactionMetadata> getTransactionMetadata(final List<byte[]> txHashes) {
    final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
    _stringBuilder.append("SELECT * FROM `TransactionMetadata` WHERE `transactionHash` IN (");
    final int _inputSize = txHashes.size();
    StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
    _stringBuilder.append(")");
    final String _sql = _stringBuilder.toString();
    final int _argCount = 0 + _inputSize;
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, _argCount);
    int _argIndex = 1;
    for (byte[] _item : txHashes) {
      _statement.bindBlob(_argIndex, _item);
      _argIndex++;
    }
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfTransactionHash = CursorUtil.getColumnIndexOrThrow(_cursor, "transactionHash");
      final int _cursorIndexOfAmount = CursorUtil.getColumnIndexOrThrow(_cursor, "amount");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final int _cursorIndexOfFee = CursorUtil.getColumnIndexOrThrow(_cursor, "fee");
      final List<TransactionMetadata> _result = new ArrayList<TransactionMetadata>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionMetadata _item_1;
        final byte[] _tmpTransactionHash;
        _tmpTransactionHash = _cursor.getBlob(_cursorIndexOfTransactionHash);
        _item_1 = new TransactionMetadata(_tmpTransactionHash);
        final long _tmpAmount;
        _tmpAmount = _cursor.getLong(_cursorIndexOfAmount);
        _item_1.setAmount(_tmpAmount);
        final TransactionType _tmpType;
        final Integer _tmp;
        if (_cursor.isNull(_cursorIndexOfType)) {
          _tmp = null;
        } else {
          _tmp = _cursor.getInt(_cursorIndexOfType);
        }
        final TransactionType _tmp_1 = __transactionTypeConverter.fromInt(_tmp);
        if (_tmp_1 == null) {
          throw new IllegalStateException("Expected NON-NULL 'io.horizontalsystems.bitcoincore.models.TransactionType', but it was NULL.");
        } else {
          _tmpType = _tmp_1;
        }
        _item_1.setType(_tmpType);
        final Long _tmpFee;
        if (_cursor.isNull(_cursorIndexOfFee)) {
          _tmpFee = null;
        } else {
          _tmpFee = _cursor.getLong(_cursorIndexOfFee);
        }
        _item_1.setFee(_tmpFee);
        _result.add(_item_1);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
