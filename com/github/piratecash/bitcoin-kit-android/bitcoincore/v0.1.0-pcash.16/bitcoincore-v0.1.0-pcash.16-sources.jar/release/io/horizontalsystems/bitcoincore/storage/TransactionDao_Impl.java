package io.horizontalsystems.bitcoincore.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.bitcoincore.models.Block;
import io.horizontalsystems.bitcoincore.models.InvalidTransaction;
import io.horizontalsystems.bitcoincore.models.Transaction;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class TransactionDao_Impl implements TransactionDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Transaction> __insertionAdapterOfTransaction;

  private final EntityDeletionOrUpdateAdapter<Transaction> __deletionAdapterOfTransaction;

  private final EntityDeletionOrUpdateAdapter<Transaction> __updateAdapterOfTransaction;

  private final SharedSQLiteStatement __preparedStmtOfDeleteByHash;

  public TransactionDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfTransaction = new EntityInsertionAdapter<Transaction>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `Transaction` (`uid`,`hash`,`blockHash`,`version`,`lockTime`,`timestamp`,`order`,`isMine`,`isOutgoing`,`segwit`,`status`,`serializedTxInfo`,`conflictingTxHash`,`rawTransaction`,`extraPayload`,`nTime`,`type`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Transaction entity) {
        statement.bindString(1, entity.getUid());
        statement.bindBlob(2, entity.getHash());
        if (entity.getBlockHash() == null) {
          statement.bindNull(3);
        } else {
          statement.bindBlob(3, entity.getBlockHash());
        }
        statement.bindLong(4, entity.getVersion());
        statement.bindLong(5, entity.getLockTime());
        statement.bindLong(6, entity.getTimestamp());
        statement.bindLong(7, entity.getOrder());
        final int _tmp = entity.isMine() ? 1 : 0;
        statement.bindLong(8, _tmp);
        final int _tmp_1 = entity.isOutgoing() ? 1 : 0;
        statement.bindLong(9, _tmp_1);
        final int _tmp_2 = entity.getSegwit() ? 1 : 0;
        statement.bindLong(10, _tmp_2);
        statement.bindLong(11, entity.getStatus());
        statement.bindString(12, entity.getSerializedTxInfo());
        if (entity.getConflictingTxHash() == null) {
          statement.bindNull(13);
        } else {
          statement.bindBlob(13, entity.getConflictingTxHash());
        }
        if (entity.getRawTransaction() == null) {
          statement.bindNull(14);
        } else {
          statement.bindString(14, entity.getRawTransaction());
        }
        statement.bindBlob(15, entity.getExtraPayload());
        statement.bindLong(16, entity.getNTime());
        statement.bindLong(17, entity.getType());
      }
    };
    this.__deletionAdapterOfTransaction = new EntityDeletionOrUpdateAdapter<Transaction>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `Transaction` WHERE `hash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Transaction entity) {
        statement.bindBlob(1, entity.getHash());
      }
    };
    this.__updateAdapterOfTransaction = new EntityDeletionOrUpdateAdapter<Transaction>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR REPLACE `Transaction` SET `uid` = ?,`hash` = ?,`blockHash` = ?,`version` = ?,`lockTime` = ?,`timestamp` = ?,`order` = ?,`isMine` = ?,`isOutgoing` = ?,`segwit` = ?,`status` = ?,`serializedTxInfo` = ?,`conflictingTxHash` = ?,`rawTransaction` = ?,`extraPayload` = ?,`nTime` = ?,`type` = ? WHERE `hash` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Transaction entity) {
        statement.bindString(1, entity.getUid());
        statement.bindBlob(2, entity.getHash());
        if (entity.getBlockHash() == null) {
          statement.bindNull(3);
        } else {
          statement.bindBlob(3, entity.getBlockHash());
        }
        statement.bindLong(4, entity.getVersion());
        statement.bindLong(5, entity.getLockTime());
        statement.bindLong(6, entity.getTimestamp());
        statement.bindLong(7, entity.getOrder());
        final int _tmp = entity.isMine() ? 1 : 0;
        statement.bindLong(8, _tmp);
        final int _tmp_1 = entity.isOutgoing() ? 1 : 0;
        statement.bindLong(9, _tmp_1);
        final int _tmp_2 = entity.getSegwit() ? 1 : 0;
        statement.bindLong(10, _tmp_2);
        statement.bindLong(11, entity.getStatus());
        statement.bindString(12, entity.getSerializedTxInfo());
        if (entity.getConflictingTxHash() == null) {
          statement.bindNull(13);
        } else {
          statement.bindBlob(13, entity.getConflictingTxHash());
        }
        if (entity.getRawTransaction() == null) {
          statement.bindNull(14);
        } else {
          statement.bindString(14, entity.getRawTransaction());
        }
        statement.bindBlob(15, entity.getExtraPayload());
        statement.bindLong(16, entity.getNTime());
        statement.bindLong(17, entity.getType());
        statement.bindBlob(18, entity.getHash());
      }
    };
    this.__preparedStmtOfDeleteByHash = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM `Transaction` WHERE hash=?";
        return _query;
      }
    };
  }

  @Override
  public void insert(final Transaction transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfTransaction.insert(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void delete(final Transaction transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfTransaction.handle(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteAll(final List<? extends Transaction> transactions) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __deletionAdapterOfTransaction.handleMultiple(transactions);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void update(final Transaction transaction) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __updateAdapterOfTransaction.handle(transaction);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public void deleteByHash(final byte[] hash) {
    __db.assertNotSuspendingTransaction();
    final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteByHash.acquire();
    int _argIndex = 1;
    _stmt.bindBlob(_argIndex, hash);
    try {
      __db.beginTransaction();
      try {
        _stmt.executeUpdateDelete();
        __db.setTransactionSuccessful();
      } finally {
        __db.endTransaction();
      }
    } finally {
      __preparedStmtOfDeleteByHash.release(_stmt);
    }
  }

  @Override
  public Transaction getByHashAndStatus(final byte[] hash, final int status) {
    final String _sql = "select * from `Transaction` where hash = ? and status = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    _argIndex = 2;
    _statement.bindLong(_argIndex, status);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final Transaction _result;
      if (_cursor.moveToFirst()) {
        _result = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _result.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _result.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _result.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _result.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _result.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _result.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _result.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _result.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _result.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _result.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _result.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _result.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _result.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _result.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _result.setType(_tmpType);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Transaction getByHash(final byte[] hash) {
    final String _sql = "select * from `Transaction` where hash = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final Transaction _result;
      if (_cursor.moveToFirst()) {
        _result = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _result.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _result.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _result.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _result.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _result.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _result.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _result.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _result.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _result.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _result.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _result.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _result.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _result.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _result.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _result.setType(_tmpType);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Transaction getValidOrInvalidByUid(final String uid) {
    final String _sql = "select * from (SELECT * FROM `Transaction` UNION ALL SELECT * FROM InvalidTransaction) where uid = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindString(_argIndex, uid);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final Transaction _result;
      if (_cursor.moveToFirst()) {
        _result = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _result.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _result.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _result.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _result.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _result.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _result.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _result.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _result.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _result.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _result.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _result.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _result.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _result.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _result.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _result.setType(_tmpType);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Transaction> getBlockTransactions(final byte[] blockHash) {
    final String _sql = "select * from `Transaction` where blockHash = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, blockHash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final List<Transaction> _result = new ArrayList<Transaction>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Transaction _item;
        _item = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _item.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _item.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _item.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _item.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _item.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _item.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _item.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _item.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _item.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _item.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _item.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _item.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _item.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _item.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _item.setType(_tmpType);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public Transaction getNewTransaction(final byte[] hash) {
    final String _sql = "select * from `Transaction` where hash = ? and status = 1 limit 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final Transaction _result;
      if (_cursor.moveToFirst()) {
        _result = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _result.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _result.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _result.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _result.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _result.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _result.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _result.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _result.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _result.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _result.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _result.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _result.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _result.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _result.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _result.setType(_tmpType);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Transaction> getNewTransactions() {
    final String _sql = "select * from `Transaction` where status = 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final List<Transaction> _result = new ArrayList<Transaction>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Transaction _item;
        _item = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _item.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _item.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _item.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _item.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _item.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _item.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _item.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _item.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _item.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _item.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _item.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _item.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _item.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _item.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _item.setType(_tmpType);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public TransactionWithBlock getTransactionWithBlock(final byte[] hash) {
    final String _sql = "SELECT * FROM `Transaction` t LEFT JOIN Block b ON t.blockHash = b.headerHash WHERE hash = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final int _cursorIndexOfVersion_1 = CursorUtil.getColumnIndexOrThrow(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndexOrThrow(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp_1 = CursorUtil.getColumnIndexOrThrow(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndexOrThrow(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndexOrThrow(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndexOrThrow(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndexOrThrow(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndexOrThrow(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndexOrThrow(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndexOrThrow(_cursor, "partial");
      final TransactionWithBlock _result;
      if (_cursor.moveToFirst()) {
        final Transaction _tmpTransaction;
        _tmpTransaction = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _tmpTransaction.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _tmpTransaction.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _tmpTransaction.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _tmpTransaction.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _tmpTransaction.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _tmpTransaction.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _tmpTransaction.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _tmpTransaction.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _tmpTransaction.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _tmpTransaction.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _tmpTransaction.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _tmpTransaction.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _tmpTransaction.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _tmpTransaction.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _tmpTransaction.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _tmpTransaction.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _tmpTransaction.setType(_tmpType);
        final Block _tmpBlock;
        if (!(_cursor.isNull(_cursorIndexOfVersion_1) && _cursor.isNull(_cursorIndexOfPreviousBlockHash) && _cursor.isNull(_cursorIndexOfMerkleRoot) && _cursor.isNull(_cursorIndexOfTimestamp_1) && _cursor.isNull(_cursorIndexOfBits) && _cursor.isNull(_cursorIndexOfNonce) && _cursor.isNull(_cursorIndexOfHasTransactions) && _cursor.isNull(_cursorIndexOfHeaderHash) && _cursor.isNull(_cursorIndexOfHeight) && _cursor.isNull(_cursorIndexOfStale) && _cursor.isNull(_cursorIndexOfPartial))) {
          _tmpBlock = new Block();
          final int _tmpVersion_1;
          _tmpVersion_1 = _cursor.getInt(_cursorIndexOfVersion_1);
          _tmpBlock.setVersion(_tmpVersion_1);
          final byte[] _tmpPreviousBlockHash;
          _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
          _tmpBlock.setPreviousBlockHash(_tmpPreviousBlockHash);
          final byte[] _tmpMerkleRoot;
          _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
          _tmpBlock.setMerkleRoot(_tmpMerkleRoot);
          final long _tmpTimestamp_1;
          _tmpTimestamp_1 = _cursor.getLong(_cursorIndexOfTimestamp_1);
          _tmpBlock.setTimestamp(_tmpTimestamp_1);
          final long _tmpBits;
          _tmpBits = _cursor.getLong(_cursorIndexOfBits);
          _tmpBlock.setBits(_tmpBits);
          final long _tmpNonce;
          _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
          _tmpBlock.setNonce(_tmpNonce);
          final boolean _tmpHasTransactions;
          final int _tmp_3;
          _tmp_3 = _cursor.getInt(_cursorIndexOfHasTransactions);
          _tmpHasTransactions = _tmp_3 != 0;
          _tmpBlock.setHasTransactions(_tmpHasTransactions);
          final byte[] _tmpHeaderHash;
          _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
          _tmpBlock.setHeaderHash(_tmpHeaderHash);
          final int _tmpHeight;
          _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
          _tmpBlock.setHeight(_tmpHeight);
          final boolean _tmpStale;
          final int _tmp_4;
          _tmp_4 = _cursor.getInt(_cursorIndexOfStale);
          _tmpStale = _tmp_4 != 0;
          _tmpBlock.setStale(_tmpStale);
          final boolean _tmpPartial;
          final int _tmp_5;
          _tmp_5 = _cursor.getInt(_cursorIndexOfPartial);
          _tmpPartial = _tmp_5 != 0;
          _tmpBlock.setPartial(_tmpPartial);
        } else {
          _tmpBlock = null;
        }
        _result = new TransactionWithBlock(_tmpTransaction,_tmpBlock);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<Transaction> getRelayedPendingTransactions(final int status) {
    final String _sql = "SELECT * FROM `Transaction` WHERE blockHash IS NULL AND status = ? AND isMine = 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, status);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final List<Transaction> _result = new ArrayList<Transaction>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final Transaction _item;
        _item = new Transaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _item.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _item.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _item.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _item.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _item.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _item.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _item.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _item.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _item.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _item.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _item.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _item.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _item.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _item.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _item.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _item.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _item.setType(_tmpType);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<byte[]> getIncomingPendingTxHashes() {
    final String _sql = "SELECT hash FROM `Transaction` WHERE blockHash IS NULL AND isOutgoing = 0 AND isMine = 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final List<byte[]> _result = new ArrayList<byte[]>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final byte[] _item;
        _item = _cursor.getBlob(0);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public int getIncomingPendingTxCount() {
    final String _sql = "SELECT COUNT(*) FROM `Transaction` WHERE blockHash IS NULL AND isOutgoing = 0 AND isMine = 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _result;
      if (_cursor.moveToFirst()) {
        _result = _cursor.getInt(0);
      } else {
        _result = 0;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public InvalidTransaction getInvalidTransaction(final byte[] hash) {
    final String _sql = "SELECT * FROM InvalidTransaction WHERE hash = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindBlob(_argIndex, hash);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndexOrThrow(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndexOrThrow(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndexOrThrow(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndexOrThrow(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndexOrThrow(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndexOrThrow(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndexOrThrow(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndexOrThrow(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndexOrThrow(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndexOrThrow(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndexOrThrow(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndexOrThrow(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndexOrThrow(_cursor, "type");
      final InvalidTransaction _result;
      if (_cursor.moveToFirst()) {
        _result = new InvalidTransaction();
        final String _tmpUid;
        _tmpUid = _cursor.getString(_cursorIndexOfUid);
        _result.setUid(_tmpUid);
        final byte[] _tmpHash;
        _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
        _result.setHash(_tmpHash);
        final byte[] _tmpBlockHash;
        if (_cursor.isNull(_cursorIndexOfBlockHash)) {
          _tmpBlockHash = null;
        } else {
          _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
        }
        _result.setBlockHash(_tmpBlockHash);
        final int _tmpVersion;
        _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
        _result.setVersion(_tmpVersion);
        final long _tmpLockTime;
        _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
        _result.setLockTime(_tmpLockTime);
        final long _tmpTimestamp;
        _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
        _result.setTimestamp(_tmpTimestamp);
        final int _tmpOrder;
        _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
        _result.setOrder(_tmpOrder);
        final boolean _tmpIsMine;
        final int _tmp;
        _tmp = _cursor.getInt(_cursorIndexOfIsMine);
        _tmpIsMine = _tmp != 0;
        _result.setMine(_tmpIsMine);
        final boolean _tmpIsOutgoing;
        final int _tmp_1;
        _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
        _tmpIsOutgoing = _tmp_1 != 0;
        _result.setOutgoing(_tmpIsOutgoing);
        final boolean _tmpSegwit;
        final int _tmp_2;
        _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
        _tmpSegwit = _tmp_2 != 0;
        _result.setSegwit(_tmpSegwit);
        final int _tmpStatus;
        _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
        _result.setStatus(_tmpStatus);
        final String _tmpSerializedTxInfo;
        _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
        _result.setSerializedTxInfo(_tmpSerializedTxInfo);
        final byte[] _tmpConflictingTxHash;
        if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
          _tmpConflictingTxHash = null;
        } else {
          _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
        }
        _result.setConflictingTxHash(_tmpConflictingTxHash);
        final String _tmpRawTransaction;
        if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
          _tmpRawTransaction = null;
        } else {
          _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
        }
        _result.setRawTransaction(_tmpRawTransaction);
        final byte[] _tmpExtraPayload;
        _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
        _result.setExtraPayload(_tmpExtraPayload);
        final long _tmpNTime;
        _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
        _result.setNTime(_tmpNTime);
        final int _tmpType;
        _tmpType = _cursor.getInt(_cursorIndexOfType);
        _result.setType(_tmpType);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @Override
  public List<TransactionWithBlock> getTransactionWithBlockBySql(final SupportSQLiteQuery query) {
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, query, false, null);
    try {
      final int _cursorIndexOfUid = CursorUtil.getColumnIndex(_cursor, "uid");
      final int _cursorIndexOfHash = CursorUtil.getColumnIndex(_cursor, "hash");
      final int _cursorIndexOfBlockHash = CursorUtil.getColumnIndex(_cursor, "blockHash");
      final int _cursorIndexOfVersion = CursorUtil.getColumnIndex(_cursor, "version");
      final int _cursorIndexOfLockTime = CursorUtil.getColumnIndex(_cursor, "lockTime");
      final int _cursorIndexOfTimestamp = CursorUtil.getColumnIndex(_cursor, "timestamp");
      final int _cursorIndexOfOrder = CursorUtil.getColumnIndex(_cursor, "order");
      final int _cursorIndexOfIsMine = CursorUtil.getColumnIndex(_cursor, "isMine");
      final int _cursorIndexOfIsOutgoing = CursorUtil.getColumnIndex(_cursor, "isOutgoing");
      final int _cursorIndexOfSegwit = CursorUtil.getColumnIndex(_cursor, "segwit");
      final int _cursorIndexOfStatus = CursorUtil.getColumnIndex(_cursor, "status");
      final int _cursorIndexOfSerializedTxInfo = CursorUtil.getColumnIndex(_cursor, "serializedTxInfo");
      final int _cursorIndexOfConflictingTxHash = CursorUtil.getColumnIndex(_cursor, "conflictingTxHash");
      final int _cursorIndexOfRawTransaction = CursorUtil.getColumnIndex(_cursor, "rawTransaction");
      final int _cursorIndexOfExtraPayload = CursorUtil.getColumnIndex(_cursor, "extraPayload");
      final int _cursorIndexOfNTime = CursorUtil.getColumnIndex(_cursor, "nTime");
      final int _cursorIndexOfType = CursorUtil.getColumnIndex(_cursor, "type");
      final int _cursorIndexOfVersion_1 = CursorUtil.getColumnIndex(_cursor, "block_version");
      final int _cursorIndexOfPreviousBlockHash = CursorUtil.getColumnIndex(_cursor, "previousBlockHash");
      final int _cursorIndexOfMerkleRoot = CursorUtil.getColumnIndex(_cursor, "merkleRoot");
      final int _cursorIndexOfTimestamp_1 = CursorUtil.getColumnIndex(_cursor, "block_timestamp");
      final int _cursorIndexOfBits = CursorUtil.getColumnIndex(_cursor, "bits");
      final int _cursorIndexOfNonce = CursorUtil.getColumnIndex(_cursor, "nonce");
      final int _cursorIndexOfHasTransactions = CursorUtil.getColumnIndex(_cursor, "hasTransactions");
      final int _cursorIndexOfHeaderHash = CursorUtil.getColumnIndex(_cursor, "headerHash");
      final int _cursorIndexOfHeight = CursorUtil.getColumnIndex(_cursor, "height");
      final int _cursorIndexOfStale = CursorUtil.getColumnIndex(_cursor, "stale");
      final int _cursorIndexOfPartial = CursorUtil.getColumnIndex(_cursor, "partial");
      final List<TransactionWithBlock> _result = new ArrayList<TransactionWithBlock>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final TransactionWithBlock _item;
        final Transaction _tmpTransaction;
        _tmpTransaction = new Transaction();
        if (_cursorIndexOfUid != -1) {
          final String _tmpUid;
          _tmpUid = _cursor.getString(_cursorIndexOfUid);
          _tmpTransaction.setUid(_tmpUid);
        }
        if (_cursorIndexOfHash != -1) {
          final byte[] _tmpHash;
          _tmpHash = _cursor.getBlob(_cursorIndexOfHash);
          _tmpTransaction.setHash(_tmpHash);
        }
        if (_cursorIndexOfBlockHash != -1) {
          final byte[] _tmpBlockHash;
          if (_cursor.isNull(_cursorIndexOfBlockHash)) {
            _tmpBlockHash = null;
          } else {
            _tmpBlockHash = _cursor.getBlob(_cursorIndexOfBlockHash);
          }
          _tmpTransaction.setBlockHash(_tmpBlockHash);
        }
        if (_cursorIndexOfVersion != -1) {
          final int _tmpVersion;
          _tmpVersion = _cursor.getInt(_cursorIndexOfVersion);
          _tmpTransaction.setVersion(_tmpVersion);
        }
        if (_cursorIndexOfLockTime != -1) {
          final long _tmpLockTime;
          _tmpLockTime = _cursor.getLong(_cursorIndexOfLockTime);
          _tmpTransaction.setLockTime(_tmpLockTime);
        }
        if (_cursorIndexOfTimestamp != -1) {
          final long _tmpTimestamp;
          _tmpTimestamp = _cursor.getLong(_cursorIndexOfTimestamp);
          _tmpTransaction.setTimestamp(_tmpTimestamp);
        }
        if (_cursorIndexOfOrder != -1) {
          final int _tmpOrder;
          _tmpOrder = _cursor.getInt(_cursorIndexOfOrder);
          _tmpTransaction.setOrder(_tmpOrder);
        }
        if (_cursorIndexOfIsMine != -1) {
          final boolean _tmpIsMine;
          final int _tmp;
          _tmp = _cursor.getInt(_cursorIndexOfIsMine);
          _tmpIsMine = _tmp != 0;
          _tmpTransaction.setMine(_tmpIsMine);
        }
        if (_cursorIndexOfIsOutgoing != -1) {
          final boolean _tmpIsOutgoing;
          final int _tmp_1;
          _tmp_1 = _cursor.getInt(_cursorIndexOfIsOutgoing);
          _tmpIsOutgoing = _tmp_1 != 0;
          _tmpTransaction.setOutgoing(_tmpIsOutgoing);
        }
        if (_cursorIndexOfSegwit != -1) {
          final boolean _tmpSegwit;
          final int _tmp_2;
          _tmp_2 = _cursor.getInt(_cursorIndexOfSegwit);
          _tmpSegwit = _tmp_2 != 0;
          _tmpTransaction.setSegwit(_tmpSegwit);
        }
        if (_cursorIndexOfStatus != -1) {
          final int _tmpStatus;
          _tmpStatus = _cursor.getInt(_cursorIndexOfStatus);
          _tmpTransaction.setStatus(_tmpStatus);
        }
        if (_cursorIndexOfSerializedTxInfo != -1) {
          final String _tmpSerializedTxInfo;
          _tmpSerializedTxInfo = _cursor.getString(_cursorIndexOfSerializedTxInfo);
          _tmpTransaction.setSerializedTxInfo(_tmpSerializedTxInfo);
        }
        if (_cursorIndexOfConflictingTxHash != -1) {
          final byte[] _tmpConflictingTxHash;
          if (_cursor.isNull(_cursorIndexOfConflictingTxHash)) {
            _tmpConflictingTxHash = null;
          } else {
            _tmpConflictingTxHash = _cursor.getBlob(_cursorIndexOfConflictingTxHash);
          }
          _tmpTransaction.setConflictingTxHash(_tmpConflictingTxHash);
        }
        if (_cursorIndexOfRawTransaction != -1) {
          final String _tmpRawTransaction;
          if (_cursor.isNull(_cursorIndexOfRawTransaction)) {
            _tmpRawTransaction = null;
          } else {
            _tmpRawTransaction = _cursor.getString(_cursorIndexOfRawTransaction);
          }
          _tmpTransaction.setRawTransaction(_tmpRawTransaction);
        }
        if (_cursorIndexOfExtraPayload != -1) {
          final byte[] _tmpExtraPayload;
          _tmpExtraPayload = _cursor.getBlob(_cursorIndexOfExtraPayload);
          _tmpTransaction.setExtraPayload(_tmpExtraPayload);
        }
        if (_cursorIndexOfNTime != -1) {
          final long _tmpNTime;
          _tmpNTime = _cursor.getLong(_cursorIndexOfNTime);
          _tmpTransaction.setNTime(_tmpNTime);
        }
        if (_cursorIndexOfType != -1) {
          final int _tmpType;
          _tmpType = _cursor.getInt(_cursorIndexOfType);
          _tmpTransaction.setType(_tmpType);
        }
        final Block _tmpBlock;
        if (!((_cursorIndexOfVersion_1 == -1 || _cursor.isNull(_cursorIndexOfVersion_1)) && (_cursorIndexOfPreviousBlockHash == -1 || _cursor.isNull(_cursorIndexOfPreviousBlockHash)) && (_cursorIndexOfMerkleRoot == -1 || _cursor.isNull(_cursorIndexOfMerkleRoot)) && (_cursorIndexOfTimestamp_1 == -1 || _cursor.isNull(_cursorIndexOfTimestamp_1)) && (_cursorIndexOfBits == -1 || _cursor.isNull(_cursorIndexOfBits)) && (_cursorIndexOfNonce == -1 || _cursor.isNull(_cursorIndexOfNonce)) && (_cursorIndexOfHasTransactions == -1 || _cursor.isNull(_cursorIndexOfHasTransactions)) && (_cursorIndexOfHeaderHash == -1 || _cursor.isNull(_cursorIndexOfHeaderHash)) && (_cursorIndexOfHeight == -1 || _cursor.isNull(_cursorIndexOfHeight)) && (_cursorIndexOfStale == -1 || _cursor.isNull(_cursorIndexOfStale)) && (_cursorIndexOfPartial == -1 || _cursor.isNull(_cursorIndexOfPartial)))) {
          _tmpBlock = new Block();
          if (_cursorIndexOfVersion_1 != -1) {
            final int _tmpVersion_1;
            _tmpVersion_1 = _cursor.getInt(_cursorIndexOfVersion_1);
            _tmpBlock.setVersion(_tmpVersion_1);
          }
          if (_cursorIndexOfPreviousBlockHash != -1) {
            final byte[] _tmpPreviousBlockHash;
            _tmpPreviousBlockHash = _cursor.getBlob(_cursorIndexOfPreviousBlockHash);
            _tmpBlock.setPreviousBlockHash(_tmpPreviousBlockHash);
          }
          if (_cursorIndexOfMerkleRoot != -1) {
            final byte[] _tmpMerkleRoot;
            _tmpMerkleRoot = _cursor.getBlob(_cursorIndexOfMerkleRoot);
            _tmpBlock.setMerkleRoot(_tmpMerkleRoot);
          }
          if (_cursorIndexOfTimestamp_1 != -1) {
            final long _tmpTimestamp_1;
            _tmpTimestamp_1 = _cursor.getLong(_cursorIndexOfTimestamp_1);
            _tmpBlock.setTimestamp(_tmpTimestamp_1);
          }
          if (_cursorIndexOfBits != -1) {
            final long _tmpBits;
            _tmpBits = _cursor.getLong(_cursorIndexOfBits);
            _tmpBlock.setBits(_tmpBits);
          }
          if (_cursorIndexOfNonce != -1) {
            final long _tmpNonce;
            _tmpNonce = _cursor.getLong(_cursorIndexOfNonce);
            _tmpBlock.setNonce(_tmpNonce);
          }
          if (_cursorIndexOfHasTransactions != -1) {
            final boolean _tmpHasTransactions;
            final int _tmp_3;
            _tmp_3 = _cursor.getInt(_cursorIndexOfHasTransactions);
            _tmpHasTransactions = _tmp_3 != 0;
            _tmpBlock.setHasTransactions(_tmpHasTransactions);
          }
          if (_cursorIndexOfHeaderHash != -1) {
            final byte[] _tmpHeaderHash;
            _tmpHeaderHash = _cursor.getBlob(_cursorIndexOfHeaderHash);
            _tmpBlock.setHeaderHash(_tmpHeaderHash);
          }
          if (_cursorIndexOfHeight != -1) {
            final int _tmpHeight;
            _tmpHeight = _cursor.getInt(_cursorIndexOfHeight);
            _tmpBlock.setHeight(_tmpHeight);
          }
          if (_cursorIndexOfStale != -1) {
            final boolean _tmpStale;
            final int _tmp_4;
            _tmp_4 = _cursor.getInt(_cursorIndexOfStale);
            _tmpStale = _tmp_4 != 0;
            _tmpBlock.setStale(_tmpStale);
          }
          if (_cursorIndexOfPartial != -1) {
            final boolean _tmpPartial;
            final int _tmp_5;
            _tmp_5 = _cursor.getInt(_cursorIndexOfPartial);
            _tmpPartial = _tmp_5 != 0;
            _tmpBlock.setPartial(_tmpPartial);
          }
        } else {
          _tmpBlock = null;
        }
        _item = new TransactionWithBlock(_tmpTransaction,_tmpBlock);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
