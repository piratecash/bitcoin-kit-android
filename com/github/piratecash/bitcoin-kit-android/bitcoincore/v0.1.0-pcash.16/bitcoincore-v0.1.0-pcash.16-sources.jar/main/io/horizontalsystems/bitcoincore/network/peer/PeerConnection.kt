package io.horizontalsystems.bitcoincore.network.peer

import io.horizontalsystems.bitcoincore.io.BitcoinInput
import io.horizontalsystems.bitcoincore.network.Network
import io.horizontalsystems.bitcoincore.network.messages.IMessage
import io.horizontalsystems.bitcoincore.network.messages.NetworkMessageParser
import io.horizontalsystems.bitcoincore.network.messages.NetworkMessageSerializer
import io.horizontalsystems.bitcoincore.utils.NetworkUtils
import timber.log.Timber
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.RejectedExecutionException
import java.util.logging.Logger

class PeerConnection(
        private val host: String,
        private val network: Network,
        private val listener: Listener,
        private val sendingExecutor: ExecutorService,
        private val networkMessageParser: NetworkMessageParser,
        private val networkMessageSerializer: NetworkMessageSerializer)
    : Runnable {

    interface Listener {
        fun socketConnected(address: InetAddress)
        fun disconnected(e: Exception? = null)
        fun onTimePeriodPassed() // didn't find better name
        fun onMessage(message: IMessage)
    }

    private val socket = NetworkUtils.createSocket()

    private val logger = Logger.getLogger("Peer[$host]")
    private var outputStream: OutputStream? = null
    private var inputStream: InputStream? = null
    private var disconnectError: Exception? = null

    @Volatile
    private var isRunning = false

    override fun run() {
        isRunning = true
        // connect:
        try {
            socket.connect(InetSocketAddress(host, network.port), 10000)
            socket.soTimeout = 10000

            outputStream = socket.getOutputStream()
            val inputStream = socket.getInputStream()
            val bitcoinInput = BitcoinInput(inputStream)

            logger.info("${network.logTag}: Socket $host connected.")

            listener.socketConnected(socket.inetAddress)

            this.inputStream = inputStream
            // loop:
            while (isRunning) {
                listener.onTimePeriodPassed()

                Thread.sleep(1000)

                // try receive message:
                while (isRunning && inputStream.available() > 0) {
                    try {
                        val parsedMsg = networkMessageParser.parseMessage(bitcoinInput)
                        Timber.tag(network.logTag).d("<= $parsedMsg")
                        listener.onMessage(parsedMsg)
                    } catch (ex : Exception) {
                        ex.printStackTrace()
                        logger.warning("${network.logTag}: Failed to parse message: ${ex.message}")
                    }
                }
            }
        } catch (e: Exception) {
            close(e)
        } finally {
            outputStream?.close()
            outputStream = null

            inputStream?.close()
            inputStream = null

            listener.disconnected(disconnectError)
        }
    }

    @Synchronized
    fun close(error: Exception?) {
        disconnectError = error
        isRunning = false
    }

    @Synchronized
    fun sendMessage(message: IMessage) {
        try {
            sendingExecutor.execute {
                if (isRunning) {
                    try {
                        logger.info("${network.logTag}: => $message")
                        outputStream?.write(networkMessageSerializer.serialize(message))
                    } catch (e: Exception) {
                        close(e)
                    }
                }
            }
        } catch (_: RejectedExecutionException) {
            // PeerGroup.stop() shut the sending executor down. By that point
            // peerManager.disconnectAll() has already called close(null) on
            // this connection, so we MUST NOT call close(e) here — that would
            // overwrite the clean (null) disconnect cause with a synthetic
            // error and make PeerGroup.onDisconnect mark the peer as failed.
            // PeerAddressManager.markFailed deletes the host from storage,
            // which on networks with only a few seed nodes
            // (Cosanta / Pirate Cash currently have 3) would burn valid peer
            // addresses on every kit restart. Late sends are safe to drop:
            // the peer is on its way out cleanly.
        }
    }

}
