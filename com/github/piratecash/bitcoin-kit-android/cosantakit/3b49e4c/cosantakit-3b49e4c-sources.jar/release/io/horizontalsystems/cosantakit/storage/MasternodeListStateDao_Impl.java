package io.horizontalsystems.cosantakit.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.cosantakit.models.MasternodeListState;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class MasternodeListStateDao_Impl implements MasternodeListStateDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<MasternodeListState> __insertionAdapterOfMasternodeListState;

  public MasternodeListStateDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfMasternodeListState = new EntityInsertionAdapter<MasternodeListState>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `MasternodeListState` (`baseBlockHash`,`primaryKey`) VALUES (?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final MasternodeListState entity) {
        statement.bindBlob(1, entity.getBaseBlockHash());
        statement.bindString(2, entity.getPrimaryKey());
      }
    };
  }

  @Override
  public void setState(final MasternodeListState state) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfMasternodeListState.insert(state);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public MasternodeListState getState() {
    final String _sql = "SELECT * FROM MasternodeListState LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfBaseBlockHash = CursorUtil.getColumnIndexOrThrow(_cursor, "baseBlockHash");
      final int _cursorIndexOfPrimaryKey = CursorUtil.getColumnIndexOrThrow(_cursor, "primaryKey");
      final MasternodeListState _result;
      if (_cursor.moveToFirst()) {
        final byte[] _tmpBaseBlockHash;
        _tmpBaseBlockHash = _cursor.getBlob(_cursorIndexOfBaseBlockHash);
        _result = new MasternodeListState(_tmpBaseBlockHash);
        final String _tmpPrimaryKey;
        _tmpPrimaryKey = _cursor.getString(_cursorIndexOfPrimaryKey);
        _result.setPrimaryKey(_tmpPrimaryKey);
      } else {
        _result = null;
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
