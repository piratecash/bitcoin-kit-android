package io.horizontalsystems.cosantakit.storage;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import io.horizontalsystems.cosantakit.models.InstantTransactionHash;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class InstantTransactionHashDao_Impl implements InstantTransactionHashDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<InstantTransactionHash> __insertionAdapterOfInstantTransactionHash;

  public InstantTransactionHashDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfInstantTransactionHash = new EntityInsertionAdapter<InstantTransactionHash>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `InstantTransactionHash` (`txHash`) VALUES (?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final InstantTransactionHash entity) {
        statement.bindBlob(1, entity.getTxHash());
      }
    };
  }

  @Override
  public void insert(final InstantTransactionHash instantTransactionHash) {
    __db.assertNotSuspendingTransaction();
    __db.beginTransaction();
    try {
      __insertionAdapterOfInstantTransactionHash.insert(instantTransactionHash);
      __db.setTransactionSuccessful();
    } finally {
      __db.endTransaction();
    }
  }

  @Override
  public List<InstantTransactionHash> getAll() {
    final String _sql = "SELECT * FROM InstantTransactionHash";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    __db.assertNotSuspendingTransaction();
    final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
    try {
      final int _cursorIndexOfTxHash = CursorUtil.getColumnIndexOrThrow(_cursor, "txHash");
      final List<InstantTransactionHash> _result = new ArrayList<InstantTransactionHash>(_cursor.getCount());
      while (_cursor.moveToNext()) {
        final InstantTransactionHash _item;
        final byte[] _tmpTxHash;
        _tmpTxHash = _cursor.getBlob(_cursorIndexOfTxHash);
        _item = new InstantTransactionHash(_tmpTxHash);
        _result.add(_item);
      }
      return _result;
    } finally {
      _cursor.close();
      _statement.release();
    }
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
