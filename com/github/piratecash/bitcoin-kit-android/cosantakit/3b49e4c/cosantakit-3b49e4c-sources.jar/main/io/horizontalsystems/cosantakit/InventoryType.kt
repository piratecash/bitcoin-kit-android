package io.horizontalsystems.cosantakit

object InventoryType {
    const val MSG_TXLOCK_REQUEST = 4
    const val MSG_TXLOCK_VOTE = 5
    const val MSG_ISLOCK = 30
    const val MSG_ISDLOCK = 31
}
