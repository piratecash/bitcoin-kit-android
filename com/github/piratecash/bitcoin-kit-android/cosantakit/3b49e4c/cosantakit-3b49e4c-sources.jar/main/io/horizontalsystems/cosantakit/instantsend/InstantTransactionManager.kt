package io.horizontalsystems.cosantakit.instantsend

import io.horizontalsystems.bitcoincore.core.IInstantTransactionChecker
import io.horizontalsystems.bitcoincore.models.TransactionInput
import io.horizontalsystems.bitcoincore.storage.FullTransaction
import io.horizontalsystems.cosantakit.CosantaKitErrors
import io.horizontalsystems.cosantakit.ICosantaStorage
import io.horizontalsystems.cosantakit.InstantSend
import io.horizontalsystems.cosantakit.models.InstantTransactionInput
import io.horizontalsystems.cosantakit.models.InstantTransactionState

class InstantTransactionManager(
        private val storage: ICosantaStorage,
        private val instantSendFactory: InstantSendFactory,
        private val state: InstantTransactionState
) : IInstantTransactionChecker {
    init {
        state.clearAndAppend(storage.instantTransactionHashes())
    }

    fun instantTransactionInputs(txHash: ByteArray, instantTransaction: FullTransaction?): List<InstantTransactionInput> {
        // check if inputs already created
        val inputs = storage.instantTransactionInputs(txHash)
        if (inputs.isNotEmpty()) {
            return inputs
        }

        // if not check coming ix
        instantTransaction?.let { transaction ->
            return makeInputs(txHash, transaction.inputs)
        }

        // if we can't get inputs and ix is null, try get tx inputs from db
        return makeInputs(txHash, storage.getTransactionInputs(txHash))
    }

    @Throws
    fun updateInput(inputTxHash: ByteArray, inputTxOutputIndex: Long, transactionInputs: List<InstantTransactionInput>) {
        val updatedInputs = transactionInputs.toMutableList()

        val inputIndex = transactionInputs.indexOfFirst {
            it.inputTxHash.contentEquals(inputTxHash) && it.inputTxOutputIndex == inputTxOutputIndex
        }
        if (inputIndex == -1) {
            throw CosantaKitErrors.LockVoteValidation.TxInputNotFound()
        }

        val input = transactionInputs[inputIndex]
        val increasedInput = instantSendFactory.instantTransactionInput(input.txHash, input.inputTxHash, input.inputTxOutputIndex, input.voteCount + 1, input.blockHeight)
        storage.addInstantTransactionInput(increasedInput)

        updatedInputs[inputIndex] = increasedInput
        if (updatedInputs.none { it.voteCount < InstantSend.requiredVoteCount }) {
            state.append(input.txHash)
            storage.addInstantTransactionHash(input.txHash)
            storage.removeInstantTransactionInputs(input.txHash)
        }
    }

    override fun isTransactionInstant(txHash: ByteArray): Boolean {
        return state.isInstant(txHash)
    }

    fun isTransactionExists(txHash: ByteArray): Boolean {
        return storage.isTransactionExists(txHash)
    }

    fun makeInstant(txHash: ByteArray) {
        state.append(txHash)
        storage.addInstantTransactionHash(txHash)
    }

    private fun makeInputs(txHash: ByteArray, inputs: List<TransactionInput>): List<InstantTransactionInput> {
        val instantInputs = mutableListOf<InstantTransactionInput>()
        for (input in inputs) {
            val instantInput = instantSendFactory.instantTransactionInput(txHash, input.previousOutputTxHash, input.previousOutputIndex, 0, null)

            storage.addInstantTransactionInput(instantInput)
            instantInputs.add(instantInput)
        }
        return instantInputs
    }

}